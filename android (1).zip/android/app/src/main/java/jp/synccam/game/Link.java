package jp.synccam.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import org.json.JSONObject;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.MediaStreamTrack;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpTransceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.VideoFrame;
import org.webrtc.VideoSink;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 2台の接続（メイン機とサブ機）。
 * 相手探しはFirebase（待ち合わせ場所）、映像は2台の間で直接（WebRTC）。
 * パスワードから作った合言葉で、同じパスワードの相手に自動でつながる。
 */
public class Link {

    static final Handler MAIN = new Handler(Looper.getMainLooper());

    static String peerIdFor(String pw) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("synccam|" + pw).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return "synccam-" + sb.substring(0, 32);
        } catch (Exception e) {
            return "synccam-" + Math.abs(pw.hashCode());
        }
    }

    /* ================= 共通：WebRTC の準備 ================= */

    static EglBase egl;
    static PeerConnectionFactory factory;

    static synchronized void initRtc(Context c) {
        if (factory != null) return;
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(c.getApplicationContext()).createInitializationOptions());
        egl = EglBase.create();
        factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(new DefaultVideoEncoderFactory(egl.getEglBaseContext(), true, true))
                .setVideoDecoderFactory(new DefaultVideoDecoderFactory(egl.getEglBaseContext()))
                .createPeerConnectionFactory();
    }

    static PeerConnection.RTCConfiguration rtcConfig() {
        List<PeerConnection.IceServer> ice = new ArrayList<>();
        ice.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());
        ice.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer());
        ice.add(PeerConnection.IceServer.builder(Arrays.asList("turn:eu-0.turn.peerjs.com:3478", "turn:us-0.turn.peerjs.com:3478"))
                .setUsername("peerjs").setPassword("peerjsp").createIceServer());
        ice.add(PeerConnection.IceServer.builder(Arrays.asList(
                        "turn:openrelay.metered.ca:80", "turn:openrelay.metered.ca:443", "turn:openrelay.metered.ca:443?transport=tcp"))
                .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer());
        PeerConnection.RTCConfiguration cfg = new PeerConnection.RTCConfiguration(ice);
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        return cfg;
    }

    /** 何もしない SdpObserver（必要なところだけ上書き） */
    static class Sdp implements SdpObserver {
        public void onCreateSuccess(SessionDescription d) { }
        public void onSetSuccess() { }
        public void onCreateFailure(String s) { }
        public void onSetFailure(String s) { }
    }

    /** 何もしない PeerConnection.Observer */
    static class PcObserver implements PeerConnection.Observer {
        public void onSignalingChange(PeerConnection.SignalingState s) { }
        public void onIceConnectionChange(PeerConnection.IceConnectionState s) { }
        public void onIceConnectionReceivingChange(boolean b) { }
        public void onIceGatheringChange(PeerConnection.IceGatheringState s) { }
        public void onIceCandidate(IceCandidate c) { }
        public void onIceCandidatesRemoved(IceCandidate[] c) { }
        public void onAddStream(MediaStream s) { }
        public void onRemoveStream(MediaStream s) { }
        public void onDataChannel(DataChannel d) { }
        public void onRenegotiationNeeded() { }
        public void onAddTrack(RtpReceiver r, MediaStream[] s) { }
        public void onTrack(RtpTransceiver t) { }
    }

    static JSONObject candJson(IceCandidate c) {
        try {
            return new JSONObject().put("candidate", new JSONObject().put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static IceCandidate cand(JSONObject payload) {
        JSONObject c = payload.optJSONObject("candidate");
        if (c == null) return null;
        return new IceCandidate(c.optString("sdpMid"), c.optInt("sdpMLineIndex"), c.optString("candidate"));
    }

    static void sendData(DataChannel dc, JSONObject m) {
        try {
            if (dc != null && dc.state() == DataChannel.State.OPEN) {
                byte[] b = m.toString().getBytes(StandardCharsets.UTF_8);
                dc.send(new DataChannel.Buffer(ByteBuffer.wrap(b), false));
            }
        } catch (Exception ignored) { }
    }

    static JSONObject readData(DataChannel.Buffer buf) {
        try {
            byte[] b = new byte[buf.data.remaining()];
            buf.data.get(b);
            return new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    /* ================= 相手探しの待ち合わせ場所（Firebase） ================= */

    static final String DB = "https://synccam-link-default-rtdb.asia-southeast1.firebasedatabase.app";

    interface SignalListener {
        void onOpen();
        void onMessage(JSONObject m);
        void onError(String type);
    }

    /**
     * rooms/<部屋>/inbox/<自分のID> が自分あての郵便受け。
     * 相手の郵便受けに手紙を入れ（POST）、自分の郵便受けを見張る（ストリーミング）。
     */
    static class Signal {
        static final OkHttpClient CLIENT = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(90, TimeUnit.SECONDS)
                .build();
        static final okhttp3.MediaType JSON = okhttp3.MediaType.parse("application/json; charset=utf-8");
        final String room, id;
        final SignalListener l;
        final java.util.concurrent.ExecutorService out = java.util.concurrent.Executors.newSingleThreadExecutor();
        final java.util.Set<String> seen = new java.util.HashSet<>();
        volatile boolean closed = false, opened = false;
        okhttp3.Call stream;

        Signal(String room, String id, SignalListener l) { this.room = room; this.id = id; this.l = l; }

        String box(String who) { return DB + "/rooms/" + room + "/inbox/" + who + ".json"; }

        void connect(boolean clearFirst) {
            out.execute(() -> {
                if (clearFirst) http("DELETE", box(id), null);
                listen();
            });
        }

        void listen() {
            if (closed) return;
            Request r = new Request.Builder().url(box(id)).header("Accept", "text/event-stream").build();
            stream = CLIENT.newCall(r);
            new Thread(() -> {
                okhttp3.Call call = stream;
                try (Response resp = call.execute()) {
                    if (!resp.isSuccessful() || resp.body() == null) throw new Exception("http " + resp.code());
                    okio.BufferedSource src = resp.body().source();
                    String event = null;
                    while (!closed) {
                        String line = src.readUtf8Line();
                        if (line == null) break;
                        if (line.startsWith("event:")) event = line.substring(6).trim();
                        else if (line.startsWith("data:")) onEvent(event, line.substring(5).trim());
                    }
                } catch (Exception e) {
                    // 下で処理
                }
                if (closed) return;
                if (!opened) {
                    MAIN.post(() -> { if (!closed) l.onError("network"); });
                } else {
                    MAIN.postDelayed(this::listen, 2000);   // 途中で切れたら、静かにつなぎ直す
                }
            }).start();
        }

        void onEvent(String event, String data) {
            if ("cancel".equals(event) || "auth_revoked".equals(event)) {
                MAIN.post(() -> { if (!closed) l.onError("server"); });
                return;
            }
            if (!"put".equals(event) && !"patch".equals(event)) return;
            try {
                JSONObject j = new JSONObject(data);
                String path = j.optString("path", "/");
                Object d = j.opt("data");
                if ("/".equals(path)) {
                    if (d instanceof JSONObject) {
                        JSONObject all = (JSONObject) d;
                        java.util.List<String> keys = new java.util.ArrayList<>();
                        java.util.Iterator<String> it = all.keys();
                        while (it.hasNext()) keys.add(it.next());
                        java.util.Collections.sort(keys);
                        for (String k : keys) deliver(k, all.optJSONObject(k));
                    }
                    if (!opened) { opened = true; MAIN.post(() -> { if (!closed) l.onOpen(); }); }
                } else if (d instanceof JSONObject) {
                    String k = path.substring(1);
                    if (k.contains("/")) return;
                    deliver(k, (JSONObject) d);
                }
            } catch (Exception ignored) { }
        }

        void deliver(String key, JSONObject m) {
            if (m == null || !seen.add(key)) return;
            out.execute(() -> http("DELETE", DB + "/rooms/" + room + "/inbox/" + id + "/" + key + ".json", null));
            MAIN.post(() -> { if (!closed) l.onMessage(m); });
        }

        void send(String type, String dst, JSONObject payload) {
            if (closed || dst == null) return;
            try {
                String body = new JSONObject().put("type", type).put("src", id).put("payload", payload).toString();
                out.execute(() -> http("POST", box(dst), body));   // 順番どおりに1通ずつ
            } catch (Exception ignored) { }
        }

        static void http(String method, String url, String body) {
            for (int i = 0; i < 3; i++) {
                try {
                    Request.Builder b = new Request.Builder().url(url);
                    if (body != null) b.method(method, okhttp3.RequestBody.create(body, JSON));
                    else b.method(method, null);
                    try (Response r = CLIENT.newCall(b.build()).execute()) {
                        if (r.isSuccessful()) return;
                    }
                } catch (Exception ignored) { }
                try { Thread.sleep(700); } catch (Exception ignored) { }
            }
        }

        void close() {
            closed = true;
            try { if (stream != null) stream.cancel(); } catch (Exception ignored) { }
            final String mine = box(id);
            try { out.execute(() -> http("DELETE", mine, null)); out.shutdown(); } catch (Exception ignored) { }
        }
    }

    /* ================= 直接つながらないときの「中継」 =================
       rooms/<部屋>/frame に小さな写真（1秒に5枚）を置き、メイン機が見張って受け取る */

    static String frameUrl(String room) { return DB + "/rooms/" + room + "/frame.json"; }

    /** 1つの場所を見張り続ける（切れたらつなぎ直す） */
    static class Watch {
        final String url;
        final java.util.function.Consumer<Object> cb;
        volatile boolean closed = false;
        volatile okhttp3.Call call;

        Watch(String url, java.util.function.Consumer<Object> cb) { this.url = url; this.cb = cb; start(); }

        void start() {
            if (closed) return;
            new Thread(() -> {
                try {
                    call = Signal.CLIENT.newCall(new Request.Builder().url(url).header("Accept", "text/event-stream").build());
                    try (Response r = call.execute()) {
                        if (r.isSuccessful() && r.body() != null) {
                            okio.BufferedSource src = r.body().source();
                            String ev = null;
                            while (!closed) {
                                String line = src.readUtf8Line();
                                if (line == null) break;
                                if (line.startsWith("event:")) ev = line.substring(6).trim();
                                else if (line.startsWith("data:") && "put".equals(ev)) {
                                    JSONObject j = new JSONObject(line.substring(5).trim());
                                    if ("/".equals(j.optString("path"))) cb.accept(j.opt("data"));
                                }
                            }
                        }
                    }
                } catch (Exception ignored) { }
                if (!closed) MAIN.postDelayed(this::start, 2000);
            }).start();
        }

        void close() {
            closed = true;
            try { if (call != null) call.cancel(); } catch (Exception ignored) { }
        }
    }

    /* =====================================================
       メイン機：パスワードを決めると待ち受ける。サブ機の映像を受け取る
       ===================================================== */

    public static class Main {
        static Context ctx;
        static String pw;
        static Signal signal;
        static PeerConnection pc;
        static DataChannel dc;
        static String remoteId;
        static boolean approved = false, remoteSet = false;
        static final List<IceCandidate> pending = new ArrayList<>();
        static String status = "off";       // off / connecting / wait / linking / linked / dup / neterr
        static Runnable onChange;            // ロビーの表示を変える
        static FrameListener frames;         // 配信の合成に映像を渡す
        static Runnable onLinkChange;        // つながった／切れた
        static int retry = 0;
        static long lastFrame = 0;
        static volatile boolean converting = false;

        interface FrameListener { void onFrame(Bitmap upright); }

        static void set(String s) {
            status = s;
            MAIN.post(() -> { if (onChange != null) onChange.run(); });
        }

        /** サブ機の映像が届いているか（届いていなければ、この端末のカメラを使う） */
        static boolean linked() { return approved && videoOn && pc != null; }

        static void start(Context c, String password) {
            ctx = c.getApplicationContext();
            if (password.equals(pw) && signal != null && !"neterr".equals(status) && !"dup".equals(status)) return;
            stop();
            pw = password;
            set("connecting");
            final String mine = password;
            signal = new Signal(peerIdFor(password), peerIdFor(password), new SignalListener() {
                public void onOpen() { retry = 0; if (!linked()) set("wait"); }
                public void onMessage(JSONObject m) { handle(m); }
                public void onError(String type) {
                    if (!mine.equals(pw)) return;
                    if (signal != null) signal.close();
                    signal = null;
                    if ("taken".equals(type) && retry++ < 6) {
                        set("connecting");
                        MAIN.postDelayed(() -> { if (mine.equals(pw) && signal == null) start(ctx, mine); }, 5000);
                    } else {
                        set("taken".equals(type) ? "dup" : "neterr");
                        if (!"taken".equals(type)) MAIN.postDelayed(() -> { if (mine.equals(pw) && signal == null) start(ctx, mine); }, 10000);
                    }
                }
            });
            signal.connect(true);
        }

        static void handle(JSONObject m) {
            String type = m.optString("type");
            JSONObject p = m.optJSONObject("payload");
            String src = m.optString("src");
            if ("OFFER".equals(type) && p != null) onOffer(src, p);
            else if ("CANDIDATE".equals(type) && p != null && p.has("ctl")) {
                // サブ機からの合図（パーティーに参加する、など）
                if (src.equals(remoteId)) onData(p.optJSONObject("ctl"));
            } else if ("CANDIDATE".equals(type) && p != null && src.equals(remoteId)) {
                IceCandidate c = cand(p);
                if (c == null) return;
                if (pc != null && remoteSet) pc.addIceCandidate(c); else pending.add(c);
            }
        }

        static void onOffer(String src, JSONObject p) {
            dropSub(true);
            initRtc(ctx);
            remoteId = src;
            approved = false;
            remoteSet = false;
            pending.clear();
            set("linking");
            pc = factory.createPeerConnection(rtcConfig(), new PcObserver() {
                @Override
                public void onIceCandidate(IceCandidate c) { MAIN.post(() -> { if (signal != null) signal.send("CANDIDATE", src, candJson(c)); }); }

                @Override
                public void onTrack(RtpTransceiver t) {
                    MediaStreamTrack tr = t.getReceiver().track();
                    if (tr instanceof VideoTrack) ((VideoTrack) tr).addSink(SINK);
                }

                @Override
                public void onDataChannel(DataChannel d) {
                    MAIN.post(() -> {
                        dc = d;
                        d.registerObserver(new DataChannel.Observer() {
                            public void onBufferedAmountChange(long l) { }
                            public void onStateChange() { }
                            public void onMessage(DataChannel.Buffer b) {
                                JSONObject j = readData(b);
                                if (j != null) MAIN.post(() -> onData(j));
                            }
                        });
                    });
                }

                @Override
                public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
                    MAIN.post(() -> {
                        if (s == PeerConnection.IceConnectionState.CONNECTED || s == PeerConnection.IceConnectionState.COMPLETED) iceOk = true;
                        if (s == PeerConnection.IceConnectionState.FAILED) iceFailed = true;
                        if (approved) set("linked");
                    });
                }
            });
            iceOk = false;
            iceFailed = false;
            videoOn = false;
            if (pc == null) { set("wait"); return; }
            String sdp = p.optString("sdp");
            pc.setRemoteDescription(new Sdp() {
                @Override
                public void onSetSuccess() {
                    MAIN.post(() -> {
                        remoteSet = true;
                        for (IceCandidate c : pending) pc.addIceCandidate(c);
                        pending.clear();
                        pc.createAnswer(new Sdp() {
                            @Override
                            public void onCreateSuccess(SessionDescription d) {
                                MAIN.post(() -> {
                                    if (pc == null) return;
                                    pc.setLocalDescription(new Sdp(), d);
                                    // 返事に「この人です」（メールアドレス）を入れて、すぐサブ機に確認を出してもらう
                                    try { signal.send("ANSWER", src, who().put("sdp", d.description)); } catch (Exception ignored) { }
                                });
                            }
                        }, new MediaConstraints());
                    });
                }
            }, new SessionDescription(SessionDescription.Type.OFFER, sdp));
        }

        static boolean iceOk = false, iceFailed = false;
        static volatile boolean videoOn = false;

        /** メイン機のアカウント（サブ機の「この人でいいですか？」に出す） */
        static JSONObject who() {
            JSONObject acc = null;
            String cur = Auth.sp(ctx).getString("current", "");
            for (JSONObject o : Auth.accounts(ctx)) if (o.optString("email").equalsIgnoreCase(cur)) acc = o;
            if (acc == null && !Auth.accounts(ctx).isEmpty()) acc = Auth.accounts(ctx).get(0);
            JSONObject j = new JSONObject();
            try {
                j.put("email", acc == null ? "（Googleアカウント未設定）" : acc.optString("email"));
                j.put("name", acc == null ? "" : acc.optString("channel", acc.optString("name")));
            } catch (Exception ignored) { }
            return j;
        }

        static Watch relay;
        static volatile boolean relayBusy = false;

        static void startRelayWatch() {
            if (relay != null || pw == null) return;
            String room = peerIdFor(pw);
            relay = new Watch(frameUrl(room), d -> {
                if (!(d instanceof JSONObject) || !approved || relayBusy) return;
                String b64 = ((JSONObject) d).optString("d", "");
                if (b64.isEmpty()) return;
                relayBusy = true;
                try {
                    byte[] jpg = android.util.Base64.decode(b64, android.util.Base64.NO_WRAP);
                    Bitmap bm = android.graphics.BitmapFactory.decodeByteArray(jpg, 0, jpg.length);
                    if (bm == null) return;
                    if (!videoOn) {
                        videoOn = true;
                        relayMode = true;
                        MAIN.post(() -> { set("linked"); if (onLinkChange != null) onLinkChange.run(); });
                    }
                    if (frames != null) frames.onFrame(bm);
                } catch (Exception ignored) {
                } finally {
                    relayBusy = false;
                }
            });
        }

        static void stopRelayWatch() {
            if (relay != null) relay.close();
            relay = null;
            relayMode = false;
        }

        static volatile boolean relayMode = false;

        static void onData(JSONObject j) {
            if (j == null) return;
            if ("ok".equals(j.optString("t"))) {
                startRelayWatch();
                approved = true;          // パーティーに参加
                set("linked");
                sendCam();
                sendLive(StreamService.running() && StreamService.instance != null && StreamService.instance.state == 3);
            } else if ("bye".equals(j.optString("t"))) {
                dropSub(false);
            }
        }

        /** 合図はサーバー経由で送る（映像の通り道ができていなくても届く） */
        static void ctl(JSONObject m) {
            if (signal == null || remoteId == null) return;
            try { signal.send("CANDIDATE", remoteId, new JSONObject().put("ctl", m)); } catch (Exception ignored) { }
        }

        static void sendCam() {
            if (!approved) return;
            try { ctl(new JSONObject().put("t", "cam").put("facing", "hand".equals(Parts.mode(ctx)) ? "back" : "front")); } catch (Exception ignored) { }
        }

        static void sendLive(boolean on) {
            if (!approved) return;
            try { ctl(new JSONObject().put("t", "live").put("on", on)); } catch (Exception ignored) { }
        }

        /** ロビーに出す、いまの様子 */
        static String detail() {
            if (!approved) return "";
            if (videoOn) return relayMode ? "（映像OK・中継）" : "（映像OK）";
            if (iceFailed) return "（映像の通り道を作れません。Wi-Fiかモバイル回線を変えてみてください）";
            return "（映像をつないでいます…）";
        }

        /** サブ機の映像（1秒に約12回）を、上向きの絵にして合成に渡す */
        static final VideoSink SINK = frame -> {
            if (!approved) return;
            if (!videoOn) {
                videoOn = true;
                MAIN.post(() -> { set("linked"); if (onLinkChange != null) onLinkChange.run(); });
            }
            if (frames == null || converting) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastFrame < 80) return;
            lastFrame = now;
            converting = true;
            try {
                Bitmap b = toBitmap(frame);
                if (b != null && frames != null) frames.onFrame(b);
            } catch (Exception ignored) {
            } finally {
                converting = false;
            }
        };

        static Bitmap toBitmap(VideoFrame f) {
            VideoFrame.I420Buffer b = f.getBuffer().toI420();
            if (b == null) return null;
            try {
                int w = b.getWidth(), h = b.getHeight();
                int[] argb = new int[w * h];
                ByteBuffer Y = b.getDataY(), U = b.getDataU(), V = b.getDataV();
                int sy = b.getStrideY(), su = b.getStrideU(), sv = b.getStrideV();
                for (int j = 0; j < h; j++) {
                    int yr = j * sy, ur = (j >> 1) * su, vr = (j >> 1) * sv;
                    for (int i = 0; i < w; i++) {
                        int y = (Y.get(yr + i) & 0xff) - 16;
                        int u = (U.get(ur + (i >> 1)) & 0xff) - 128;
                        int v = (V.get(vr + (i >> 1)) & 0xff) - 128;
                        int y1 = 1192 * Math.max(0, y);
                        int r = (y1 + 1634 * v) >> 10, g = (y1 - 833 * v - 400 * u) >> 10, bl = (y1 + 2066 * u) >> 10;
                        r = r < 0 ? 0 : Math.min(255, r);
                        g = g < 0 ? 0 : Math.min(255, g);
                        bl = bl < 0 ? 0 : Math.min(255, bl);
                        argb[j * w + i] = 0xff000000 | (r << 16) | (g << 8) | bl;
                    }
                }
                Bitmap bm = Bitmap.createBitmap(argb, w, h, Bitmap.Config.ARGB_8888);
                int rot = f.getRotation();
                if (rot != 0) {
                    Matrix m = new Matrix();
                    m.postRotate(rot);
                    bm = Bitmap.createBitmap(bm, 0, 0, w, h, m, true);
                }
                return bm;
            } finally {
                b.release();
            }
        }

        /** 配信終了：サブ機との通信を切る（待ち受けは続ける） */
        static void endSub() {
            if (remoteId != null) { try { ctl(new JSONObject().put("t", "end")); } catch (Exception ignored) { } }
            MAIN.postDelayed(() -> dropSub(false), 400);
        }

        static void dropSub(boolean quiet) {
            boolean was = approved && videoOn;
            stopRelayWatch();
            approved = false;
            videoOn = false;
            remoteSet = false;
            try { if (dc != null) { dc.unregisterObserver(); dc.close(); } } catch (Exception ignored) { }
            dc = null;
            try { if (pc != null) pc.close(); } catch (Exception ignored) { }
            pc = null;
            remoteId = null;
            if (!quiet) set(signal != null ? "wait" : "off");
            if (was && onLinkChange != null) onLinkChange.run();
        }

        static void stop() {
            dropSub(true);
            if (signal != null) signal.close();
            signal = null;
            pw = null;
            set("off");
        }
    }

    /* =====================================================
       サブ機：パスワードでメイン機を探して、カメラの映像を送る
       ===================================================== */

    interface SubListener {
        void onStep(String text);
        void onWho(String email, String name);
        void onLocalTrack(VideoTrack t, boolean front);
        void onLinked();
        void onLive(boolean on);
        void onEnd();
        void onFail(String code);
    }

    public static class Sub {
        static Signal signal;
        static PeerConnection pc;
        static DataChannel dc;
        static CameraVideoCapturer capturer;
        static SurfaceTextureHelper helper;
        static VideoSource source;
        static VideoTrack track;
        static String mainId;
        static boolean front = true, remoteSet = false, gotWho = false, closed = true;
        static final List<IceCandidate> pending = new ArrayList<>();
        static SubListener l;
        static volatile boolean iceUp = false, relaying = false, sending = false;
        static long lastSent = 0;
        static String room;

        /** 直接つながらないときは、中継で送る */
        static final VideoSink RELAY = frame -> {
            if (!relaying || sending) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastSent < 200) return;   // 1秒に5枚
            lastSent = now;
            sending = true;
            Bitmap b;
            try { b = Main.toBitmap(frame); } catch (Exception e) { sending = false; return; }
            if (b == null) { sending = false; return; }
            final Bitmap src = b;
            new Thread(() -> {
                try {
                    int w = src.getWidth(), h = src.getHeight();
                    float k = 360f / Math.max(w, h);
                    Bitmap sm = k < 1 ? Bitmap.createScaledBitmap(src, Math.round(w * k), Math.round(h * k), true) : src;
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    sm.compress(Bitmap.CompressFormat.JPEG, 55, bo);
                    String body = new JSONObject().put("d", android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)).toString();
                    if (relaying && room != null) {
                        Request r = new Request.Builder().url(frameUrl(room)).put(okhttp3.RequestBody.create(body, Signal.JSON)).build();
                        try (Response resp = Signal.CLIENT.newCall(r).execute()) { }
                    }
                } catch (Exception ignored) {
                } finally {
                    sending = false;
                }
            }).start();
        };

        static void startRelay() {
            if (relaying || closed || track == null) return;
            relaying = true;
            track.addSink(RELAY);
            if (l != null) l.onStep("relay");
        }

        static void connect(Context c, String password, SubListener listener) {
            close();
            closed = false;
            l = listener;
            Context ctx = c.getApplicationContext();
            initRtc(ctx);
            mainId = peerIdFor(password);
            room = mainId;
            iceUp = false;
            relaying = false;
            gotWho = false;
            remoteSet = false;
            pending.clear();
            String myId = "synccam-sub-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            if (l != null) l.onStep("相手探しのサーバーにつないでいます…");
            signal = new Signal(mainId, myId, new SignalListener() {
                public void onOpen() { if (l != null) l.onStep("メイン機を呼んでいます…"); startOffer(ctx); }
                public void onMessage(JSONObject m) { handle(m); }
                public void onError(String type) { fail("neterr"); }
            });
            signal.connect(false);
            MAIN.postDelayed(() -> { if (!closed && !gotWho) fail("notfound"); }, 20000);
        }

        static void fail(String code) {
            if (closed) return;
            SubListener cb = l;
            close();
            if (cb != null) cb.onFail(code);
        }

        static void startCamera(Context ctx) {
            Camera2Enumerator en = new Camera2Enumerator(ctx);
            String name = null;
            for (String n : en.getDeviceNames()) if (en.isFrontFacing(n) == front) { name = n; break; }
            if (name == null && en.getDeviceNames().length > 0) name = en.getDeviceNames()[0];
            if (name == null) return;
            capturer = en.createCapturer(name, null);
            helper = SurfaceTextureHelper.create("cam", egl.getEglBaseContext());
            source = factory.createVideoSource(false);
            capturer.initialize(helper, ctx, source.getCapturerObserver());
            capturer.startCapture(640, 480, 24);
            track = factory.createVideoTrack("cam0", source);
        }

        static void startOffer(Context ctx) {
            try { startCamera(ctx); } catch (Exception ignored) { }
            pc = factory.createPeerConnection(rtcConfig(), new PcObserver() {
                @Override
                public void onIceCandidate(IceCandidate c) { MAIN.post(() -> { if (signal != null) signal.send("CANDIDATE", mainId, candJson(c)); }); }

                @Override
                public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
                    MAIN.post(() -> {
                        if (l == null) return;
                        if (s == PeerConnection.IceConnectionState.CONNECTED || s == PeerConnection.IceConnectionState.COMPLETED) { iceUp = true; if (!relaying) l.onStep("ok"); }
                        else if (s == PeerConnection.IceConnectionState.FAILED || s == PeerConnection.IceConnectionState.DISCONNECTED) { iceUp = false; startRelay(); }
                    });
                }
            });
            if (pc == null) { fail("neterr"); return; }
            if (track != null) {
                pc.addTrack(track, java.util.Collections.singletonList("s0"));
                if (l != null) l.onLocalTrack(track, front);
            }
            DataChannel.Init init = new DataChannel.Init();
            dc = pc.createDataChannel("ctl", init);
            dc.registerObserver(new DataChannel.Observer() {
                public void onBufferedAmountChange(long x) { }
                public void onStateChange() { }
                public void onMessage(DataChannel.Buffer b) {
                    JSONObject j = readData(b);
                    if (j != null) MAIN.post(() -> onData(ctx, j));
                }
            });
            pc.createOffer(new Sdp() {
                @Override
                public void onCreateSuccess(SessionDescription d) {
                    MAIN.post(() -> {
                        if (pc == null) return;
                        pc.setLocalDescription(new Sdp(), d);
                        try { signal.send("OFFER", mainId, new JSONObject().put("sdp", d.description).put("type", "synccam")); } catch (Exception ignored) { }
                    });
                }
            }, new MediaConstraints());
        }

        static void handle(JSONObject m) {
            String type = m.optString("type");
            JSONObject p = m.optJSONObject("payload");
            if ("EXPIRE".equals(type) || "LEAVE".equals(type)) {
                if (!gotWho) fail("notfound"); else fail("lost");
            } else if ("CANDIDATE".equals(type) && p != null && p.has("ctl")) {
                onData(null, p.optJSONObject("ctl"));
            } else if ("ANSWER".equals(type) && p != null && pc != null) {
                // メイン機から返事。「この人でいいですか？」を出す
                if (!gotWho) {
                    gotWho = true;
                    if (l != null) l.onWho(p.optString("email"), p.optString("name"));
                }
                pc.setRemoteDescription(new Sdp() {
                    @Override
                    public void onSetSuccess() {
                        MAIN.post(() -> {
                            remoteSet = true;
                            for (IceCandidate c : pending) if (pc != null) pc.addIceCandidate(c);
                            pending.clear();
                        });
                    }
                }, new SessionDescription(SessionDescription.Type.ANSWER, p.optString("sdp")));
            } else if ("CANDIDATE".equals(type) && p != null) {
                IceCandidate c = cand(p);
                if (c == null) return;
                if (pc != null && remoteSet) pc.addIceCandidate(c); else pending.add(c);
            }
        }

        static void onData(Context ctx, JSONObject j) {
            if (j == null) return;
            String t = j.optString("t");
            if ("who".equals(t)) {
                gotWho = true;
                if (l != null) l.onWho(j.optString("email"), j.optString("name"));
            } else if ("cam".equals(t)) {
                boolean wantFront = !"back".equals(j.optString("facing"));
                if (wantFront != front && capturer != null) {
                    front = wantFront;
                    capturer.switchCamera(null);
                    if (l != null && track != null) l.onLocalTrack(track, front);
                }
            } else if ("live".equals(t)) {
                if (l != null) l.onLive(j.optBoolean("on"));
            } else if ("end".equals(t)) {
                SubListener cb = l;
                close();
                if (cb != null) cb.onEnd();
            }
        }

        /** 「はい」でパーティーに参加 */
        static void accept() {
            try { signal.send("CANDIDATE", mainId, new JSONObject().put("ctl", new JSONObject().put("t", "ok"))); } catch (Exception ignored) { }
            if (l != null) l.onLinked();
            // 8秒たっても直接つながらなければ、中継に切りかえる
            MAIN.postDelayed(() -> { if (!closed && !iceUp) startRelay(); }, 8000);
        }

        /** 「やり直し」：メイン機に知らせて切る */
        static void decline() {
            try { if (signal != null) signal.send("CANDIDATE", mainId, new JSONObject().put("ctl", new JSONObject().put("t", "bye"))); } catch (Exception ignored) { }
            MAIN.postDelayed(Sub::close, 300);
        }

        static void close() {
            closed = true;
            l = null;
            if (relaying) {
                try { track.removeSink(RELAY); } catch (Exception ignored) { }
                final String u = frameUrl(room);
                new Thread(() -> Signal.http("DELETE", u, null)).start();
            }
            relaying = false;
            try { if (capturer != null) capturer.stopCapture(); } catch (Exception ignored) { }
            try { if (capturer != null) capturer.dispose(); } catch (Exception ignored) { }
            capturer = null;
            try { if (dc != null) { dc.unregisterObserver(); dc.close(); } } catch (Exception ignored) { }
            dc = null;
            try { if (pc != null) pc.close(); } catch (Exception ignored) { }
            pc = null;
            try { if (track != null) track.dispose(); } catch (Exception ignored) { }
            track = null;
            try { if (source != null) source.dispose(); } catch (Exception ignored) { }
            source = null;
            try { if (helper != null) helper.dispose(); } catch (Exception ignored) { }
            helper = null;
            if (signal != null) signal.close();
            signal = null;
            front = true;
        }
    }
}
