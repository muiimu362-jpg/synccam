package jp.synccam.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;

/**
 * マイクラ（統合版）とつなぐ係。
 * マイクラのチャットで「/connect localhost:19131」と打つと、ここにつながる。
 * つながったら、視聴者の妨害を「/scriptevent bougai:tnt 5 sub」のような命令にして送る。
 * （自分のワールドで、チートがONのときだけ使える。Hiveなどのサーバーでは使えない）
 */
public class MinecraftLink {

    static final int PORT = 19131;
    static volatile ServerSocket server;
    static volatile Socket client;
    static volatile OutputStream out;
    static volatile boolean running = false;
    static Runnable onChange;
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    static boolean connected() { return client != null && out != null; }

    /* ---------- 設定 ---------- */

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("synccam", Context.MODE_PRIVATE); }
    static boolean on(Context c) { return sp(c).getBoolean("jamOn", false); }
    static int subTnt(Context c) { return sp(c).getInt("jamSubTnt", 5); }
    static int likeTnt(Context c) { return sp(c).getInt("jamLikeTnt", 1); }
    static int commentEvery(Context c) { return sp(c).getInt("jamCommentEvery", 100); }
    static int commentTnt(Context c) { return sp(c).getInt("jamCommentTnt", 20); }

    /* ---------- 待ち受け ---------- */

    static synchronized void start() {
        if (running) return;
        running = true;
        new Thread(() -> {
            try {
                server = new ServerSocket(PORT, 1, InetAddress.getLoopbackAddress());   // このスマホの中だけ（ほかの人はつなげない）
                while (running) {
                    Socket s = server.accept();
                    handle(s);
                }
            } catch (Exception ignored) {
            } finally {
                running = false;
            }
        }, "mc-link").start();
    }

    static synchronized void stop() {
        running = false;
        try { if (client != null) client.close(); } catch (Exception ignored) { }
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        client = null;
        out = null;
        server = null;
        changed();
    }

    static void changed() { Runnable r = onChange; if (r != null) MAIN.post(r); }

    /** つながってきたマイクラと、WebSocketであいさつする */
    static void handle(Socket s) {
        try {
            InputStream in = s.getInputStream();
            StringBuilder head = new StringBuilder();
            int prev3 = 0, c;
            while ((c = in.read()) != -1) {
                head.append((char) c);
                prev3 = ((prev3 << 8) | c) & 0xffffffff;
                if (prev3 == 0x0d0a0d0a) break;   // 見出しの終わり
                if (head.length() > 8192) throw new Exception("too long");
            }
            String key = null;
            for (String line : head.toString().split("\r\n")) {
                int i = line.indexOf(':');
                if (i > 0 && line.substring(0, i).trim().equalsIgnoreCase("Sec-WebSocket-Key")) key = line.substring(i + 1).trim();
            }
            if (key == null) { s.close(); return; }
            String accept = Base64.encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP);
            OutputStream o = s.getOutputStream();
            o.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "
                    + accept + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            o.flush();
            try { if (client != null) client.close(); } catch (Exception ignored) { }
            client = s;
            out = o;
            changed();
            sendCommand("say §a[SyncCam] つながりました！視聴者の妨害が届きます");
            // マイクラからの返事は読み捨てる（切れたら終わり）
            new Thread(() -> readLoop(s, in), "mc-read").start();
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    static void readLoop(Socket s, InputStream in) {
        try {
            while (true) {
                int b0 = in.read();
                if (b0 == -1) break;
                int b1 = in.read();
                long len = b1 & 0x7f;
                if (len == 126) len = (in.read() << 8) | in.read();
                else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | in.read(); }
                boolean masked = (b1 & 0x80) != 0;
                byte[] mask = new byte[4];
                if (masked) for (int i = 0; i < 4; i++) mask[i] = (byte) in.read();
                for (long i = 0; i < len; i++) if (in.read() == -1) throw new Exception("eof");
                int op = b0 & 0x0f;
                if (op == 8) break;            // 切断
                if (op == 9) pong();           // ping → pong
            }
        } catch (Exception ignored) {
        }
        if (client == s) { client = null; out = null; changed(); }
        try { s.close(); } catch (Exception ignored) { }
    }

    static synchronized void pong() {
        try { if (out != null) { out.write(new byte[]{(byte) 0x8A, 0}); out.flush(); } } catch (Exception ignored) { }
    }

    /** マイクラにコマンドを送る（例：scriptevent bougai:tnt 5 sub） */
    static void sendCommand(String command) {
        new Thread(() -> {
            try {
                JSONObject msg = new JSONObject()
                        .put("header", new JSONObject()
                                .put("version", 1)
                                .put("requestId", UUID.randomUUID().toString())
                                .put("messagePurpose", "commandRequest")
                                .put("messageType", "commandRequest"))
                        .put("body", new JSONObject()
                                .put("version", 1)
                                .put("commandLine", command)
                                .put("origin", new JSONObject().put("type", "player")));
                sendText(msg.toString());
            } catch (Exception ignored) { }
        }).start();
    }

    static synchronized void sendText(String text) throws Exception {
        OutputStream o = out;
        if (o == null) return;
        byte[] p = text.getBytes(StandardCharsets.UTF_8);
        java.io.ByteArrayOutputStream f = new java.io.ByteArrayOutputStream();
        f.write(0x81);
        if (p.length < 126) f.write(p.length);
        else if (p.length < 65536) { f.write(126); f.write(p.length >> 8); f.write(p.length & 0xff); }
        else { f.write(127); for (int i = 7; i >= 0; i--) f.write((int) ((long) p.length >> (8 * i)) & 0xff); }
        f.write(p);
        o.write(f.toByteArray());
        o.flush();
    }

    /* ---------- 妨害 ---------- */

    static void tnt(Context c, int count, String reason) {
        if (!on(c) || count <= 0 || !connected()) return;
        sendCommand("scriptevent bougai:tnt " + Math.min(64, count) + " " + reason);
    }
}
