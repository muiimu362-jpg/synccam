package jp.synccam.game;

import android.accounts.Account;
import android.content.Context;
import android.content.SharedPreferences;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.Tasks;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/** Androidの「アカウントを選択」画面で選んだGoogleアカウントの管理 */
public class Auth {

    static final List<Scope> SCOPES = Arrays.asList(
            new Scope("https://www.googleapis.com/auth/youtube"),
            new Scope("openid"),
            new Scope("email"),
            new Scope("profile"));

    static AuthorizationRequest request(String email) {
        return AuthorizationRequest.builder()
                .setRequestedScopes(SCOPES)
                .setAccount(new Account(email, "com.google"))
                .build();
    }

    /** 画面を出さずにトークンをもらう（裏で使う。メインスレッドでは呼ばない） */
    static String tokenBlocking(Context c, String email) throws Exception {
        AuthorizationResult r;
        try {
            r = Tasks.await(Identity.getAuthorizationClient(c).authorize(request(email)), 30, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            throw new Exception(message(e.getCause()));
        }
        if (r.hasResolution()) throw new Exception("Googleの許可が切れています。アプリを開いて、アカウントを連携し直してください");
        String t = r.getAccessToken();
        if (t == null || t.isEmpty()) throw new Exception("Googleからトークンをもらえませんでした");
        return t;
    }

    static String message(Throwable e) {
        if (e instanceof ApiException) {
            int code = ((ApiException) e).getStatusCode();
            if (code == 10) return "Google Cloudの設定がまだです（Androidのクライアントが登録されていません・コード10）";
            if (code == 16 || code == 12501) return "アカウントの選択をやめました";
            if (code == 7) return "ネットにつながっていません";
            return "Googleにつなげませんでした（コード" + code + "）";
        }
        return e == null ? "Googleにつなげませんでした" : String.valueOf(e.getMessage());
    }

    /* ---------- 連携しているアカウントの一覧（この端末に保存） ---------- */

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("synccam", Context.MODE_PRIVATE);
    }

    static List<JSONObject> accounts(Context c) {
        List<JSONObject> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("accounts", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i));
        } catch (Exception ignored) { }
        return out;
    }

    static void saveAccount(Context c, JSONObject acc) {
        List<JSONObject> list = accounts(c);
        JSONArray a = new JSONArray();
        boolean replaced = false;
        for (JSONObject o : list) {
            if (o.optString("email").equalsIgnoreCase(acc.optString("email"))) { a.put(acc); replaced = true; }
            else a.put(o);
        }
        if (!replaced) a.put(acc);
        sp(c).edit().putString("accounts", a.toString()).apply();
    }

    static void removeAccount(Context c, String email) {
        JSONArray a = new JSONArray();
        for (JSONObject o : accounts(c)) if (!o.optString("email").equalsIgnoreCase(email)) a.put(o);
        sp(c).edit().putString("accounts", a.toString()).apply();
        new java.io.File(c.getFilesDir(), avatarName(email)).delete();
    }

    static String avatarName(String email) {
        return "avatar_" + Integer.toHexString(email.toLowerCase().hashCode()) + ".png";
    }
}
