package jp.synccam.game;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;

import java.nio.ByteBuffer;

/** 動画の切り抜き（元の動画はそのまま。新しいファイルを作る） */
public class Trimmer {

    static long durationMs(String path) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(path);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? 0 : Long.parseLong(d);
        } catch (Exception e) {
            return 0;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    static void trim(String src, String dst, long startMs, long endMs) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(src);
        MediaMuxer mux = new MediaMuxer(dst, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int n = ex.getTrackCount();
        int[] map = new int[n];
        int maxSize = 1024 * 1024;
        boolean any = false;
        for (int i = 0; i < n; i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            map[i] = -1;
            if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/"))) {
                map[i] = mux.addTrack(f);
                ex.selectTrack(i);
                any = true;
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = Math.max(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
                if (mime.startsWith("video/") && f.containsKey("rotation-degrees")) mux.setOrientationHint(f.getInteger("rotation-degrees"));
            }
        }
        if (!any) { ex.release(); mux.release(); throw new Exception("動画を読めませんでした"); }
        mux.start();
        ByteBuffer buf = ByteBuffer.allocate(maxSize);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        long base = -1;
        while (true) {
            int size = ex.readSampleData(buf, 0);
            if (size < 0) break;
            long t = ex.getSampleTime();
            if (t > endMs * 1000) break;
            if (base < 0) base = t;
            int track = ex.getSampleTrackIndex();
            if (track >= 0 && map[track] >= 0) {
                info.offset = 0;
                info.size = size;
                info.presentationTimeUs = Math.max(0, t - base);
                info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                mux.writeSampleData(map[track], buf, info);
            }
            ex.advance();
        }
        mux.stop();
        mux.release();
        ex.release();
    }
}
