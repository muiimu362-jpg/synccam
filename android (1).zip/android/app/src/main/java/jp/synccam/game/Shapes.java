package jp.synccam.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

/** 部品の形：四角・角丸・丸・三角・ハート・星 */
public class Shapes {

    static final String[] KEYS = {"round", "square", "circle", "triangle", "heart", "star"};
    static final String[] NAMES = {"角丸", "四角", "丸", "三角", "ハート", "星"};

    static String name(String key) {
        for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(key)) return NAMES[i];
        return NAMES[0];
    }

    /** w×h の枠いっぱいの形 */
    static Path path(String kind, float w, float h) {
        Path p = new Path();
        if (kind == null) kind = "round";
        switch (kind) {
            case "square":
                p.addRect(0, 0, w, h, Path.Direction.CW);
                break;
            case "circle":
                p.addOval(new RectF(0, 0, w, h), Path.Direction.CW);
                break;
            case "triangle":
                p.moveTo(w / 2f, 0);
                p.lineTo(w, h);
                p.lineTo(0, h);
                p.close();
                break;
            case "heart": {
                p.moveTo(w / 2f, h * 0.25f);
                p.cubicTo(w * 0.5f, h * 0.05f, w * 0.05f, h * -0.05f, w * 0.02f, h * 0.32f);
                p.cubicTo(0, h * 0.62f, w * 0.35f, h * 0.78f, w / 2f, h);
                p.cubicTo(w * 0.65f, h * 0.78f, w, h * 0.62f, w * 0.98f, h * 0.32f);
                p.cubicTo(w * 0.95f, h * -0.05f, w * 0.5f, h * 0.05f, w / 2f, h * 0.25f);
                p.close();
                break;
            }
            case "star": {
                float cx = w / 2f, cy = h / 2f + h * 0.04f;
                float ro = Math.min(w, h) / 2f, ri = ro * 0.45f;
                float sx = w / (2f * ro), sy = h / (2f * ro);
                for (int i = 0; i < 10; i++) {
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    float r = (i % 2 == 0) ? ro : ri;
                    float x = cx + (float) (Math.cos(a) * r) * sx;
                    float y = cy + (float) (Math.sin(a) * r) * sy;
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                break;
            }
            default: {
                float r = Math.min(w, h) * 0.08f;
                p.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
            }
        }
        return p;
    }

    /** 絵を outW×outH に切り抜いて（はみ出す分は真ん中で切る）、形でくりぬく */
    static Bitmap fit(Bitmap src, int outW, int outH, String kind) {
        outW = Math.max(2, outW);
        outH = Math.max(2, outH);
        Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.clipPath(path(kind, outW, outH));
        float a = outW / (float) outH, sa = src.getWidth() / (float) src.getHeight();
        int cw = src.getWidth(), ch = src.getHeight();
        if (sa > a) cw = Math.round(ch * a); else ch = Math.round(cw / a);
        int cx = (src.getWidth() - cw) / 2, cy = (src.getHeight() - ch) / 2;
        c.drawBitmap(src, new Rect(cx, cy, cx + cw, cy + ch), new Rect(0, 0, outW, outH), new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    /** 中身をそのまま縮めて入れる（切らずに全部見せる）。余白は白 */
    static Bitmap contain(Bitmap src, int outW, int outH, String kind, int bg) {
        outW = Math.max(2, outW);
        outH = Math.max(2, outH);
        Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.clipPath(path(kind, outW, outH));
        c.drawColor(bg);
        float s = Math.min(outW / (float) src.getWidth(), outH / (float) src.getHeight());
        float w = src.getWidth() * s, h = src.getHeight() * s;
        c.drawBitmap(src, null, new RectF((outW - w) / 2, (outH - h) / 2, (outW + w) / 2, (outH + h) / 2), new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    /** 形の外側だけ黒くぬった絵（動画など、くりぬけないものの上にかぶせる） */
    static Bitmap outside(int w, int h, String kind) {
        w = Math.max(2, w);
        h = Math.max(2, h);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.BLACK);
        Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
        clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        c.drawPath(path(kind, w, h), clear);
        return out;
    }

    /** 配置の編集で、形の外側を黒くかくす */
    static class Cover extends View {
        String kind;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Cover(Context c, String kind) {
            super(c);
            this.kind = kind;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            setClickable(false);
        }
        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0 || "square".equals(kind)) return;
            Path p = new Path();
            p.addRect(0, 0, w, h, Path.Direction.CW);
            p.op(path(kind, w, h), Path.Op.DIFFERENCE);
            paint.setColor(Color.BLACK);
            c.drawPath(p, paint);
            // 形のふち
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);
            paint.setColor(Color.argb(160, 255, 255, 255));
            c.drawPath(path(kind, w, h), paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }
}
