package jp.synccam.game;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/** 配置の編集で決めた、カメラ枠・字幕・URLの位置と大きさ（画面に対する割合） */
public class Parts {

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("synccam", Context.MODE_PRIVATE);
    }

    static JSONObject defaults() {
        try {
            return new JSONObject()
                    .put("face", new JSONObject().put("x", 0.62).put("y", 0.06).put("w", 0.34).put("h", 0.2))
                    .put("hand", new JSONObject().put("x", 0.62).put("y", 0.06).put("w", 0.34).put("h", 0.2))
                    .put("caption", new JSONObject().put("x", 0.05).put("y", 0.78).put("w", 0.9).put("h", 0.07).put("on", false).put("text", ""))
                    .put("url", new JSONObject().put("x", 0.05).put("y", 0.08).put("w", 0.5).put("h", 0.18).put("on", false).put("src", ""))
                    .put("video", new JSONObject().put("x", 0.05).put("y", 0.3).put("w", 0.45).put("h", 0.14).put("on", false).put("sound", false))
                    .put("photo", new JSONObject().put("x", 0.5).put("y", 0.3).put("w", 0.3).put("h", 0.14).put("on", false));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** ロング（横）のときの最初の置き方：ゲームの邪魔にならない角に小さく */
    static JSONObject defaultsLong() {
        try {
            return new JSONObject()
                    .put("face", new JSONObject().put("x", 0.76).put("y", 0.62).put("w", 0.22).put("h", 0.34))
                    .put("hand", new JSONObject().put("x", 0.76).put("y", 0.62).put("w", 0.22).put("h", 0.34))
                    .put("caption", new JSONObject().put("x", 0.2).put("y", 0.9).put("w", 0.6).put("h", 0.08).put("on", false).put("text", ""))
                    .put("url", new JSONObject().put("x", 0.02).put("y", 0.04).put("w", 0.26).put("h", 0.3).put("on", false).put("src", ""))
                    .put("video", new JSONObject().put("x", 0.02).put("y", 0.62).put("w", 0.22).put("h", 0.34).put("on", false).put("sound", false))
                    .put("photo", new JSONObject().put("x", 0.78).put("y", 0.04).put("w", 0.2).put("h", 0.26).put("on", false));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** "short"（縦・ショート）/ "long"（横・ロング） */
    static String shape(Context c) { return sp(c).getString("liveShape", "short"); }
    static boolean isLong(Context c) { return "long".equals(shape(c)); }
    static void setShape(Context c, String s) { sp(c).edit().putString("liveShape", s).apply(); }
    static String key(Context c) { return isLong(c) ? "layout_long" : "layout"; }

    static JSONObject load(Context c) {
        JSONObject d = isLong(c) ? defaultsLong() : defaults();
        try {
            JSONObject s = new JSONObject(sp(c).getString(key(c), "{}"));
            for (String k : new String[]{"face", "hand", "caption", "url", "video", "photo"}) {
                JSONObject o = s.optJSONObject(k);
                if (o == null) continue;
                JSONObject t = d.getJSONObject(k);
                java.util.Iterator<String> it = o.keys();
                while (it.hasNext()) { String key = it.next(); t.put(key, o.get(key)); }
            }
        } catch (Exception ignored) { }
        return d;
    }

    static void save(Context c, JSONObject l) {
        sp(c).edit().putString(key(c), l.toString()).apply();
    }

    /** "face"（顔出し）/ "hand"（手元）/ ""（カメラなし） */
    static String mode(Context c) { return sp(c).getString("camMode", "face"); }
    static void setMode(Context c, String m) { sp(c).edit().putString("camMode", m).apply(); }

    static boolean snow(Context c) { return sp(c).getBoolean("fxSnow", true); }
    static boolean dog(Context c) { return sp(c).getBoolean("fxDog", false); }
}
