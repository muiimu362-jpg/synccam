package jp.synccam.game;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import com.pedro.encoder.input.audio.CustomAudioEffect;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 配信の音にまぜる係。
 * ・配信音源（BGM）：くり返し流す
 * ・効果音（チャンネル登録・グッド）：1回だけ流す
 * スマホのスピーカーからは鳴らさないので、自分には聞こえず、配信を見ている人だけに聞こえる。
 */
public class BgmMixer extends CustomAudioEffect {

    static final int RATE = 44100;
    final File file;   // BGM（なければ null）
    volatile float vol;
    volatile boolean running = false;

    // BGMを2秒ぶんためておく（左右交互）
    final short[] ring = new short[RATE * 2 * 2];
    int rd = 0, wr = 0, count = 0;
    final Object lock = new Object();

    /** 1回だけ流す音 */
    static class Clip {
        final short[] data;
        final float vol;
        int pos = 0;
        Clip(short[] d, float v) { data = d; vol = v; }
    }
    final List<Clip> clips = new ArrayList<>();

    interface Sink { boolean put(short l, short r) throws InterruptedException; }

    BgmMixer(File file, float vol) {
        this.file = file;
        this.vol = vol;
    }

    void start() {
        running = true;
        if (file != null && file.exists()) new Thread(this::bgmLoop, "bgm").start();
    }

    void stop() {
        running = false;
        synchronized (lock) { lock.notifyAll(); }
    }

    /** 効果音を配信にまぜる（最長 maxMs まで） */
    void addClip(File f, float v, long maxMs) {
        if (!running || f == null || !f.exists()) return;
        new Thread(() -> {
            int max = (int) Math.min(RATE * 2L * 60, RATE * 2L * Math.max(500, maxMs) / 1000);
            short[] buf = new short[Math.min(max, RATE * 2 * 5)];
            int[] n = {0};
            short[][] b = {buf};
            try {
                decodeOnce(f, (l, r) -> {
                    if (n[0] + 2 > max) return false;
                    if (n[0] + 2 > b[0].length) b[0] = java.util.Arrays.copyOf(b[0], Math.min(max, b[0].length * 2));
                    b[0][n[0]++] = l;
                    b[0][n[0]++] = r;
                    return true;
                });
            } catch (Exception ignored) { }
            if (n[0] == 0) return;
            short[] data = java.util.Arrays.copyOf(b[0], n[0]);
            synchronized (lock) { clips.add(new Clip(data, v)); }
        }, "clip").start();
    }

    /** マイクの音（16bit・ステレオ）にBGMと効果音を足す */
    @Override
    public byte[] process(byte[] pcm) {
        if (!running || pcm == null) return pcm;
        float v = vol;
        int n = pcm.length / 2;
        synchronized (lock) {
            for (int i = 0; i < n; i++) {
                int lo = pcm[2 * i] & 0xff, hi = pcm[2 * i + 1];
                float m = (hi << 8) | lo;
                if (count > 0) {
                    m += ring[rd] * v;
                    rd = (rd + 1) % ring.length;
                    count--;
                }
                for (int k = 0; k < clips.size(); k++) {
                    Clip c = clips.get(k);
                    if (c.pos < c.data.length) m += c.data[c.pos++] * c.vol;
                }
                int o = Math.round(m);
                if (o > 32767) o = 32767;
                if (o < -32768) o = -32768;
                pcm[2 * i] = (byte) (o & 0xff);
                pcm[2 * i + 1] = (byte) ((o >> 8) & 0xff);
            }
            for (int k = clips.size() - 1; k >= 0; k--) if (clips.get(k).pos >= clips.get(k).data.length) clips.remove(k);
            lock.notifyAll();
        }
        return pcm;
    }

    boolean push(short l, short r) throws InterruptedException {
        synchronized (lock) {
            while (running && count + 2 > ring.length) lock.wait(50);
            if (!running) return false;
            ring[wr] = l;
            wr = (wr + 1) % ring.length;
            ring[wr] = r;
            wr = (wr + 1) % ring.length;
            count += 2;
            return true;
        }
    }

    void bgmLoop() {
        int fails = 0;
        while (running && fails < 3) {
            boolean ok = false;
            try { ok = decodeOnce(file, this::push); } catch (Exception ignored) { }
            if (ok) fails = 0; else fails++;
        }
    }

    /** ファイルを最初から最後まで、44100Hz・ステレオにして sink に渡す。何か渡せたら true */
    boolean decodeOnce(File f, Sink sink) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec dec = null;
        boolean played = false;
        try {
            ex.setDataSource(f.getPath());
            int track = -1;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; break; }
            }
            if (track < 0) return false;
            ex.selectTrack(track);
            MediaFormat fmt = ex.getTrackFormat(track);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            dec.configure(fmt, null, null, 0);
            dec.start();
            int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : RATE;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            double carry = 0;
            boolean inEnd = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (running) {
                if (!inEnd) {
                    int ii = dec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int sz = ib == null ? -1 : ex.readSampleData(ib, 0);
                        if (sz < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inEnd = true;
                        } else {
                            dec.queueInputBuffer(ii, 0, sz, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = dec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                } else if (oi >= 0) {
                    ByteBuffer ob = dec.getOutputBuffer(oi);
                    boolean stop = false;
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ShortBuffer sb = ob.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
                        short[] in = new short[sb.remaining()];
                        sb.get(in);
                        int c = Math.max(1, ch);
                        int frames = in.length / c;
                        double step = srcRate / (double) RATE;   // 44100に合わせる
                        double pos = carry;
                        while (pos < frames && running) {
                            int i = (int) pos;
                            short l = in[i * c];
                            short r = c > 1 ? in[i * c + 1] : l;
                            if (!sink.put(l, r)) { stop = true; break; }
                            played = true;
                            pos += step;
                        }
                        carry = pos - frames;
                    }
                    dec.releaseOutputBuffer(oi, false);
                    if (stop || (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
        } finally {
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) { }
            try { ex.release(); } catch (Exception ignored) { }
        }
        return played;
    }
}
