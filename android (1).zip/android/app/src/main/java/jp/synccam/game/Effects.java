package jp.synccam.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.Random;

/** 顔に重ねる「雪（白いキラキラの粒）」と「犬（耳と鼻）」を描く */
public class Effects {

    static final float[] PX = new float[260], PY = new float[260], PR = new float[260], PH = new float[260];
    static final Paint DOT = new Paint(Paint.ANTI_ALIAS_FLAG), WHITE = new Paint(Paint.ANTI_ALIAS_FLAG),
            BLACK = new Paint(Paint.ANTI_ALIAS_FLAG), STROKE = new Paint(Paint.ANTI_ALIAS_FLAG);

    static {
        DOT.setColor(Color.WHITE);
        WHITE.setColor(Color.WHITE);
        BLACK.setColor(Color.rgb(25, 25, 25));
        STROKE.setStyle(Paint.Style.STROKE);
        STROKE.setColor(Color.rgb(25, 25, 25));
        Random r = new Random(7);
        for (int i = 0; i < PX.length; i++) {
            double a = r.nextDouble() * Math.PI * 2, d = Math.sqrt(r.nextDouble());
            PX[i] = (float) (Math.cos(a) * d);
            PY[i] = (float) (Math.sin(a) * d);
            PR[i] = 0.004f + r.nextFloat() * 0.012f;
            PH[i] = r.nextFloat() * 6.28f;
        }
    }

    static void snow(Canvas c, RectF f, float t) {
        float cx = f.centerX(), cy = f.centerY() + f.height() * 0.05f;
        float rx = f.width() * 0.55f, ry = f.height() * 0.62f;
        float size = f.width();
        for (int i = 0; i < PX.length; i++) {
            float tw = 0.55f + 0.45f * (float) Math.sin(t * 3 + PH[i]);
            DOT.setAlpha((int) (255 * (0.45f + 0.55f * tw)));
            c.drawCircle(cx + PX[i] * rx, cy + PY[i] * ry, Math.max(1.2f, PR[i] * size * (0.7f + 0.5f * tw)), DOT);
        }
        for (int i = 0; i < 14; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 4 + i * 1.7f);
            DOT.setAlpha((int) (255 * tw));
            star(c, cx + PX[i * 7] * rx, cy + PY[i * 7] * ry, size * 0.025f * (0.6f + tw));
        }
        DOT.setAlpha(255);
    }

    static void star(Canvas c, float x, float y, float s) {
        Path path = new Path();
        for (int i = 0; i < 8; i++) {
            float rr = i % 2 == 0 ? s : s * 0.25f;
            double a = i * Math.PI / 4;
            float xx = x + (float) Math.cos(a) * rr, yy = y + (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
        }
        path.close();
        c.drawPath(path, DOT);
    }

    static void dog(Canvas c, RectF f) {
        float w = f.width();
        STROKE.setStrokeWidth(Math.max(2, w * 0.015f));
        for (int side = -1; side <= 1; side += 2) {
            float ex = f.centerX() + side * w * 0.48f, ey = f.top - w * 0.12f;
            c.save();
            c.rotate(side * 25, ex, ey);
            RectF ear = new RectF(ex - w * 0.2f, ey - w * 0.24f, ex + w * 0.2f, ey + w * 0.24f);
            c.drawOval(ear, WHITE);
            c.drawOval(ear, STROKE);
            c.drawOval(new RectF(ex - w * 0.06f, ey - w * 0.12f, ex + w * 0.05f, ey), BLACK);
            c.drawOval(new RectF(ex - w * 0.02f, ey + w * 0.05f, ex + w * 0.07f, ey + w * 0.14f), BLACK);
            c.restore();
        }
        float nx = f.centerX(), ny = f.top + f.height() * 0.62f;
        c.drawOval(new RectF(nx - w * 0.2f, ny - w * 0.12f, nx + w * 0.2f, ny + w * 0.14f), WHITE);
        Path nose = new Path();
        nose.moveTo(nx - w * 0.08f, ny - w * 0.06f);
        nose.quadTo(nx, ny - w * 0.11f, nx + w * 0.08f, ny - w * 0.06f);
        nose.quadTo(nx + w * 0.04f, ny + w * 0.03f, nx, ny + w * 0.03f);
        nose.quadTo(nx - w * 0.04f, ny + w * 0.03f, nx - w * 0.08f, ny - w * 0.06f);
        c.drawPath(nose, BLACK);
        c.drawRect(nx - w * 0.008f, ny + w * 0.02f, nx + w * 0.008f, ny + w * 0.09f, BLACK);
    }
}
