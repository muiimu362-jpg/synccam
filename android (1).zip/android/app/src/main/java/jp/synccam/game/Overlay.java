package jp.synccam.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.graphics.PathParser;

import java.util.ArrayDeque;

/**
 * 自分の画面に出すのは「黒い丸」と、押したときに横に出るアイコンだけ。
 * （チャットはONにしたときだけ右上に出る。どれも配信の映像には映らないようにする）
 */
public class Overlay {

    interface Listener {
        void onConfirmedGoLive();
        void onPauseToggle(boolean paused);
        void onMicToggle(boolean on);
        void onChatToggle(boolean on);
        void onEnd();
        String busyText();
    }

    static final int WAITING = 1, STARTING = 2, LIVE = 3;

    // アイコン（Material Icons の形）
    static final String CAM = "M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z";
    static final String CAM_OFF = "M21 6.5l-4 4V7c0-.55-.45-1-1-1H9.82L21 17.18V6.5zM3.27 2L2 3.27 4.73 6H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.21 0 .39-.08.54-.18L19.73 21 21 19.73 3.27 2z";
    static final String MIC = "M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z";
    static final String MIC_OFF = "M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17c0-.06.02-.11.02-.17V5c0-1.66-1.34-3-3-3S9 3.34 9 5v.18l5.98 5.99zM4.27 3L3 4.27l6.01 6.01V11c0 1.66 1.33 3 2.99 3 .22 0 .44-.03.65-.08l1.66 1.66c-.71.33-1.5.52-2.31.52-2.76 0-5.3-2.1-5.3-5.1H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c.91-.13 1.77-.45 2.54-.9L19.73 21 21 19.73 4.27 3z";
    static final String CHAT = "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z";
    static final String CHAT_BASE = "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z";

    final Context ctx;
    final WindowManager wm;
    final Listener l;
    final Handler h = new Handler(Looper.getMainLooper());

    LinearLayout win;
    WindowManager.LayoutParams winLp;
    FrameLayout circle;
    View dot;
    LinearLayout panel;
    TextView chatView;
    WindowManager.LayoutParams chatLp;
    boolean chatAdded = false;

    int state = WAITING;
    boolean paused = false, micOn = true, chatOn = false;   // チャットは最初OFF
    final ArrayDeque<String> chatLines = new ArrayDeque<>();

    Overlay(Context c, Listener l) {
        ctx = c;
        this.l = l;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.getResources().getDisplayMetrics()));
    }

    WindowManager.LayoutParams lp(int w, int hgt, int flags) {
        // FLAG_SECURE：自分の画面には見えるが、配信の映像には中身が映らない
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, hgt,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    /** アイコンのボタン */
    class Icon extends View {
        String path;
        boolean slash;
        int bgColor;
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

        Icon(String path, boolean slash, int bg) {
            super(ctx);
            this.path = path;
            this.slash = slash;
            this.bgColor = bg;
            fill.setColor(Color.WHITE);
            line.setColor(Color.WHITE);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            GradientDrawable d = new GradientDrawable();
            d.setColor(bg);
            d.setCornerRadius(dp(12));
            setBackground(d);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()) * 0.58f;
            float ox = (getWidth() - s) / 2f, oy = (getHeight() - s) / 2f;
            Path p = PathParser.createPathFromPathData(path);
            Matrix m = new Matrix();
            m.setScale(s / 24f, s / 24f);
            m.postTranslate(ox, oy);
            p.transform(m);
            c.drawPath(p, fill);
            if (slash) {
                line.setColor(bgColor);
                line.setStrokeWidth(s * 0.2f);
                c.drawLine(ox + s * 0.12f, oy + s * 0.1f, ox + s * 0.9f, oy + s * 0.88f, line);
                line.setColor(Color.WHITE);
                line.setStrokeWidth(s * 0.08f);
                c.drawLine(ox + s * 0.12f, oy + s * 0.1f, ox + s * 0.9f, oy + s * 0.88f, line);
            }
        }
    }

    /** ライブ終了のアイコン（赤い丸の中に四角） */
    class EndIcon extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        EndIcon() {
            super(ctx);
            GradientDrawable d = new GradientDrawable();
            d.setColor(Color.rgb(220, 38, 38));
            d.setCornerRadius(dp(12));
            setBackground(d);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()) * 0.58f;
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.09f);
            c.drawCircle(cx, cy, s * 0.42f, p);
            p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(cx - s * 0.16f, cy - s * 0.16f, cx + s * 0.16f, cy + s * 0.16f, s * 0.04f, s * 0.04f, p);
        }
    }

    /* ================= 表示 ================= */

    void show() {
        circle = new FrameLayout(ctx);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.BLACK);
        bg.setStroke(dp(2), Color.argb(200, 255, 255, 255));
        circle.setBackground(bg);
        dot = new View(ctx);
        circle.addView(dot, new FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER));

        panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(Color.argb(230, 0, 0, 0));
        pbg.setCornerRadius(dp(16));
        panel.setBackground(pbg);
        panel.setVisibility(View.GONE);

        win = new LinearLayout(ctx);
        win.setOrientation(LinearLayout.HORIZONTAL);
        win.setGravity(Gravity.CENTER_VERTICAL);
        win.addView(circle, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pl.leftMargin = dp(6);
        win.addView(panel, pl);

        winLp = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0);
        winLp.x = dp(10);
        winLp.y = dp(140);
        final int[] start = new int[2];
        Drag.attach(circle, this::onTap, new Drag.Listener() {
            public void onStart() { panel.setVisibility(View.GONE); start[0] = winLp.x; start[1] = winLp.y; }
            public void onMove(float dx, float dy) {
                winLp.x = Math.max(0, start[0] + Math.round(dx));
                winLp.y = Math.max(0, start[1] + Math.round(dy));
                try { wm.updateViewLayout(win, winLp); } catch (Exception ignored) { }
            }
            public void onEnd() { }
        });
        wm.addView(win, winLp);

        // 自分の画面のチャット（ONのときだけ）
        chatView = new TextView(ctx);
        chatView.setTextColor(Color.WHITE);
        chatView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        chatView.setShadowLayer(4, 0, 1, Color.BLACK);
        chatView.setMaxLines(3);
        chatView.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable cbg = new GradientDrawable();
        cbg.setColor(Color.argb(90, 0, 0, 0));
        cbg.setCornerRadius(dp(10));
        chatView.setBackground(cbg);
        chatLp = lp(dp(220), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        chatLp.gravity = Gravity.TOP | Gravity.END;
        chatLp.x = dp(8);
        chatLp.y = dp(36);

        setState(WAITING);
    }

    void hide() {
        safeRemove(win);
        if (chatAdded) safeRemove(chatView);
        chatAdded = false;
    }

    void safeRemove(View v) {
        try { if (v != null && v.isAttachedToWindow()) wm.removeView(v); } catch (Exception ignored) { }
    }

    void setState(int s) {
        state = s;
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(s == LIVE ? Color.rgb(239, 68, 68) : s == STARTING ? Color.rgb(250, 204, 21) : Color.rgb(160, 160, 160));
        dot.setBackground(d);
        panel.setVisibility(View.GONE);
        updateChatVisibility();
    }

    void onTap() {
        if (panel.getVisibility() == View.VISIBLE) { panel.setVisibility(View.GONE); return; }
        if (state == WAITING) showConfirm();
        else if (state == LIVE) showMenu();
        else showBusy();
    }

    /* ================= 横に出る中身 ================= */

    static final int GRAY = Color.rgb(55, 55, 55), GREEN = Color.rgb(22, 163, 74), OFF = Color.rgb(127, 29, 29);

    Button btn(String text, int color, View.OnClickListener c) {
        Button b = new Button(ctx);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(12));
        b.setBackground(d);
        b.setOnClickListener(c);
        return b;
    }

    TextView label(String text) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(dp(4), 0, dp(8), 0);
        return t;
    }

    void setPanel(View... views) {
        panel.removeAllViews();
        for (View v : views) {
            boolean icon = v instanceof Icon || v instanceof EndIcon;
            LinearLayout.LayoutParams p = icon ? new LinearLayout.LayoutParams(dp(46), dp(46))
                    : new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.leftMargin = dp(4);
            panel.addView(v, p);
        }
        panel.setVisibility(View.VISIBLE);
    }

    /** 確認は1回だけ。「はい」ですぐ公開 */
    void showConfirm() {
        setPanel(label("配信を開始しますか？"),
                btn("はい", GREEN, v -> { panel.setVisibility(View.GONE); l.onConfirmedGoLive(); }),
                btn("キャンセル", GRAY, v -> panel.setVisibility(View.GONE)));
    }

    void showMenu() {
        Icon cam = new Icon(paused ? CAM_OFF : CAM, false, paused ? OFF : GRAY);
        cam.setOnClickListener(v -> { paused = !paused; l.onPauseToggle(paused); showMenu(); });
        Icon mic = new Icon(micOn ? MIC : MIC_OFF, false, micOn ? GRAY : OFF);
        mic.setOnClickListener(v -> { micOn = !micOn; l.onMicToggle(micOn); showMenu(); });
        Icon chat = new Icon(chatOn ? CHAT : CHAT_BASE, !chatOn, chatOn ? GRAY : OFF);
        chat.setOnClickListener(v -> { chatOn = !chatOn; updateChatVisibility(); l.onChatToggle(chatOn); showMenu(); });
        EndIcon end = new EndIcon();
        end.setOnClickListener(v -> showEndConfirm());
        setPanel(cam, mic, chat, end);
    }

    /** 準備中でも、いつでも終われるようにする */
    void showBusy() {
        EndIcon end = new EndIcon();
        end.setOnClickListener(v -> showEndConfirm());
        setPanel(label(l.busyText()), end);
    }

    void showEndConfirm() {
        setPanel(label(state == LIVE ? "ライブを終了しますか？" : "配信をやめますか？"),
                btn("はい", Color.rgb(220, 38, 38), v -> { panel.setVisibility(View.GONE); l.onEnd(); }),
                btn("キャンセル", GRAY, v -> { if (state == LIVE) showMenu(); else panel.setVisibility(View.GONE); }));
    }

    /* ================= 自分の画面のチャット ================= */

    void addChat(String line) {
        chatLines.addFirst(line);
        while (chatLines.size() > 3) chatLines.removeLast();
        StringBuilder sb = new StringBuilder();
        for (String s : chatLines) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s.length() > 40 ? s.substring(0, 40) + "…" : s);
        }
        chatView.setText(sb.toString());
        updateChatVisibility();
    }

    void updateChatVisibility() {
        boolean want = chatOn && state == LIVE && !chatLines.isEmpty();
        if (want && !chatAdded) {
            try { wm.addView(chatView, chatLp); chatAdded = true; } catch (Exception ignored) { }
        } else if (!want && chatAdded) {
            safeRemove(chatView);
            chatAdded = false;
        }
    }
}
