package jp.synccam.game;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 画面：起動直後 → ロビー（黒） → Google／ライブの効果音／配信せってい */
public class MainActivity extends Activity {

    static final int REQ_CAPTURE = 100, REQ_PERM = 101, REQ_PICK = 102, REQ_AUTH = 103, REQ_FILE = 104, REQ_SUBCAM = 105;
    static final String RELEASE_URL = "https://github.com/muiimu362-jpg/synccam/releases/latest";

    static final String[] CAT_NAMES = {"ゲーム", "エンターテイメント", "ブログ", "音楽", "コメディー", "ハウツーとスタイル", "教育", "科学と技術", "スポーツ", "ペットと動物", "旅行とイベント", "映画とアニメ"};
    static final String[] CAT_IDS = {"20", "24", "22", "10", "23", "26", "27", "28", "17", "15", "19", "1"};
    static final String[] GAMES = {"なし",
            // 人気のゲーム
            "フォートナイト", "マインクラフト", "ONE PIECE バウンティラッシュ", "荒野行動", "Apex Legends", "PUBG MOBILE", "Call of Duty: Mobile",
            "VALORANT", "ブロスタ（Brawl Stars）", "クラッシュ・ロワイヤル", "ロブロックス（Roblox）", "Among Us", "第五人格",
            "ポケモンGO", "ポケモンユナイト", "ポケポケ", "モンスターストライク", "パズル＆ドラゴンズ", "原神", "崩壊：スターレイル",
            "ゼンレスゾーンゼロ", "ウマ娘", "プロジェクトセカイ", "ブルーアーカイブ", "Fate/Grand Order", "ドラゴンクエストウォーク",
            "白猫プロジェクト", "遊戯王 マスターデュエル", "雀魂", "スプラトゥーン", "大乱闘スマッシュブラザーズ", "マリオカート",
            "グランツーリスモ", "eFootball", "プロスピA", "ストリートファイター",
            // ジャンル
            "アクション", "RPG", "シューティング", "バトルロイヤル", "パズル", "スポーツ", "レース", "音楽・リズム",
            "シミュレーション", "ホラー", "格闘", "アドベンチャー", "カードゲーム", "その他"};

    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newSingleThreadExecutor();
    SharedPreferences sp;
    FrameLayout root;
    String screen = "start";

    // 認証の途中で覚えておくこと
    String pendingEmail = null;
    boolean pendingForStream = false;
    String streamEmail = null, streamToken = null;
    String pickTarget = null;   // どのファイルを選んでいるか
    MediaPlayer tester;

    int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("synccam", MODE_PRIVATE);
        installCrashReporter();
        getWindow().setStatusBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        show(StreamService.running() ? "lobby" : "start");
        handleShare(getIntent());
        handleCapture(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
        handleCapture(intent);
    }

    /** ほかのアプリの「共有」から来たもの */
    void handleShare(Intent in) {
        if (in == null || !Intent.ACTION_SEND.equals(in.getAction())) return;
        Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
        in.setAction(null);   // 2回処理しないように
        if (u != null) {
            soundCb = null;
            String name = displayName(u);
            AlertDialog wait = new AlertDialog.Builder(this).setMessage("音を読みこんでいます…").setCancelable(false).show();
            new Thread(() -> {
                String err = null;
                SoundLib.Item it = null;
                try { it = SoundLib.importUri(this, u, name); } catch (Exception e) { err = e.getMessage(); }
                SoundLib.Item done = it;
                String er = err;
                main.post(() -> {
                    try { wait.dismiss(); } catch (Exception ignored) { }
                    if (done == null) { toast("読み込めませんでした：" + er); return; }
                    new AlertDialog.Builder(this).setTitle("保存しました")
                            .setMessage("「" + done.name + "」を「保存した音源」に入れました。\n効果音・配信音源・動画編集の音を選ぶときに使えます。")
                            .setPositiveButton("OK", null).show();
                });
            }).start();
            return;
        }
        String text = in.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null) {
            new AlertDialog.Builder(this).setTitle("リンクからは保存できません")
                    .setMessage("TikTokなどのリンクから音を取り出すことはできません。\n\n"
                            + "代わりに、TikTokで「動画を保存」した動画を、写真（ギャラリー）アプリから「共有」→「SyncCam」で送ってください。音だけ「保存した音源」に入ります。")
                    .setPositiveButton("OK", null).show();
        }
    }

    /** アプリが落ちたら理由を保存して、次に開いたときに見せる（直すときに使う） */
    void installCrashReporter() {
        Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        android.content.SharedPreferences cp = getSharedPreferences("synccam", MODE_PRIVATE);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                java.io.StringWriter w = new java.io.StringWriter();
                e.printStackTrace(new java.io.PrintWriter(w));
                String txt = "v" + BuildConfigVersion() + "\n" + w;
                if (txt.length() > 3000) txt = txt.substring(0, 3000);
                cp.edit().putString("lastCrash", txt).commit();
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
        String crash = cp.getString("lastCrash", null);
        if (crash != null) {
            cp.edit().remove("lastCrash").apply();
            TextView tv = new TextView(this);
            tv.setText(crash);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            tv.setTextIsSelectable(true);
            tv.setPadding(dp(16), dp(8), dp(16), dp(8));
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new AlertDialog.Builder(this).setTitle("前回アプリが落ちました")
                    .setMessage("この画面の写真を送ってもらえれば直せます。")
                    .setView(sv)
                    .setPositiveButton("OK", null)
                    .setNeutralButton("コピー", (d, w) -> {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", crash));
                        toast("コピーしました");
                    }).show();
        }
    }

    String BuildConfigVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if ("editor".equals(screen) && bgmPreview == null) startBgmPreview();
        if (!"settings".equals(screen) && !"clip".equals(screen) && !"editor".equals(screen)
                && !"subview".equals(screen) && !"subwait".equals(screen) && !"subpw".equals(screen)) show(screen);
        String msg = sp.getString("lastMessage", null);
        if (msg != null) {
            sp.edit().remove("lastMessage").apply();
            new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTester();
        stopBgmPreview();
        if (cut != null) cut.pause();
    }

    @Override
    public void onBackPressed() {
        switch (screen) {
            case "lobby": show("start"); break;
            case "google": case "sounds": case "settings": case "history": show("lobby"); break;
            case "editor": show("settings"); break;
            case "clip":
                if (cut != null && cut.dirty()) {
                    new AlertDialog.Builder(this).setMessage("編集をやめますか？（保存していない変更は消えます）")
                            .setPositiveButton("やめる", (d, w) -> show("history"))
                            .setNegativeButton("続ける", null).show();
                } else show("history");
                break;
            case "subpw": show("start"); break;
            case "subwait": Link.Sub.close(); show("start"); break;
            case "subview": toast("サブ機は操作できません。メイン機がライブを終了すると自動で切れます"); break;
            default: super.onBackPressed();
        }
    }

    void show(String s) {
        if ("settings".equals(screen) && !"settings".equals(s)) saveSettingsFields();
        if ("subview".equals(screen) && !"subview".equals(s)) releaseSubView();
        if ("clip".equals(screen) && clipView != null) { try { clipView.stopPlayback(); } catch (Exception ignored) { } clipView = null; }
        if (cut != null) { cut.release(); cut = null; }
        if ("editor".equals(screen) && !"editor".equals(s)) releaseEditorWebs();
        screen = s;
        root.removeAllViews();
        View v;
        switch (s) {
            case "lobby": v = lobbyScreen(); break;
            case "google": v = googleScreen(); break;
            case "sounds": v = soundsScreen(); break;
            case "settings": v = settingsScreen(); break;
            case "editor": v = editorScreen(); break;
            case "history": v = historyScreen(); break;
            case "clip":
                if (clipFile == null || !clipFile.exists()) { v = clipScreen(); break; }
                cut = new CutEditor(this, clipFile);
                v = cut.view;
                break;
            case "subpw": v = subPwScreen(); break;
            case "subwait": v = subWaitScreen(); break;
            case "subview": v = subViewScreen(); break;
            default: v = startScreen();
        }
        root.addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // 配置の編集の画面にいるあいだだけ、配信音源を自分のスマホでも流す（音の大きさを確かめるため）
        if ("editor".equals(s)) { startingStream = false; startBgmPreview(); } else stopBgmPreview();
    }

    /* ================= 配信音源の試し聞き（配置の編集の画面だけ） ================= */

    android.media.MediaPlayer bgmPreview;
    android.media.audiofx.LoudnessEnhancer bgmBoost;

    void startBgmPreview() {
        stopBgmPreview();
        File f = new File(getFilesDir(), "bgm");
        if (!sp.getBoolean("bgmOn", false) || !f.exists() || startingStream || StreamService.instance != null) return;
        playBgmPreview(f);
    }

    void playBgmPreview(File f) {
        stopBgmPreview();
        try {
            bgmPreview = new android.media.MediaPlayer();
            bgmPreview.setDataSource(f.getPath());
            bgmPreview.setLooping(true);
            bgmPreview.prepare();
            try { bgmBoost = new android.media.audiofx.LoudnessEnhancer(bgmPreview.getAudioSessionId()); } catch (Throwable ignored) { bgmBoost = null; }
            applyBgmPreviewVol(sp.getInt("bgmVol", 50));
            bgmPreview.start();
        } catch (Exception e) {
            stopBgmPreview();
        }
    }

    /** 0〜200%。100%より大きいときは、音を持ち上げる仕組みで大きくする（配信と同じくらいに聞こえる） */
    void applyBgmPreviewVol(int pct) {
        if (bgmPreview == null) return;
        try {
            float v = Math.min(1f, pct / 100f);
            bgmPreview.setVolume(v, v);
            if (bgmBoost != null) {
                if (pct > 100) {
                    bgmBoost.setTargetGain((int) Math.round(2000 * Math.log10(pct / 100.0)));
                    bgmBoost.setEnabled(true);
                } else {
                    bgmBoost.setEnabled(false);
                }
            }
        } catch (Exception ignored) { }
    }

    void stopBgmPreview() {
        try { if (bgmBoost != null) bgmBoost.release(); } catch (Exception ignored) { }
        bgmBoost = null;
        try { if (bgmPreview != null) { bgmPreview.stop(); bgmPreview.release(); } } catch (Exception ignored) { }
        bgmPreview = null;
    }

    /* ================= 見た目の部品 ================= */

    static final int GRAY = Color.rgb(154, 167, 160), PANEL = Color.rgb(21, 26, 23), LINE = Color.rgb(44, 53, 48), GREEN = Color.rgb(34, 197, 94), RED = Color.rgb(239, 68, 68);

    GradientDrawable round(int color, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(r));
        return d;
    }

    Button button(String text, int bg, int fg) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextColor(fg);
        bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bt.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable d = round(bg, 14);
        if (bg == PANEL) d.setStroke(dp(1), LINE);
        bt.setBackground(d);
        bt.setPadding(dp(16), dp(12), dp(16), dp(12));
        bt.setStateListAnimator(null);
        return bt;
    }

    EditText edit(String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(110, 120, 115));
        e.setBackground(round(PANEL, 12));
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        return e;
    }

    TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        t.setTextColor(color);
        return t;
    }

    void add(LinearLayout parent, View v, int topMargin) {
        add(parent, v, topMargin, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    void add(LinearLayout parent, View v, int topMargin, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
        p.topMargin = dp(topMargin);
        parent.addView(v, p);
    }

    /** 戻る＋タイトルの見出しと、スクロールする中身 */
    LinearLayout page(String title, LinearLayout[] bodyOut) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        FrameLayout head = new FrameLayout(this);
        head.setPadding(dp(12), dp(12), dp(12), dp(12));
        Button back = button("戻る", Color.rgb(34, 43, 38), Color.WHITE);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        back.setPadding(dp(14), dp(6), dp(14), dp(6));
        back.setOnClickListener(v -> onBackPressed());
        head.addView(back, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START | Gravity.CENTER_VERTICAL));
        TextView t = text(title, 18, Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        outer.addView(head);
        View line = new View(this);
        line.setBackgroundColor(LINE);
        outer.addView(line, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(8), dp(18), dp(28));
        sv.addView(body);
        outer.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        bodyOut[0] = body;
        return outer;
    }

    /** 白い丸。中にアカウントのアイコン（なければ白いまま） */
    FrameLayout avatar(String email, int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.WHITE);
        f.setBackground(bg);
        f.setClipToOutline(true);
        if (email != null) {
            File file = new File(getFilesDir(), Auth.avatarName(email));
            Bitmap bm = file.exists() ? BitmapFactory.decodeFile(file.getPath()) : null;
            if (bm != null) {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(bm);
                f.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            } else {
                TextView t = text(email.substring(0, 1).toUpperCase(), sizeDp * 0.45f, Color.rgb(17, 17, 17));
                t.setGravity(Gravity.CENTER);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                f.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        return f;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    /* ================= ① 起動直後 ================= */

    View startScreen() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(24), dp(24), dp(24), dp(24));
        TextView logo = text("SyncCam", 34, Color.WHITE);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        add(v, logo, 0);
        TextView sub = text("シンクカム", 13, GRAY);
        sub.setGravity(Gravity.CENTER);
        add(v, sub, 2);
        Button b1 = button("【1】配信者\n（メイン機）", GREEN, Color.rgb(4, 33, 15));
        b1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21);
        b1.setOnClickListener(x -> show("lobby"));
        add(v, b1, 28, dp(120));
        Button b2 = button("【2】手元・顔出し用\n（サブ機）", Color.WHITE, Color.rgb(17, 17, 17));
        b2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21);
        b2.setOnClickListener(x -> {
            String saved = sp.getString("subPw", "");
            if (!saved.isEmpty()) subConnect(saved, true);   // 同じパスワードなら、押した瞬間につなぐ
            else show("subpw");
        });
        add(v, b2, 18, dp(120));
        return v;
    }

    /* ================= ② ロビー（黒い背景） ================= */

    View lobbyScreen() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.BLACK);

        // 上の段：左「アプリ共有」、右「白い丸＋パスワード＋完了」
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10), dp(14), dp(10), 0);
        Button share = button("アプリ共有", Color.rgb(34, 43, 38), Color.WHITE);
        share.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        share.setPadding(dp(10), dp(6), dp(10), dp(6));
        share.setOnClickListener(x -> shareApp());
        top.addView(share);
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        FrameLayout av = avatar(current(), 40);
        av.setOnClickListener(x -> show("google"));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(40), dp(40));
        ap.rightMargin = dp(6);
        top.addView(av, ap);
        EditText pw = new EditText(this);
        pw.setSingleLine(true);
        pw.setHint("パスワード");
        pw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        pw.setTextColor(Color.WHITE);
        pw.setHintTextColor(Color.rgb(110, 120, 115));
        pw.setPadding(dp(8), 0, dp(8), 0);
        String saved = sp.getString("mainPw", "");
        pw.setText(saved);
        boolean locked = !saved.isEmpty();
        pw.setEnabled(!locked);
        GradientDrawable pwbg = round(Color.rgb(17, 17, 17), 10);
        pwbg.setStroke(dp(1), locked ? GREEN : LINE);
        pw.setBackground(pwbg);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(104), dp(38));
        pp.rightMargin = dp(6);
        top.addView(pw, pp);
        Button ok = button(locked ? "変更" : "完了", GREEN, Color.rgb(4, 33, 15));
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        ok.setPadding(dp(10), dp(6), dp(10), dp(6));
        ok.setOnClickListener(x -> {
            if (!pw.isEnabled()) { pw.setEnabled(true); pw.requestFocus(); ok.setText("完了"); return; }
            String n = Normalizer.normalize(pw.getText().toString(), Normalizer.Form.NFKC).replaceAll("[\\s　]+", " ").trim();
            if (n.isEmpty()) { toast("パスワードを入力してください"); return; }
            sp.edit().putString("mainPw", n).apply();
            Link.Main.start(this, n);
            toast("パスワードを決めました。サブ機で同じパスワードを入れるとつながります");
            show("lobby");
        });
        top.addView(ok);
        f.addView(top, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // サブ機の状態（パスワードを決めると待ち受ける）
        if (!saved.isEmpty() && !saved.equals(Link.Main.pw)) Link.Main.start(this, saved);
        TextView ls = text(linkText(), 11, Color.WHITE);
        ls.setPadding(dp(10), dp(4), dp(10), dp(4));
        ls.setBackground(round("linked".equals(Link.Main.status) ? Color.argb(230, 34, 197, 94) : Color.rgb(26, 31, 28), 999));
        FrameLayout.LayoutParams lsp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        lsp.topMargin = dp(62);
        lsp.rightMargin = dp(10);
        f.addView(ls, lsp);
        Link.Main.onChange = () -> { if ("lobby".equals(screen)) show("lobby"); };

        // 真ん中のボタン（前と同じ並び＋ライブの効果音）
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(30), 0, dp(30), 0);
        String mode = Parts.mode(this);
        Button hist = button("履歴", PANEL, Color.WHITE);
        hist.setOnClickListener(x -> show("history"));
        add(c, hist, 0, dp(52));
        Button face = button("顔出し", "face".equals(mode) ? GREEN : PANEL, "face".equals(mode) ? Color.rgb(4, 33, 15) : Color.WHITE);
        face.setOnClickListener(x -> { Parts.setMode(this, "face".equals(Parts.mode(this)) ? "" : "face"); Link.Main.sendCam(); show("lobby"); });
        add(c, face, 10, dp(52));
        Button hand = button("手元", "hand".equals(mode) ? GREEN : PANEL, "hand".equals(mode) ? Color.rgb(4, 33, 15) : Color.WHITE);
        hand.setOnClickListener(x -> { Parts.setMode(this, "hand".equals(Parts.mode(this)) ? "" : "hand"); Link.Main.sendCam(); show("lobby"); });
        add(c, hand, 10, dp(52));
        Button fx = button("顔エフェクト", PANEL, Color.WHITE);
        fx.setOnClickListener(x -> openEffects());
        add(c, fx, 10, dp(52));
        Button sounds = button("ライブの効果音", PANEL, Color.WHITE);
        sounds.setOnClickListener(x -> show("sounds"));
        add(c, sounds, 10, dp(52));
        Button google = button("Google", PANEL, Color.WHITE);
        google.setOnClickListener(x -> show("google"));
        add(c, google, 10, dp(52));
        Button start = button("配信スタート", RED, Color.WHITE);
        start.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        start.setOnClickListener(x -> startPressed());
        add(c, start, 10, dp(60));
        if (StreamService.running()) {
            start.setEnabled(false);
            start.setAlpha(0.5f);
            TextView st = text("配信中です。ゲームの上の黒い丸から操作してください", 13, GRAY);
            st.setGravity(Gravity.CENTER);
            add(c, st, 12);
        }
        // 緊急停止：アプリやYouTubeに残っている配信を、強制的に全部終わらせる
        Button stop = button("⛔ 緊急停止", Color.BLACK, RED);
        GradientDrawable sb = round(Color.BLACK, 14);
        sb.setStroke(dp(2), RED);
        stop.setBackground(sb);
        stop.setOnClickListener(x -> new AlertDialog.Builder(this)
                .setTitle("緊急停止")
                .setMessage("配信を強制的に終了しますか？\n（連携しているアカウントで、ライブ中・準備中になっている配信を全部終わらせます）")
                .setPositiveButton("はい", (d, w) -> emergencyStop())
                .setNegativeButton("キャンセル", null).show());
        add(c, stop, 18, dp(50));
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(0, dp(76), 0, dp(20));
        holder.addView(c, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        sv.addView(holder);
        f.addView(sv, 0, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        return f;
    }

    void shareApp() {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "SyncCam Game（Androidアプリ）\n" + RELEASE_URL + "\nここの SyncCamGame.apk をダウンロードしてインストールしてください。");
        startActivity(Intent.createChooser(i, "アプリを共有"));
    }

    /* ================= ③ Google（アカウントの連携） ================= */

    String current() {
        List<JSONObject> list = Auth.accounts(this);
        String cur = sp.getString("current", "");
        for (JSONObject o : list) if (o.optString("email").equalsIgnoreCase(cur)) return o.optString("email");
        return list.isEmpty() ? null : list.get(0).optString("email");
    }

    View googleScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("Googleアカウント", b);
        LinearLayout body = b[0];
        List<JSONObject> list = Auth.accounts(this);
        String cur = current();
        add(body, text("連携しているアカウント（タップで配信に使うアカウントにする）", 12, GRAY), 10);
        if (list.isEmpty()) add(body, text("まだありません。下のボタンから連携してください。", 14, GRAY), 10);
        for (int i = 0; i < list.size(); i++) {
            JSONObject o = list.get(i);
            String email = o.optString("email");
            boolean isCur = email.equalsIgnoreCase(cur);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable bg = round(PANEL, 12);
            bg.setStroke(dp(isCur ? 2 : 1), isCur ? GREEN : LINE);
            row.setBackground(bg);
            row.addView(avatar(email, 40), new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), 0, 0, 0);
            col.addView(text((i + 1) + "アカウント目" + (isCur ? "（配信に使う）" : ""), 11, isCur ? GREEN : GRAY));
            String name = o.optString("channel");
            if (name.isEmpty()) name = o.optString("name");
            if (!name.isEmpty()) col.addView(text(name, 15, Color.WHITE));
            col.addView(text(email, 13, Color.rgb(200, 210, 205)));
            row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            row.setOnClickListener(v -> { sp.edit().putString("current", email).apply(); show("google"); toast(email + " を配信に使います"); });
            row.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("連携を外しますか？").setMessage(email)
                        .setPositiveButton("外す", (d, w) -> { Auth.removeAccount(this, email); show("google"); })
                        .setNegativeButton("やめる", null).show();
                return true;
            });
            add(body, row, 8);
        }
        Button addBtn = button("＋ Googleアカウントを追加", Color.WHITE, Color.BLACK);
        addBtn.setOnClickListener(v -> pickAccount());
        add(body, addBtn, 16);
        if (!list.isEmpty()) add(body, text("アカウントを長押しすると、連携を外せます", 12, GRAY), 10);
        return pageView;
    }

    void pickAccount() {
        Intent i = AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null);
        try { startActivityForResult(i, REQ_PICK); }
        catch (Exception e) { toast("アカウントの選択画面を開けませんでした"); }
    }

    void onPicked(String email) {
        new AlertDialog.Builder(this)
                .setTitle("このアカウントを連携しますか？")
                .setMessage(email)
                .setPositiveButton("はい", (d, w) -> authorize(email, false))
                .setNegativeButton("やり直し", (d, w) -> pickAccount())
                .show();
    }

    /** Googleに「YouTubeを操作していいか」を許可してもらう（初回だけ確認画面が出る） */
    void authorize(String email, boolean forStream) {
        pendingEmail = email;
        pendingForStream = forStream;
        Identity.getAuthorizationClient(this).authorize(Auth.request(email))
                .addOnSuccessListener(r -> {
                    if (r.hasResolution()) {
                        try {
                            startIntentSenderForResult(r.getPendingIntent().getIntentSender(), REQ_AUTH, null, 0, 0, 0);
                        } catch (IntentSender.SendIntentException e) {
                            toast("Googleの許可画面を開けませんでした");
                        }
                    } else {
                        onAuthorized(email, r.getAccessToken(), forStream);
                    }
                })
                .addOnFailureListener(e -> showError(Auth.message(e)));
    }

    void onAuthorized(String email, String token, boolean forStream) {
        if (forStream) {
            streamEmail = email;
            streamToken = token;
            show("settings");
            return;
        }
        toast("連携しています…");
        io.execute(() -> {
            try {
                YouTube yt = new YouTube(this, email);
                yt.setToken(token);
                JSONObject acc = yt.loadProfile();
                Auth.saveAccount(this, acc);
                sp.edit().putString("current", email).apply();
                main.post(() -> { show(screen); toast(email + " を連携しました"); });
            } catch (Exception e) {
                main.post(() -> showError("アカウント情報を読み込めませんでした：" + e.getMessage()));
            }
        });
    }

    void showError(String m) {
        new AlertDialog.Builder(this).setTitle("うまくいきませんでした").setMessage(m).setPositiveButton("OK", null).show();
    }

    interface Picked { void on(String email); }

    void chooseAccountDialog(String title, Picked cb) {
        List<JSONObject> list = Auth.accounts(this);
        String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            JSONObject o = list.get(i);
            String name = o.optString("channel");
            if (name.isEmpty()) name = o.optString("name");
            items[i] = (i + 1) + "アカウント目：" + (name.isEmpty() ? "" : name + "\n") + o.optString("email");
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(items, (d, which) -> cb.on(list.get(which).optString("email")))
                .setNegativeButton("キャンセル", null)
                .show();
    }

    /* ================= ④ ライブの効果音 ================= */

    View soundsScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("ライブの効果音", b);
        LinearLayout body = b[0];
        add(body, sectionTitle("⭐ チャンネル登録されたとき"), 14);
        add(body, slotRow("subImg", "subSnd"), 8);
        alertSliders(body, "sub");

        add(body, sectionTitle("👍 グッドされたとき"), 28);
        add(body, slotRow("likeImg", "likeSnd"), 8);
        alertSliders(body, "like");

        add(body, text("「写真」を押すとスマホの写真一覧、「効果音」を押すとファイル選択が開きます。長押しで外せます。\n効果音はスマホのスピーカーから鳴り、マイクが拾って配信にも入ります（イヤホンをつけていると配信には入りません）。\nチャンネル登録は、登録者の数が増えたときに流れます（YouTube側の更新で少し遅れることがあります）。", 12, GRAY), 18);
        return pageView;
    }

    /** 「写真を出す時間」と「効果音の音量」（チャンネル登録・グッドで別々） */
    void alertSliders(LinearLayout body, String kind) {
        int sec = alertSec(sp, kind);
        TextView secT = text("写真を出す時間：" + sec + "秒", 14, Color.WHITE);
        SeekBar secBar = new SeekBar(this);
        secBar.setMax(29);   // 1〜30秒
        secBar.setProgress(sec - 1);
        secBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { secT.setText("写真を出す時間：" + (p + 1) + "秒"); sp.edit().putInt(kind + "Sec", p + 1).apply(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        add(body, secT, 10);
        add(body, secBar, 2);

        int vol = alertVol(sp, kind);
        TextView volT = text("効果音の音量：" + vol + "%", 14, Color.WHITE);
        SeekBar volBar = new SeekBar(this);
        volBar.setMax(100);
        volBar.setProgress(vol);
        volBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { volT.setText("効果音の音量：" + p + "%"); sp.edit().putInt(kind + "Vol", p).apply(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        add(body, volT, 8);
        add(body, volBar, 2);
    }

    static int alertSec(android.content.SharedPreferences p, String kind) { return p.getInt(kind + "Sec", p.getInt("alertSec", 4)); }
    static int alertVol(android.content.SharedPreferences p, String kind) { return p.getInt(kind + "Vol", p.getInt("alertVol", 80)); }

    TextView sectionTitle(String s) {
        TextView t = text(s, 14, Color.rgb(167, 243, 208));
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout slotRow(String imgKey, String sndKey) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(116), 1);
        row.addView(imageSlot(imgKey, "写真を選ぶ\n（写真一覧が開く）"), lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(116), 1);
        lp2.leftMargin = dp(10);
        row.addView(soundSlot(sndKey), lp2);
        return row;
    }

    View slotFrame(boolean set) {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.setGravity(Gravity.CENTER);
        s.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable d = round(set ? Color.argb(20, 34, 197, 94) : Color.TRANSPARENT, 12);
        d.setStroke(dp(2), set ? GREEN : Color.rgb(61, 74, 67), dp(6), dp(4));
        s.setBackground(d);
        return s;
    }

    View imageSlot(String key, String emptyLabel) {
        File f = new File(getFilesDir(), key);
        boolean set = f.exists();
        LinearLayout s = (LinearLayout) slotFrame(set);
        if (set) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(decodeSampled(f, 300));
            iv.setBackground(round(Color.BLACK, 10));
            iv.setClipToOutline(true);
            s.addView(iv, new LinearLayout.LayoutParams(dp(64), dp(64)));
            TextView t = text("写真（変更）", 12, Color.rgb(207, 216, 211));
            t.setGravity(Gravity.CENTER);
            s.addView(t);
        } else {
            TextView p = text("＋", 28, GRAY);
            p.setGravity(Gravity.CENTER);
            s.addView(p);
            TextView t = text(emptyLabel, 12, Color.rgb(207, 216, 211));
            t.setGravity(Gravity.CENTER);
            s.addView(t);
        }
        s.setOnClickListener(v -> pickImage(key));
        s.setOnLongClickListener(v -> { if (f.exists()) confirmRemove(f, null); return true; });
        return s;
    }

    View soundSlot(String key) {
        File f = new File(getFilesDir(), key);
        boolean set = f.exists();
        LinearLayout s = (LinearLayout) slotFrame(set);
        if (set) {
            s.addView(centered(text("🔊", 22, Color.WHITE)));
            TextView name = text(sp.getString(key + "Name", "効果音"), 12, Color.rgb(207, 216, 211));
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            s.addView(name);
            Button play = button("▶ ためす", GREEN, Color.rgb(4, 33, 15));
            play.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            play.setPadding(dp(10), dp(2), dp(10), dp(2));
            play.setMinHeight(0);
            play.setMinimumHeight(0);
            play.setOnClickListener(v -> playTest(f));
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(28));
            pl.topMargin = dp(4);
            s.addView(play, pl);
        } else {
            s.addView(centered(text("＋", 28, GRAY)));
            TextView t = text("効果音を選ぶ\n（ファイルが開く）", 12, Color.rgb(207, 216, 211));
            t.setGravity(Gravity.CENTER);
            s.addView(t);
        }
        s.setOnClickListener(v -> pickAudio(key));
        s.setOnLongClickListener(v -> { if (f.exists()) confirmRemove(f, key + "Name"); return true; });
        return s;
    }

    TextView centered(TextView t) { t.setGravity(Gravity.CENTER); return t; }

    void confirmRemove(File f, String nameKey) {
        new AlertDialog.Builder(this).setTitle("外しますか？")
                .setPositiveButton("外す", (d, w) -> { f.delete(); if (nameKey != null) sp.edit().remove(nameKey).apply(); show(screen); })
                .setNegativeButton("やめる", null).show();
    }

    void playTest(File f) {
        stopTester();
        try {
            tester = new MediaPlayer();
            tester.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build());
            tester.setDataSource(f.getPath());
            String kind = f.getName().startsWith("like") ? "like" : "sub";
            float v = alertVol(sp, kind) / 100f;
            tester.setVolume(v, v);
            tester.setOnCompletionListener(mp -> stopTester());
            tester.prepare();
            tester.start();
            MediaPlayer mine = tester;
            main.postDelayed(() -> { if (tester == mine) stopTester(); }, alertSec(sp, kind) * 1000L);
        } catch (Exception e) { toast("この音声は再生できませんでした"); stopTester(); }
    }

    void stopTester() {
        if (tester != null) { try { tester.release(); } catch (Exception ignored) { } tester = null; }
    }

    /* ---- 写真・ファイルを選ぶ ---- */

    void pickImage(String key) {
        pickTarget = key;
        Intent i = new Intent(Intent.ACTION_PICK).setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        try { startActivityForResult(i, REQ_FILE); }
        catch (Exception e) {
            try { startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_FILE); }
            catch (Exception e2) { toast("写真一覧を開けませんでした"); }
        }
    }

    /** 効果音・配信音源を選ぶ（「ファイル」か「保存した音源」から） */
    void pickAudio(String key) {
        chooseSound("bgm".equals(key) ? "配信音源を選ぶ" : "効果音を選ぶ", (f, name) -> {
            try {
                SoundLib.copy(f, new File(getFilesDir(), key));
            } catch (Exception e) {
                toast("読み込めませんでした");
                return;
            }
            if (key.endsWith("Snd")) sp.edit().putString(key + "Name", name).apply();
            if ("bgm".equals(key)) sp.edit().putString("bgmName", name).putBoolean("bgmOn", true).apply();
            show(screen);
            toast("設定しました");
        });
    }

    /* ================= 音を選ぶ画面（ファイル／保存した音源） ================= */

    interface SoundCallback { void use(File f, String name); }

    static final int REQ_SOUNDFILE = 108;
    SoundCallback soundCb;
    AlertDialog soundDlg;
    android.media.MediaPlayer soundPrev;

    void stopSoundPreview() {
        try { if (soundPrev != null) { soundPrev.stop(); soundPrev.release(); } } catch (Exception ignored) { }
        soundPrev = null;
    }

    void chooseSound(String title, SoundCallback cb) {
        soundCb = cb;
        List<SoundLib.Item> items = SoundLib.list(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.rgb(16, 20, 18));
        box.setPadding(dp(14), dp(12), dp(14), dp(8));

        LinearLayout tabs = new LinearLayout(this);
        Button tFile = button("ファイル", PANEL, Color.WHITE);
        Button tLib = button("保存した音源", PANEL, Color.WHITE);
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, dp(46), 1);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(46), 1);
        a2.leftMargin = dp(8);
        tabs.addView(tFile, a1);
        tabs.addView(tLib, a2);
        box.addView(tabs);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(content);
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(-1, dp(360));
        sp1.topMargin = dp(10);
        box.addView(sv, sp1);

        Runnable[] showFile = new Runnable[1], showLib = new Runnable[1];
        showFile[0] = () -> {
            stopSoundPreview();
            tFile.setBackground(round(GREEN, 14)); tFile.setTextColor(Color.rgb(4, 33, 15));
            tLib.setBackground(round(PANEL, 14)); tLib.setTextColor(Color.WHITE);
            content.removeAllViews();
            Button pick = button("📁 ファイルから選ぶ（音楽・動画）", Color.rgb(37, 99, 235), Color.WHITE);
            pick.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(Intent.createChooser(i, "音楽か動画を選ぶ"), REQ_SOUNDFILE); }
                catch (Exception e) { toast("ファイル選択を開けませんでした"); }
            });
            content.addView(pick, new LinearLayout.LayoutParams(-1, dp(54)));
            Button cap = button("🎙 流れている音を録る", RED, Color.WHITE);
            cap.setOnClickListener(v -> startAudioCapture());
            LinearLayout.LayoutParams cpp = new LinearLayout.LayoutParams(-1, dp(54));
            cpp.topMargin = dp(10);
            content.addView(cap, cpp);
            TextView capHow = text("TikTokなどで流している曲を、そのまま録ります。マイクは使わないので、自分の声やまわりの音は入りません。TikTokの「楽曲」のページで曲の▶を押して流すと、元の曲だけがきれいに録れます。", 12, GRAY);
            LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-1, -2);
            chp.topMargin = dp(6);
            content.addView(capHow, chp);
            TextView how = text("動画を選ぶと、音だけを取り出して使います。選んだ音は「保存した音源」に入るので、次からはすぐ選べます。\n\n"
                    + "【TikTokの音を使うとき】\nTikTokでその音楽を使っている動画を開く →「シェア」→「動画を保存」→ ここで「ファイルから選ぶ」でその動画を選ぶ", 13, GRAY);
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
            hp.topMargin = dp(12);
            content.addView(how, hp);
            Button free = button("🎵 著作権フリーの音楽を探す（YouTube）", PANEL, Color.WHITE);
            free.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/audiolibrary"))); }
                catch (Exception e) { toast("開けませんでした"); }
            });
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(50));
            fp.topMargin = dp(14);
            content.addView(free, fp);
            TextView note = text("配信で使うなら、著作権フリーの音楽が安全です。TikTokの音楽は、YouTubeでは著作権の申し立てを受けることがあります。", 11, GRAY);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
            np.topMargin = dp(8);
            content.addView(note, np);
        };
        showLib[0] = () -> {
            stopSoundPreview();
            tLib.setBackground(round(GREEN, 14)); tLib.setTextColor(Color.rgb(4, 33, 15));
            tFile.setBackground(round(PANEL, 14)); tFile.setTextColor(Color.WHITE);
            content.removeAllViews();
            List<SoundLib.Item> list = SoundLib.list(this);
            if (list.isEmpty()) {
                TextView t = text("まだありません。\n「ファイル」から音楽か動画を選ぶと、ここに保存されます。", 14, GRAY);
                t.setPadding(dp(4), dp(20), dp(4), 0);
                content.addView(t);
                return;
            }
            for (SoundLib.Item it : list) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setBackground(round(PANEL, 12));
                row.setPadding(dp(12), 0, dp(4), 0);
                TextView play = text("▶", 18, Color.WHITE);
                play.setPadding(dp(4), dp(10), dp(12), dp(10));
                play.setOnClickListener(v -> {
                    boolean was = soundPrev != null && play.getText().equals("■");
                    stopSoundPreview();
                    for (int i = 0; i < content.getChildCount(); i++) {
                        View r = content.getChildAt(i);
                        if (r instanceof LinearLayout && ((LinearLayout) r).getChildCount() > 0 && ((LinearLayout) r).getChildAt(0) instanceof TextView)
                            ((TextView) ((LinearLayout) r).getChildAt(0)).setText("▶");
                    }
                    if (was) return;
                    try {
                        soundPrev = new android.media.MediaPlayer();
                        soundPrev.setDataSource(SoundLib.file(this, it.id).getPath());
                        soundPrev.setOnCompletionListener(m -> { play.setText("▶"); stopSoundPreview(); });
                        soundPrev.prepare();
                        soundPrev.start();
                        play.setText("■");
                    } catch (Exception e) { stopSoundPreview(); toast("再生できませんでした"); }
                });
                row.addView(play);
                File imf = SoundLib.img(this, it.id);
                if (imf.exists()) {
                    ImageView iv = new ImageView(this);
                    iv.setImageBitmap(decodeSampled(imf, 96));
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                        public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(8)); }
                    });
                    iv.setClipToOutline(true);
                    LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(40), dp(40));
                    ip.rightMargin = dp(10);
                    row.addView(iv, ip);
                }
                TextView name = text((imf.exists() ? "" : "♪ ") + it.name, 15, Color.WHITE);
                name.setSingleLine(true);
                name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                name.setPadding(0, dp(14), dp(8), dp(14));
                name.setOnClickListener(v -> useSound(it));
                row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
                Button use = button("使う", GREEN, Color.rgb(4, 33, 15));
                use.setOnClickListener(v -> useSound(it));
                row.addView(use, new LinearLayout.LayoutParams(dp(64), dp(40)));
                TextView more = text("⋯", 22, Color.WHITE);
                more.setPadding(dp(10), dp(6), dp(8), dp(6));
                more.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(it.name)
                        .setItems(new String[]{"名前を変える", "写真を変える", "削除する"}, (d, w) -> {
                            if (w == 1) {
                                pickImageFor(b -> {
                                    try { SoundLib.setImage(this, it.id, b); } catch (Exception ignored) { }
                                    showLib[0].run();
                                });
                            } else if (w == 0) {
                                EditText et = new EditText(this);
                                et.setText(it.name);
                                new AlertDialog.Builder(this).setTitle("名前を変える").setView(et)
                                        .setPositiveButton("OK", (d2, w2) -> { SoundLib.rename(this, it.id, et.getText().toString().trim()); showLib[0].run(); })
                                        .setNegativeButton("キャンセル", null).show();
                            } else {
                                new AlertDialog.Builder(this).setMessage("「" + it.name + "」を削除しますか？")
                                        .setPositiveButton("削除", (d2, w2) -> { SoundLib.delete(this, it.id); showLib[0].run(); })
                                        .setNegativeButton("キャンセル", null).show();
                            }
                        }).show());
                row.addView(more);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
                rp.bottomMargin = dp(8);
                content.addView(row, rp);
            }
        };
        tFile.setOnClickListener(v -> showFile[0].run());
        tLib.setOnClickListener(v -> showLib[0].run());
        if (items.isEmpty()) showFile[0].run(); else showLib[0].run();

        soundDlg = new AlertDialog.Builder(this).setTitle(title).setView(box)
                .setNegativeButton("閉じる", null)
                .setOnDismissListener(d -> stopSoundPreview())
                .show();
    }

    /* ---------- 流れている音を録る ---------- */

    static final int REQ_AUDIOCAP = 110, REQ_CAPPERM = 111, REQ_SOUNDIMG = 109;

    void startAudioCapture() {
        if (Build.VERSION.SDK_INT < 29) { toast("この機能はAndroid 10以上で使えます"); return; }
        if (StreamService.running()) { toast("配信中は使えません"); return; }
        if (CaptureService.instance != null) { toast("録音の準備中です。画面の「▶ スタート」か「■ 終了」を押してください"); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_CAPPERM);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this).setTitle("許可が必要です")
                    .setMessage("「■ 止める」ボタンを出すために、「他のアプリの上に重ねて表示」をONにしてください。ONにしたら戻って、もう一度押してください。")
                    .setPositiveButton("設定を開く", (d, w) -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("やめる", null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("流れている音を録る")
                .setMessage("① 次の画面で「画面全体」を選んで「開始」を押す\n"
                        + "② TikTokに切りかえて、録りたい曲を出す（「楽曲」のページがおすすめ）\n"
                        + "③ 画面の緑の「▶ スタート」を押して、曲を流す（押した瞬間から録ります）\n"
                        + "④ 終わったら、赤い「■ 終了」を押す\n\n"
                        + "※ マイクは使わないので、自分の声は入りません。録るのは音だけで、画面は録りません。")
                .setPositiveButton("はじめる", (d, w) -> {
                    MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                    startActivityForResult(mpm.createScreenCaptureIntent(), REQ_AUDIOCAP);
                })
                .setNegativeButton("やめる", null).show();
    }

    /** 録り終わって戻ってきたとき */
    void handleCapture(Intent in) {
        if (in == null) return;
        String err = in.getStringExtra("captureError");
        String path = in.getStringExtra("captured");
        boolean silent = in.getBooleanExtra("capturedSilent", false);
        in.removeExtra("captureError");
        in.removeExtra("captured");
        if (err != null) { new AlertDialog.Builder(this).setMessage(err).setPositiveButton("OK", null).show(); return; }
        if (path == null) return;
        File f = new File(path);
        if (!f.exists()) return;
        if (silent) {
            new AlertDialog.Builder(this).setTitle("音が録れていないかも")
                    .setMessage("ほとんど無音でした。そのアプリが録音できないようにしているか、音が小さすぎた可能性があります。\nこのまま続けますか？")
                    .setPositiveButton("続ける", (d, w) -> trimDialog(f))
                    .setNegativeButton("やめる", (d, w) -> f.delete()).show();
        } else trimDialog(f);
    }

    /** いらない最初と最後を切る */
    void trimDialog(File wav) {
        long dur = SoundLib.wavMs(wav);
        long[] range = {0, dur};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView info = text("", 14, Color.DKGRAY);
        Runnable upd = () -> info.setText(String.format(java.util.Locale.US, "はじめ %.1f秒　〜　おわり %.1f秒（%.1f秒）",
                range[0] / 1000f, range[1] / 1000f, (range[1] - range[0]) / 1000f));
        upd.run();
        box.addView(info);
        int steps = (int) Math.max(1, dur / 100);
        TextView l1 = text("はじめ", 13, Color.GRAY);
        box.addView(l1);
        SeekBar a = new SeekBar(this);
        a.setMax(steps);
        box.addView(a, new LinearLayout.LayoutParams(-1, dp(44)));
        TextView l2 = text("おわり", 13, Color.GRAY);
        box.addView(l2);
        SeekBar b = new SeekBar(this);
        b.setMax(steps);
        b.setProgress(steps);
        box.addView(b, new LinearLayout.LayoutParams(-1, dp(44)));
        a.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { range[0] = Math.min(p * 100L, range[1] - 500); if (range[0] < 0) range[0] = 0; upd.run(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { range[1] = Math.max(p * 100L, range[0] + 500); if (range[1] > dur) range[1] = dur; upd.run(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        Button play = button("▶ 試し聞き", PANEL, Color.WHITE);
        play.setOnClickListener(v -> {
            stopSoundPreview();
            try {
                soundPrev = new android.media.MediaPlayer();
                soundPrev.setDataSource(wav.getPath());
                soundPrev.prepare();
                soundPrev.seekTo((int) range[0]);
                soundPrev.start();
                android.media.MediaPlayer mine = soundPrev;
                main.postDelayed(() -> { if (soundPrev == mine) stopSoundPreview(); }, range[1] - range[0]);
            } catch (Exception e) { stopSoundPreview(); }
        });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(48));
        pp.topMargin = dp(8);
        box.addView(play, pp);
        new AlertDialog.Builder(this).setTitle("いらない最初と最後を切る").setView(box).setCancelable(false)
                .setPositiveButton("次へ", (d, w) -> {
                    stopSoundPreview();
                    File cut = new File(getCacheDir(), "capture_cut.wav");
                    try {
                        SoundLib.trimWav(wav, cut, range[0], range[1]);
                        wav.delete();
                        nameDialog(cut);
                    } catch (Exception e) { toast("切り取れませんでした"); }
                })
                .setNegativeButton("やめる", (d, w) -> { stopSoundPreview(); wav.delete(); })
                .show();
    }

    android.graphics.Bitmap pendingSoundImg;

    /** 写真と名前を決めて保存 */
    void nameDialog(File wav) {
        pendingSoundImg = null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setBackground(round(Color.rgb(230, 230, 230), 12));
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
            public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(12)); }
        });
        iv.setClipToOutline(true);
        row.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
        Button pick = button("写真を選ぶ（なくてもOK）", PANEL, Color.WHITE);
        pick.setOnClickListener(v -> pickImageFor(bm -> { pendingSoundImg = bm; iv.setImageBitmap(bm); }));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1);
        bp.leftMargin = dp(12);
        row.addView(pick, bp);
        box.addView(row);
        TextView nl = text("名前", 13, Color.GRAY);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(14);
        box.addView(nl, np);
        EditText et = new EditText(this);
        et.setHint("例：ピタゴラスイッチ");
        et.setSingleLine(true);
        box.addView(et);
        new AlertDialog.Builder(this).setTitle("写真と名前を決める").setView(box).setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    String nm = et.getText().toString().trim();
                    if (nm.isEmpty()) nm = "録音 " + new java.text.SimpleDateFormat("M/d H:mm", java.util.Locale.JAPAN).format(new java.util.Date());
                    try {
                        SoundLib.Item it = SoundLib.addFile(this, wav, nm, pendingSoundImg);
                        pendingSoundImg = null;
                        if (soundCb != null) {
                            toast("「保存した音源」に入れました");
                            useSound(it);
                        } else {
                            new AlertDialog.Builder(this).setTitle("保存しました")
                                    .setMessage("「" + it.name + "」を「保存した音源」に入れました。ずっと使えます。")
                                    .setPositiveButton("OK", null).show();
                        }
                    } catch (Exception e) { toast("保存できませんでした"); }
                })
                .setNegativeButton("やめる", (d, w) -> wav.delete())
                .show();
    }

    interface BitmapCallback { void got(android.graphics.Bitmap b); }
    BitmapCallback imgCb;

    void pickImageFor(BitmapCallback cb) {
        imgCb = cb;
        Intent i = new Intent(Intent.ACTION_PICK).setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        try { startActivityForResult(i, REQ_SOUNDIMG); }
        catch (Exception e) {
            try { startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_SOUNDIMG); }
            catch (Exception e2) { toast("写真を選べませんでした"); }
        }
    }

    void onSoundImagePicked(Uri u) {
        if (u == null || imgCb == null) return;
        try {
            File tmp = new File(getCacheDir(), "soundimg");
            try (InputStream in = getContentResolver().openInputStream(u); OutputStream o = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            android.graphics.Bitmap b = decodeSampled(tmp, 512);
            tmp.delete();
            BitmapCallback cb = imgCb;
            imgCb = null;
            if (b != null) cb.got(b);
        } catch (Exception e) { toast("写真を読み込めませんでした"); }
    }

    void useSound(SoundLib.Item it) {
        stopSoundPreview();
        if (soundDlg != null) { try { soundDlg.dismiss(); } catch (Exception ignored) { } }
        SoundCallback cb = soundCb;
        if (cb != null) cb.use(SoundLib.file(this, it.id), it.name);
    }

    /** ファイルから選んだ音（動画なら音だけ）を保存して、そのまま使う */
    void onSoundFilePicked(Uri uri) {
        if (uri == null) return;
        String name = displayName(uri);
        AlertDialog wait = new AlertDialog.Builder(this).setMessage("音を読みこんでいます…").setCancelable(false).show();
        new Thread(() -> {
            SoundLib.Item it = null;
            String err = null;
            try { it = SoundLib.importUri(this, uri, name); } catch (Exception e) { err = e.getMessage(); }
            SoundLib.Item done = it;
            String er = err;
            main.post(() -> {
                try { wait.dismiss(); } catch (Exception ignored) { }
                if (done == null) { toast("読み込めませんでした：" + er); return; }
                toast("「保存した音源」に入れました");
                useSound(done);
            });
        }).start();
    }

    void pickVideo(String key) {
        pickTarget = key;
        Intent i = new Intent(Intent.ACTION_PICK).setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*");
        try { startActivityForResult(i, REQ_FILE); }
        catch (Exception e) {
            try { startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_FILE); }
            catch (Exception e2) { toast("写真フォルダを開けませんでした"); }
        }
    }

    void onFilePicked(Uri uri) {
        String key = pickTarget;
        if (key == null || uri == null) return;
        File out = new File(getFilesDir(), key);
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(out)) {
            if (in == null) throw new Exception("open");
            byte[] buf = new byte[65536];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                o.write(buf, 0, n);
                total += n;
                if (total > ("partVideo".equals(key) ? 500L : "bgm".equals(key) ? 150L : 30L) * 1024 * 1024) throw new Exception("大きすぎます");
            }
        } catch (Exception e) {
            out.delete();
            toast("読み込めませんでした：" + e.getMessage());
            return;
        }
        if (key.endsWith("Snd")) sp.edit().putString(key + "Name", displayName(uri)).apply();
        if ("bgm".equals(key)) sp.edit().putString("bgmName", displayName(uri)).putBoolean("bgmOn", true).apply();
        if ("partVideo".equals(key) || "partPhoto".equals(key)) {
            JSONObject l = Parts.load(this);
            try { l.getJSONObject("partVideo".equals(key) ? "video" : "photo").put("on", true); } catch (Exception ignored) { }
            Parts.save(this, l);
            videoThumb = null;
        }
        show(screen);
        toast("設定しました");
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return "効果音";
    }

    static Bitmap decodeSampled(File f, int max) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        int s = 1;
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        return BitmapFactory.decodeFile(f.getPath(), o2);
    }

    /* ================= 緊急停止 ================= */

    void emergencyStop() {
        AlertDialog wait = new AlertDialog.Builder(this).setMessage("配信を止めています…").setCancelable(false).show();
        // ① このスマホの配信をすぐ止める
        try {
            if (StreamService.instance != null) StreamService.instance.endStream("緊急停止しました");
        } catch (Exception ignored) { }
        try { stopService(new Intent(this, StreamService.class)); } catch (Exception ignored) { }
        // ② YouTube側に残っている配信を、全部のアカウントで終わらせる
        java.util.List<String> emails = new java.util.ArrayList<>();
        String last = sp.getString("lastEmail", null);
        if (last != null) emails.add(last);
        for (JSONObject a : Auth.accounts(this)) {
            String e = a.optString("email");
            if (!e.isEmpty() && !emails.contains(e)) emails.add(e);
        }
        new Thread(() -> {
            int ended = 0;
            StringBuilder errs = new StringBuilder();
            for (String e : emails) {
                try {
                    ended += new YouTube(this, e).forceEndAll();
                } catch (Exception ex) {
                    errs.append("\n").append(e).append("：").append(ex.getMessage());
                }
            }
            sp.edit().remove("lastBid").apply();
            int n = ended;
            String err = errs.toString();
            main.post(() -> {
                try { wait.dismiss(); } catch (Exception ignored) { }
                String msg = n > 0 ? "YouTubeに残っていた配信を " + n + " 個終わらせました。" : "YouTubeに残っている配信はありませんでした。";
                if (!err.isEmpty()) msg += "\n\nうまくいかなかったアカウント：" + err;
                new AlertDialog.Builder(this).setTitle("緊急停止").setMessage(msg).setPositiveButton("OK", null).show();
                show(screen);
            });
        }).start();
    }

    /* ================= 配信スタート ================= */

    void startPressed() {
        if (StreamService.running()) { toast("もう配信中です"); return; }
        if (Auth.accounts(this).isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Googleと連携してください")
                    .setMessage("配信するには、先にGoogleアカウントと連携してください。")
                    .setPositiveButton("Googleと連携する", (d, w) -> { show("google"); pickAccount(); })
                    .setNegativeButton("キャンセル", null)
                    .show();
            return;
        }
        // どのアカウントでライブしますか？
        chooseAccountDialog("どのアカウントでライブしますか？", email ->
                new AlertDialog.Builder(this)
                        .setTitle("このアカウントで配信しますか？")
                        .setMessage(email)
                        .setPositiveButton("OK", (d, w) -> {
                            sp.edit().putString("current", email).apply();
                            authorize(email, true);
                        })
                        .setNegativeButton("やり直し", (d, w) -> startPressed())
                        .show());
    }

    /* ================= ⑤ 配信せってい ================= */

    EditText titleEdit, descEdit;
    Spinner catSpin, gameSpin;

    Spinner spinner(String[] items, int sel) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(Color.WHITE);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                return t;
            }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(Math.max(0, Math.min(sel, items.length - 1)));
        s.setBackground(round(PANEL, 12));
        s.setPadding(dp(8), dp(10), dp(8), dp(10));
        return s;
    }

    View settingsScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("配信せってい", b);
        LinearLayout body = b[0];

        add(body, text("ライブの形", 13, GRAY), 12);
        LinearLayout shapeRow = new LinearLayout(this);
        shapeRow.setOrientation(LinearLayout.HORIZONTAL);
        Button sShort = button("ショート（縦）", PANEL, Color.WHITE);
        Button sLong = button("ロング（横）", PANEL, Color.WHITE);
        Runnable paintShape = () -> {
            boolean lg = Parts.isLong(this);
            sShort.setBackground(round(lg ? PANEL : GREEN, 14));
            sShort.setTextColor(lg ? Color.WHITE : Color.rgb(4, 33, 15));
            sLong.setBackground(round(lg ? GREEN : PANEL, 14));
            sLong.setTextColor(lg ? Color.rgb(4, 33, 15) : Color.WHITE);
        };
        sShort.setOnClickListener(v -> { Parts.setShape(this, "short"); paintShape.run(); });
        sLong.setOnClickListener(v -> { Parts.setShape(this, "long"); paintShape.run(); });
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(0, dp(52), 1);
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(0, dp(52), 1);
        sp2.leftMargin = dp(10);
        shapeRow.addView(sShort, sp1);
        shapeRow.addView(sLong, sp2);
        paintShape.run();
        add(body, shapeRow, 6);

        add(body, text("サムネイル", 13, GRAY), 16);
        File th = new File(getFilesDir(), "thumb");
        FrameLayout box = new FrameLayout(this);
        GradientDrawable d = round(PANEL, 14);
        d.setStroke(dp(2), Color.rgb(61, 74, 67), dp(6), dp(4));
        box.setBackground(d);
        box.setClipToOutline(true);
        if (th.exists()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(decodeSampled(th, 640));
            box.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else {
            TextView plus = text("＋", 44, GRAY);
            box.addView(plus, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        }
        box.setOnClickListener(v -> { saveSettingsFields(); pickImage("thumb"); });
        box.setOnLongClickListener(v -> { if (th.exists()) confirmRemove(th, null); return true; });
        int w = getResources().getDisplayMetrics().widthPixels - dp(36);
        add(body, box, 6, w * 9 / 16);

        add(body, text("タイトル", 13, GRAY), 16);
        titleEdit = edit("配信のタイトル", false);
        titleEdit.setText(sp.getString("title", ""));
        add(body, titleEdit, 6);

        add(body, text("概要欄", 13, GRAY), 16);
        descEdit = edit("配信の説明", true);
        descEdit.setText(sp.getString("desc", ""));
        add(body, descEdit, 6);

        add(body, text("配信のジャンル", 13, GRAY), 16);
        catSpin = spinner(CAT_NAMES, sp.getInt("cat", 0));
        add(body, catSpin, 6);

        add(body, text("ゲームのジャンル", 13, GRAY), 16);
        gameSpin = spinner(GAMES, sp.getInt("game", 0));
        add(body, gameSpin, 6);

        TextView who = text("配信するアカウント：" + (streamEmail == null ? "" : streamEmail), 12, GRAY);
        add(body, who, 16);

        Button next = button("次に進む", GREEN, Color.rgb(4, 33, 15));
        next.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        next.setOnClickListener(v -> {
            saveSettingsFields();
            if (streamEmail == null) { toast("もう一度「配信スタート」から始めてください"); show("lobby"); return; }
            show("editor");
        });
        add(body, next, 22, dp(56));
        return pageView;
    }

    void saveSettingsFields() {
        if (titleEdit == null) return;
        sp.edit().putString("title", titleEdit.getText().toString())
                .putString("desc", descEdit.getText().toString())
                .putInt("cat", catSpin.getSelectedItemPosition())
                .putInt("game", gameSpin.getSelectedItemPosition())
                .apply();
    }

    /** 許可（マイク・通知・重ねて表示）を確認して、画面の録画を始める */
    boolean startingStream = false;

    void continueStart() {
        // 配信の準備に入ったら、自分のスマホの音源は止める（配信にだけ流す）
        startingStream = true;
        stopBgmPreview();
        List<String> want = new ArrayList<>();
        want.add(Manifest.permission.RECORD_AUDIO);
        if (!Parts.mode(this).isEmpty()) want.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) want.add(Manifest.permission.POST_NOTIFICATIONS);
        List<String> need = new ArrayList<>();
        for (String pm : want) {
            if (checkSelfPermission(pm) != PackageManager.PERMISSION_GRANTED && !sp.getBoolean("asked_" + pm, false)) need.add(pm);
        }
        if (!need.isEmpty()) {
            SharedPreferences.Editor ed = sp.edit();
            for (String pm : need) ed.putBoolean("asked_" + pm, true);
            ed.apply();
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("許可が必要です")
                    .setMessage("ゲームの上に黒い丸を出すために、「他のアプリの上に重ねて表示」をONにしてください。ONにしたら、このアプリに戻って「配信開始」をもう一度押してください。")
                    .setPositiveButton("設定を開く", (d, w) -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("やめる", null)
                    .show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERM) continueStart();
        if (requestCode == REQ_CAPPERM) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startAudioCapture();
            else toast("音を録るには、録音の許可が必要です（マイクは使いません）");
        }
        if (requestCode == REQ_SUBCAM && pendingSubPw != null) {
            String pw = pendingSubPw;
            pendingSubPw = null;
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) subConnect(pw, pendingSubAuto);
            else toast("サブ機はカメラの許可が必要です");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CutEditor.REQ_MUSIC) {
            if (resultCode == RESULT_OK && data != null && cut != null) cut.onMusicPicked(data.getData());
            return;
        }
        if (requestCode == REQ_FILE) {
            if (resultCode == RESULT_OK && data != null) onFilePicked(data.getData());
            return;
        }
        if (requestCode == REQ_SOUNDFILE) {
            if (resultCode == RESULT_OK && data != null) onSoundFilePicked(data.getData());
            return;
        }
        if (requestCode == REQ_SOUNDIMG) {
            if (resultCode == RESULT_OK && data != null) onSoundImagePicked(data.getData());
            return;
        }
        if (requestCode == REQ_AUDIOCAP) {
            if (resultCode != RESULT_OK || data == null) { toast("やめました"); return; }
            Intent s2 = new Intent(this, CaptureService.class).putExtra("code", resultCode).putExtra("data", data);
            try {
                startForegroundService(s2);
                toast("TikTokに切りかえて、緑の「▶ スタート」を押してください");
                moveTaskToBack(true);
            } catch (Exception e) { toast("録音を始められませんでした"); }
            return;
        }
        if (requestCode == REQ_PICK) {
            if (resultCode == RESULT_OK && data != null) {
                String email = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                if (email != null) onPicked(email);
            }
            return;
        }
        if (requestCode == REQ_AUTH) {
            if (resultCode != RESULT_OK || data == null) { toast("Googleの許可がキャンセルされました"); return; }
            try {
                AuthorizationResult r = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                onAuthorized(pendingEmail, r.getAccessToken(), pendingForStream);
            } catch (Exception e) {
                showError(Auth.message(e));
            }
            return;
        }
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            toast("画面の配信がキャンセルされました");
            startingStream = false;
            if ("editor".equals(screen)) startBgmPreview();
            return;
        }
        int cat = sp.getInt("cat", 0), game = sp.getInt("game", 0);
        File th = new File(getFilesDir(), "thumb");
        Intent s = new Intent(this, StreamService.class)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("email", streamEmail)
                .putExtra("token", streamToken)
                .putExtra("title", sp.getString("title", ""))
                .putExtra("desc", sp.getString("desc", ""))
                .putExtra("cat", CAT_IDS[Math.max(0, Math.min(cat, CAT_IDS.length - 1))])
                .putExtra("game", game > 0 && game < GAMES.length ? GAMES[game] : "")
                .putExtra("thumb", th.exists() ? th.getPath() : null);
        startForegroundService(s);
        toast("配信の準備をしています。黒い丸が出たら、ゲームを開いてください");
        show("lobby");
        // ホーム画面に戻る（配信はそのまま続く）
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        main.postDelayed(() -> startActivity(home), 600);
    }

    /* ================= 顔エフェクト（雪・犬） ================= */

    void openEffects() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        android.widget.Switch snow = new android.widget.Switch(this);
        snow.setText("❄ 雪エフェクト（顔に白いキラキラの粒）");
        snow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        snow.setChecked(Parts.snow(this));
        snow.setPadding(0, dp(12), 0, dp(12));
        android.widget.Switch dog = new android.widget.Switch(this);
        dog.setText("🐶 犬エフェクト（犬の耳と鼻）");
        dog.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        dog.setChecked(Parts.dog(this));
        dog.setPadding(0, dp(12), 0, dp(12));
        TextView note = new TextView(this);
        note.setText("「顔出し」のカメラに映った顔を追いかけて動きます。両方ONにすると両方つきます。配信の映像にだけ出ます。");
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        box.addView(snow);
        box.addView(dog);
        box.addView(note);
        new AlertDialog.Builder(this)
                .setTitle("顔エフェクト")
                .setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    sp.edit().putBoolean("fxSnow", snow.isChecked()).putBoolean("fxDog", dog.isChecked()).apply();
                    toast("顔エフェクト：" + (snow.isChecked() ? "雪ON" : "雪OFF") + "・" + (dog.isChecked() ? "犬ON" : "犬OFF"));
                })
                .show();
    }

    /* ================= 配置の編集 ================= */

    JSONObject layout;
    FrameLayout stage;
    int stageW, stageH;
    Bitmap videoThumb;

    float phoneAspect = 2.1f;
    CutEditor cut;

    View editorScreen() {
        layout = Parts.load(this);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(Color.rgb(6, 20, 11));

        FrameLayout head = new FrameLayout(this);
        head.setPadding(dp(12), dp(10), dp(12), dp(10));
        Button back = button("戻る", Color.rgb(34, 43, 38), Color.WHITE);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        back.setPadding(dp(14), dp(6), dp(14), dp(6));
        back.setOnClickListener(v -> onBackPressed());
        head.addView(back, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START | Gravity.CENTER_VERTICAL));
        TextView t = text("配置の編集", 18, Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        Button go = button("配信開始", RED, Color.WHITE);
        go.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        go.setPadding(dp(14), dp(6), dp(14), dp(6));
        go.setOnClickListener(v -> { Parts.save(this, layout); continueStart(); });
        head.addView(go, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL));
        outer.addView(head);

        FrameLayout frame = new FrameLayout(this);
        GradientDrawable fb = round(Color.rgb(6, 20, 11), 18);
        fb.setStroke(dp(4), GREEN);
        frame.setBackground(fb);
        frame.setPadding(dp(8), dp(8), dp(8), dp(8));
        stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.BLACK);
        stage.setClipChildren(true);
        frame.addView(stage, new FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        flp.leftMargin = flp.rightMargin = dp(10);
        outer.addView(frame, flp);
        frame.post(() -> {
            android.util.DisplayMetrics real = new android.util.DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(real);
            phoneAspect = Math.max(real.heightPixels, real.widthPixels) / (float) Math.min(real.heightPixels, real.widthPixels);
            int aw = frame.getWidth() - dp(16), ah = frame.getHeight() - dp(16);
            // 配信の画面の形：ショートは縦 9:16、ロングは横 16:9
            float hw = Parts.isLong(this) ? 9f / 16f : 16f / 9f;
            stageW = Math.min(aw, Math.round(ah / hw));
            stageH = Math.round(stageW * hw);
            stage.setLayoutParams(new FrameLayout.LayoutParams(stageW, stageH, Gravity.CENTER));
            buildParts();
        });

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(10), dp(10), dp(10), dp(12));
        hs.addView(bar);
        outer.addView(hs);
        editorBar = bar;
        buildBar();
        return outer;
    }

    LinearLayout editorBar;

    void buildBar() {
        LinearLayout bar = editorBar;
        bar.removeAllViews();
        String mode = Parts.mode(this);
        addBarBtn(bar, "顔出し", "face".equals(mode), "hand".equals(mode), () -> { Parts.setMode(this, "face".equals(Parts.mode(this)) ? "" : "face"); refreshEditor(); });
        addBarBtn(bar, "手元", "hand".equals(mode), "face".equals(mode), () -> { Parts.setMode(this, "hand".equals(Parts.mode(this)) ? "" : "hand"); refreshEditor(); });
        addBarBtn(bar, "字幕", on("caption"), false, () -> {
            toggle("caption");
            if (on("caption") && layout.optJSONObject("caption").optString("text").isEmpty()) openPartSheet("caption");
            refreshEditor();
        });
        addBarBtn(bar, "URL", on("url"), false, () -> {
            toggle("url");
            if (on("url") && layout.optJSONObject("url").optString("src").isEmpty()) openPartSheet("url");
            refreshEditor();
        });
        addBarBtn(bar, "動画", on("video"), false, () -> {
            if (!on("video") && !new File(getFilesDir(), "partVideo").exists()) { Parts.save(this, layout); pickVideo("partVideo"); return; }
            toggle("video");
            refreshEditor();
        });
        addBarBtn(bar, "写真", on("photo"), false, () -> {
            if (!on("photo") && !new File(getFilesDir(), "partPhoto").exists()) { Parts.save(this, layout); pickImage("partPhoto"); return; }
            toggle("photo");
            refreshEditor();
        });
        boolean bgmOn = sp.getBoolean("bgmOn", false) && new File(getFilesDir(), "bgm").exists();
        addBarBtn(bar, "音源", bgmOn, false, () -> {
            if (!new File(getFilesDir(), "bgm").exists()) { Parts.save(this, layout); pickAudio("bgm"); return; }
            openBgmSheet();
        });
    }

    /** 配信音源：配信を見ている人だけに聞こえる音楽。最後まで行ったらくり返す */
    void openBgmSheet() {
        boolean onNow = sp.getBoolean("bgmOn", false);
        int[] vol = {sp.getInt("bgmVol", 50)};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        TextView name = text("♪ " + sp.getString("bgmName", "音源"), 15, Color.BLACK);
        box.addView(name);
        TextView lab = text("", 14, Color.DKGRAY);
        Runnable show = () -> lab.setText("音の大きさ：" + vol[0] + "%");
        show.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        box.addView(lab, lp);
        SeekBar sb = new SeekBar(this);
        sb.setMax(200);
        sb.setProgress(vol[0]);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { vol[0] = p; show.run(); applyBgmPreviewVol(p); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(-1, dp(48)));
        // OFFのときも、この画面を開いているあいだは試しに流す
        if (bgmPreview == null) playBgmPreview(new File(getFilesDir(), "bgm"));
        TextView note = text("この画面（配置の編集）では、音の大きさを確かめられるように自分のスマホでも流れます。配信が始まったら自分には聞こえなくなり、見ている人にだけ聞こえます。最後まで行ったら最初からくり返します。", 12, Color.GRAY);
        box.addView(note);
        new AlertDialog.Builder(this).setTitle("配信音源")
                .setView(box)
                .setPositiveButton(onNow ? "決定" : "ONにして決定", (d, w) -> {
                    sp.edit().putInt("bgmVol", vol[0]).putBoolean("bgmOn", true).apply();
                    buildBar();
                })
                .setNeutralButton("音源を変える", (d, w) -> { sp.edit().putInt("bgmVol", vol[0]).apply(); Parts.save(this, layout); pickAudio("bgm"); })
                .setNegativeButton(onNow ? "OFFにする" : "閉じる", (d, w) -> {
                    sp.edit().putInt("bgmVol", vol[0]).putBoolean("bgmOn", false).apply();
                    buildBar();
                })
                .setOnDismissListener(d -> {
                    // 閉じたら、ONなら流し続ける・OFFなら止める
                    if ("editor".equals(screen)) {
                        if (sp.getBoolean("bgmOn", false)) { if (bgmPreview == null) startBgmPreview(); else applyBgmPreviewVol(sp.getInt("bgmVol", 50)); }
                        else stopBgmPreview();
                    }
                })
                .show();
    }

    void addBarBtn(LinearLayout bar, String label, boolean active, boolean disabled, Runnable r) {
        Button b = button(label, active ? GREEN : PANEL, active ? Color.rgb(4, 33, 15) : Color.WHITE);
        b.setMinWidth(dp(92));
        b.setEnabled(!disabled);
        b.setAlpha(disabled ? 0.35f : 1f);
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(50));
        p.rightMargin = dp(8);
        bar.addView(b, p);
    }

    boolean on(String k) { JSONObject o = layout.optJSONObject(k); return o != null && o.optBoolean("on"); }

    void toggle(String k) {
        try { layout.getJSONObject(k).put("on", !on(k)); } catch (Exception ignored) { }
        Parts.save(this, layout);
    }

    void refreshEditor() {
        Parts.save(this, layout);
        Link.Main.sendCam();
        buildBar();
        buildParts();
    }

    void buildParts() {
        if (stage == null || stageW == 0) return;
        stage.removeAllViews();
        releaseEditorWebs();
        // 真ん中の白い帯＝ゲーム画面（横向きのゲームが映るところ）。触れない・文字も変わらない
        // 横向きのゲームが、配信の画面の真ん中にぴったり入る大きさ
        int bandW = stageW, bandH = Math.round(stageW / phoneAspect);
        if (bandH > stageH) { bandH = stageH; bandW = Math.round(stageH * phoneAspect); }
        TextView band = text(Parts.isLong(this) ? "ゲーム画面" : "ゲーム画面\n（ここに重ならないように置く）", 11, Color.rgb(120, 120, 120));
        band.setGravity(Gravity.CENTER);
        band.setBackgroundColor(Color.WHITE);
        band.setClickable(false);
        stage.addView(band, new FrameLayout.LayoutParams(bandW, bandH, Gravity.CENTER));

        String mode = Parts.mode(this);
        if (!mode.isEmpty()) stage.addView(partView(mode));
        if (on("video")) stage.addView(partView("video"));
        if (on("photo")) stage.addView(partView("photo"));
        if (on("url")) stage.addView(partView("url"));
        if (on("caption")) stage.addView(partView("caption"));
    }

    String partName(String k) {
        switch (k) {
            case "face": return "顔出し";
            case "hand": return "手元";
            case "caption": return "字幕";
            case "url": return "URL";
            case "video": return "動画";
            default: return "写真";
        }
    }

    void placePart(View v, JSONObject p) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Math.max(dp(30), (int) (p.optDouble("w") * stageW)), Math.max(dp(24), (int) (p.optDouble("h") * stageH)));
        lp.leftMargin = (int) (p.optDouble("x") * stageW);
        lp.topMargin = (int) (p.optDouble("y") * stageH);
        v.setLayoutParams(lp);
    }

    final java.util.List<android.webkit.WebView> editorWebs = new java.util.ArrayList<>();

    void releaseEditorWebs() {
        for (android.webkit.WebView w : editorWebs) { try { w.destroy(); } catch (Exception ignored) { } }
        editorWebs.clear();
    }

    /** 中身（ページなど）が指を取らないように、部品の本体がタッチを受け取る。↻と◢だけはそのまま押せる */
    static class PartFrame extends FrameLayout {
        PartFrame(android.content.Context c) { super(c); }
        @Override
        public boolean onInterceptTouchEvent(android.view.MotionEvent e) {
            if (e.getActionMasked() != android.view.MotionEvent.ACTION_DOWN) return false;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if ("btn".equals(c.getTag()) && e.getX() >= c.getLeft() && e.getX() <= c.getRight()
                        && e.getY() >= c.getTop() && e.getY() <= c.getBottom()) return false;
            }
            return true;
        }
    }

    View partView(String k) {
        JSONObject p = layout.optJSONObject(k);
        FrameLayout v = new PartFrame(this);
        GradientDrawable border = round(Color.TRANSPARENT, 8);
        // URLは白いページなので、枠は緑にして見えるようにする
        border.setStroke(dp(2), "url".equals(k) ? Color.rgb(34, 197, 94) : Color.WHITE, dp(5), dp(3));
        v.setForeground(border);
        v.setClipToOutline(true);
        v.setBackground(round(Color.rgb(31, 41, 55), 8));

        if ("face".equals(k) || "hand".equals(k)) {
            TextView t = text("face".equals(k) ? "📷 前カメラ" : "📷 後ろカメラ", 11, Color.WHITE);
            t.setGravity(Gravity.CENTER);
            v.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else if ("caption".equals(k)) {
            v.setBackground(round(Color.argb(140, 0, 0, 0), 8));
            TextView t = text(p.optString("text", ""), 14, Color.WHITE);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setGravity(Gravity.CENTER);
            t.setAutoSizeTextTypeUniformWithConfiguration(8, 40, 1, TypedValue.COMPLEX_UNIT_SP);
            v.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else if ("url".equals(k)) {
            v.setBackground(round(Color.WHITE, 8));
            String src = p.optString("src", "");
            if (src.isEmpty()) {
                TextView t = text("URL（タップして入力）", 11, Color.rgb(90, 90, 90));
                t.setGravity(Gravity.CENTER);
                v.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            } else {
                // 配信に映るページを、そのまま小さく見せる
                try {
                    android.webkit.WebView w = new android.webkit.WebView(this);
                    android.webkit.WebSettings st = w.getSettings();
                    st.setJavaScriptEnabled(true);
                    st.setDomStorageEnabled(true);
                    st.setUseWideViewPort(true);
                    st.setLoadWithOverviewMode(true);
                    w.setBackgroundColor(Color.WHITE);
                    w.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override
                        public void onPageFinished(android.webkit.WebView view, String url) { view.evaluateJavascript(Compositor.FIT_JS, null); }
                    });
                    w.setVerticalScrollBarEnabled(false);
                    w.setHorizontalScrollBarEnabled(false);
                    w.loadUrl(src);
                    editorWebs.add(w);
                    // 配信と同じ大きさ（横1000）で開いて、枠に合わせて縮める＝配信と同じ見え方
                    int pw = Math.max(dp(30), (int) (p.optDouble("w") * stageW));
                    int ph = Math.max(dp(24), (int) (p.optDouble("h") * stageH));
                    int vw = 1000, vh = Math.max(100, Math.round(vw * ph / (float) pw));
                    w.setPivotX(0);
                    w.setPivotY(0);
                    w.setScaleX(pw / (float) vw);
                    w.setScaleY(pw / (float) vw);
                    v.addView(w, new FrameLayout.LayoutParams(vw, vh));
                } catch (Exception e) {
                    String host = src;
                    try { host = Uri.parse(src).getHost(); } catch (Exception ignored) { }
                    TextView t = text(host == null ? "URL" : host, 11, Color.rgb(90, 90, 90));
                    t.setGravity(Gravity.CENTER);
                    v.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                }
            }
        } else if ("video".equals(k)) {
            File f = new File(getFilesDir(), "partVideo");
            if (videoThumb == null && f.exists()) {
                android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
                try {
                    r.setDataSource(f.getPath());
                    Bitmap full = r.getFrameAtTime(0);
                    if (full != null) {
                        // 大きすぎる絵は描くときに落ちるので、小さくしておく
                        float sc = 480f / Math.max(full.getWidth(), full.getHeight());
                        videoThumb = sc < 1 ? Bitmap.createScaledBitmap(full, Math.max(1, Math.round(full.getWidth() * sc)), Math.max(1, Math.round(full.getHeight() * sc)), true) : full;
                    }
                } catch (Throwable ignored) { }
                try { r.release(); } catch (Exception ignored) { }
            }
            if (videoThumb != null) {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(videoThumb);
                v.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
            TextView t = text("▶", 22, Color.WHITE);
            t.setGravity(Gravity.CENTER);
            v.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else {
            File f = new File(getFilesDir(), "partPhoto");
            if (f.exists()) {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(decodeSampled(f, 400));
                v.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }

        // 形（丸・三角など）の外側をかくして見せる
        if (!"caption".equals(k)) {
            v.addView(new Shapes.Cover(this, p.optString("shape", "round")),
                    new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }

        TextView tag = text(partName(k), 10, Color.WHITE);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        tag.setBackground(round(Color.argb(170, 0, 0, 0), 999));
        tag.setPadding(dp(6), dp(1), dp(6), dp(1));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        tl.leftMargin = tl.topMargin = dp(4);
        v.addView(tag, tl);

        // 右上「↻」：縦長⇔横長
        TextView rot = text("↻", 14, Color.WHITE);
        rot.setGravity(Gravity.CENTER);
        rot.setTypeface(Typeface.DEFAULT_BOLD);
        rot.setBackground(round(Color.argb(190, 0, 0, 0), 8));
        rot.setOnClickListener(x -> { rotatePart(p); placePart(v, p); Parts.save(this, layout); });
        rot.setTag("btn");
        v.addView(rot, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END));

        // 右下の角：1秒長押しで変形
        TextView rsz = text("◢", 12, Color.WHITE);
        rsz.setGravity(Gravity.CENTER);
        rsz.setBackground(round(Color.argb(190, 0, 0, 0), 8));
        final double[] base = new double[2];
        Drag.attach(rsz, null, new Drag.Listener() {
            public void onStart() { base[0] = p.optDouble("w"); base[1] = p.optDouble("h"); }
            public void onMove(float dx, float dy) {
                try {
                    p.put("w", Math.max(0.1, Math.min(1 - p.optDouble("x"), base[0] + dx / stageW)));
                    p.put("h", Math.max(0.04, Math.min(1 - p.optDouble("y"), base[1] + dy / stageH)));
                } catch (Exception ignored) { }
                try { placePart(v, p); } catch (Exception ignored) { }
            }
            // 指を離した直後に作り直すと落ちることがあるので、少しあとで作り直す
            public void onEnd() {
                try { Parts.save(MainActivity.this, layout); } catch (Exception ignored) { }
                main.post(() -> { try { if ("editor".equals(screen)) buildParts(); } catch (Exception ignored) { } });
            }
        });
        rsz.setTag("btn");
        v.addView(rsz, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM | Gravity.END));

        // 本体：長押しで好きな場所へ（動画・写真は3秒、ほかは1秒）。短くタップで設定
        final double[] pos = new double[2];
        long hold = ("video".equals(k) || "photo".equals(k)) ? 3000 : 1000;
        Drag.attach(v, () -> openPartSheet(k), new Drag.Listener() {
            public void onStart() { pos[0] = p.optDouble("x"); pos[1] = p.optDouble("y"); }
            public void onMove(float dx, float dy) {
                try {
                    p.put("x", Math.max(0, Math.min(1 - p.optDouble("w"), pos[0] + dx / stageW)));
                    p.put("y", Math.max(0, Math.min(1 - p.optDouble("h"), pos[1] + dy / stageH)));
                } catch (Exception ignored) { }
                placePart(v, p);
            }
            public void onEnd() { try { Parts.save(MainActivity.this, layout); } catch (Exception ignored) { } }
        }, hold);
        placePart(v, p);
        return v;
    }

    void rotatePart(JSONObject p) {
        double w = p.optDouble("h") * stageH / stageW, h = p.optDouble("w") * stageW / stageH;
        double s = Math.min(1, Math.min(1 / w, 1 / h));
        w *= s;
        h *= s;
        double cx = p.optDouble("x") + p.optDouble("w") / 2, cy = p.optDouble("y") + p.optDouble("h") / 2;
        try {
            p.put("w", w).put("h", h);
            p.put("x", Math.max(0, Math.min(1 - w, cx - w / 2)));
            p.put("y", Math.max(0, Math.min(1 - h, cy - h / 2)));
        } catch (Exception ignored) { }
    }

    void openPartSheet(String k) {
        JSONObject p = layout.optJSONObject(k);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(partName(k));
        if ("caption".equals(k) || "url".equals(k)) {
            EditText e = new EditText(this);
            e.setText(p.optString("caption".equals(k) ? "text" : "src", ""));
            e.setHint("caption".equals(k) ? "字幕の文字（改行で2行まで）" : "https://");
            if ("url".equals(k)) e.setSingleLine(true);
            FrameLayout wrap = new FrameLayout(this);
            wrap.setPadding(dp(22), dp(8), dp(22), 0);
            wrap.addView(e);
            b.setView(wrap).setPositiveButton("決定", (d, w) -> {
                String val = e.getText().toString().trim();
                if ("url".equals(k) && !val.isEmpty() && !val.matches("(?i)^https?://.*")) val = "https://" + val;
                try { p.put("caption".equals(k) ? "text" : "src", val); } catch (Exception ignored) { }
                refreshEditor();
            }).setNegativeButton("キャンセル", null);
            if ("url".equals(k)) {
                b.setMessage("ページの中身は配信の映像にだけ映ります（自分の画面には出ません）。");
                b.setNeutralButton("形：" + Shapes.name(p.optString("shape", "round")), (d, w) -> pickShape(k));
            }
        } else if ("video".equals(k)) {
            boolean sound = p.optBoolean("sound");
            b.setItems(new String[]{"動画を選び直す", "動画の音：" + (sound ? "ON → OFFにする" : "OFF → ONにする"), "形：" + Shapes.name(p.optString("shape", "round")) + "（変える）", "外す"}, (d, which) -> {
                if (which == 0) { Parts.save(this, layout); pickVideo("partVideo"); }
                else if (which == 1) { try { p.put("sound", !sound); } catch (Exception ignored) { } refreshEditor(); }
                else if (which == 2) pickShape(k);
                else { toggle("video"); refreshEditor(); }
            });
        } else if ("photo".equals(k)) {
            b.setItems(new String[]{"写真を選び直す", "形：" + Shapes.name(p.optString("shape", "round")) + "（変える）", "外す"}, (d, which) -> {
                if (which == 0) { Parts.save(this, layout); pickImage("partPhoto"); }
                else if (which == 1) pickShape(k);
                else { toggle("photo"); refreshEditor(); }
            });
        } else {
            b.setMessage(("face".equals(k) ? "前カメラ（顔出し）" : "後ろカメラ（手元）") + "の映像が、配信の映像のこの場所に出ます。自分の画面には出ません。");
            if ("face".equals(k)) b.setPositiveButton("顔エフェクトの設定", (d, w) -> openEffects());
            b.setNeutralButton("形：" + Shapes.name(p.optString("shape", "round")), (d, w) -> pickShape(k));
            b.setNegativeButton("閉じる", null);
        }
        b.show();
    }

    /** 形を選ぶ（角丸・四角・丸・三角・ハート・星） */
    void pickShape(String k) {
        JSONObject p = layout.optJSONObject(k);
        String now = p.optString("shape", "round");
        int cur = 0;
        for (int i = 0; i < Shapes.KEYS.length; i++) if (Shapes.KEYS[i].equals(now)) cur = i;
        new AlertDialog.Builder(this).setTitle(partName(k) + "の形")
                .setSingleChoiceItems(Shapes.NAMES, cur, (d, i) -> {
                    try { p.put("shape", Shapes.KEYS[i]); } catch (Exception ignored) { }
                    d.dismiss();
                    refreshEditor();
                })
                .setNegativeButton("キャンセル", null).show();
    }

    /* ================= 履歴 ================= */

    File clipFile;
    android.widget.VideoView clipView;

    static String histLabel(String name) {
        try {
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US);
            java.text.SimpleDateFormat full = new java.text.SimpleDateFormat("yyyy年M月d日 HH:mm", java.util.Locale.JAPAN);
            if (name.startsWith("live_")) return full.format(in.parse(name.substring(5, 20))) + " に配信しました";
            if (name.startsWith("clip_")) {
                int i = name.indexOf("__live_");
                String orig = i > 0 ? name.substring(i + 7, i + 22) : name.substring(5, 20);
                return full.format(in.parse(orig)) + " の配信から切り抜き";
            }
        } catch (Exception ignored) { }
        return name;
    }

    static String fmtMs(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60)
                : String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60);
    }

    View historyScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("履歴", b);
        LinearLayout body = b[0];
        File[] files = StreamService.recDir(this).listFiles((d, n) -> n.endsWith(".mp4"));
        if (files == null || files.length == 0) {
            TextView t = text("まだ配信の履歴はありません。\n公開ライブの間は、自動で録画されます。", 14, GRAY);
            t.setGravity(Gravity.CENTER);
            add(body, t, 40);
            return pageView;
        }
        java.util.Arrays.sort(files, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        for (File f : files) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(12), 0, dp(12));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(histLabel(f.getName()), 15, Color.WHITE);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            col.addView(name);
            col.addView(text(fmtMs(Trimmer.durationMs(f.getPath())), 12, GRAY));
            row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            Button edit = button("編集", Color.rgb(34, 43, 38), Color.WHITE);
            edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            edit.setPadding(dp(12), dp(6), dp(12), dp(6));
            edit.setOnClickListener(v -> { clipFile = f; show("clip"); });
            row.addView(edit);
            Button trash = button("🗑", Color.rgb(42, 20, 20), Color.rgb(248, 113, 113));
            trash.setPadding(dp(10), dp(6), dp(10), dp(6));
            trash.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("削除しますか？")
                    .setMessage(histLabel(f.getName()) + "\nこの動画を削除します。元に戻せません。")
                    .setPositiveButton("OK", (d, w) -> { f.delete(); show("history"); toast("削除しました"); })
                    .setNegativeButton("やめる", null).show());
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tp.leftMargin = dp(8);
            row.addView(trash, tp);
            row.setOnClickListener(v -> { clipFile = f; show("clip"); });
            add(body, row, 0);
            View line = new View(this);
            line.setBackgroundColor(LINE);
            add(body, line, 0, dp(1));
        }
        return pageView;
    }

    /* ================= 動画の編集（切り抜き） ================= */

    View clipScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("動画の編集", b);
        LinearLayout body = b[0];
        if (clipFile == null || !clipFile.exists()) { add(body, text("動画が見つかりません", 14, GRAY), 20); return pageView; }
        long dur = Math.max(1000, Trimmer.durationMs(clipFile.getPath()));
        add(body, text(histLabel(clipFile.getName()), 13, GRAY), 8);

        android.widget.VideoView vv = new android.widget.VideoView(this);
        vv.setVideoPath(clipFile.getPath());
        android.widget.MediaController mc = new android.widget.MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        clipView = vv;
        FrameLayout vbox = new FrameLayout(this);
        vbox.setBackgroundColor(Color.BLACK);
        vbox.addView(vv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        add(body, vbox, 8, dp(300));

        int steps = (int) Math.min(100000, dur / 100);   // 0.1秒ずつ
        TextView st = text("はじまり  0:00", 13, GRAY);
        SeekBar sb = new SeekBar(this);
        sb.setMax(steps);
        TextView et = text("おわり  " + fmtMs(dur), 13, GRAY);
        SeekBar eb = new SeekBar(this);
        eb.setMax(steps);
        eb.setProgress(steps);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                if (p > eb.getProgress() - 10) { s.setProgress(Math.max(0, eb.getProgress() - 10)); return; }
                st.setText("はじまり  " + fmtMs(p * 100L));
                if (u) vv.seekTo(p * 100);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        eb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                if (p < sb.getProgress() + 10) { s.setProgress(Math.min(steps, sb.getProgress() + 10)); return; }
                et.setText("おわり  " + fmtMs(p * 100L));
                if (u) vv.seekTo(p * 100);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        add(body, st, 16);
        add(body, sb, 4);
        add(body, et, 12);
        add(body, eb, 4);
        TextView note = text("好きなシーンを選んで保存すると、新しい動画として履歴に追加されます。元の動画はそのまま残ります。", 12, GRAY);
        add(body, note, 12);
        Button save = button("切り抜いて保存", GREEN, Color.rgb(4, 33, 15));
        File src = clipFile;
        save.setOnClickListener(v -> {
            save.setEnabled(false);
            note.setText("切り抜いています…（少し待ってください）");
            long s0 = sb.getProgress() * 100L, e0 = eb.getProgress() * 100L;
            io.execute(() -> {
                String base = src.getName().startsWith("live_") ? src.getName().substring(0, 20) : "live_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date(src.lastModified()));
                String name = "clip_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date()) + "__" + base + ".mp4";
                File out = new File(StreamService.recDir(this), name);
                try {
                    Trimmer.trim(src.getPath(), out.getPath(), s0, e0);
                    main.post(() -> { save.setEnabled(true); note.setText("新しい動画として保存しました。元の動画はそのまま残っています。"); toast("切り抜いた動画を保存しました"); });
                } catch (Exception e) {
                    out.delete();
                    main.post(() -> { save.setEnabled(true); note.setText("保存できませんでした：" + e.getMessage()); });
                }
            });
        });
        add(body, save, 16, dp(54));
        return pageView;
    }

    /* ================= サブ機 ================= */

    String linkText() {
        switch (Link.Main.status) {
            case "connecting": return "サブ機：準備中…";
            case "wait": return "サブ機：待ち受け中";
            case "linking": return "サブ機：つないでいます…";
            case "linked": return "サブ機：パーティーに参加中" + Link.Main.detail();
            case "dup": return "このパスワードは別の端末で使われています";
            case "neterr": return "サブ機：通信エラー（つなぎ直しています）";
            default: return "サブ機：パスワードを決めると待ち受けます";
        }
    }

    String pendingSubPw;
    boolean pendingSubAuto;
    String subWaitMsg = "";
    boolean subWaitError = false;
    org.webrtc.SurfaceViewRenderer subRenderer;
    View powerSave;

    View subPwScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("サブ機の接続", b);
        LinearLayout body = b[0];
        TextView t = text("メイン機で決めたパスワードを入れてください", 15, Color.WHITE);
        t.setGravity(Gravity.CENTER);
        add(body, t, 60);
        EditText pw = edit("パスワード", false);
        pw.setGravity(Gravity.CENTER);
        pw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        add(body, pw, 16, dp(60));
        Button ok = button("決定", GREEN, Color.rgb(4, 33, 15));
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        ok.setOnClickListener(v -> {
            String n = Normalizer.normalize(pw.getText().toString(), Normalizer.Form.NFKC).replaceAll("[\\s　]+", " ").trim();
            if (n.isEmpty()) { toast("パスワードを入力してください"); return; }
            new AlertDialog.Builder(this)
                    .setTitle("このパスワードでいいですか？")
                    .setMessage("「" + n + "」")
                    .setPositiveButton("OK", (d, w) -> subConnect(n, false))
                    .setNegativeButton("やり直し", null)
                    .show();
        });
        add(body, ok, 14, dp(56));
        return pageView;
    }

    View subWaitScreen() {
        LinearLayout[] b = new LinearLayout[1];
        LinearLayout pageView = page("サブ機の接続", b);
        LinearLayout body = b[0];
        if (!subWaitError) {
            android.widget.ProgressBar pb = new android.widget.ProgressBar(this);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(48), dp(48));
            pp.gravity = Gravity.CENTER_HORIZONTAL;
            pp.topMargin = dp(80);
            body.addView(pb, pp);
        }
        TextView t = text(subWaitMsg, 15, Color.WHITE);
        t.setGravity(Gravity.CENTER);
        add(body, t, subWaitError ? 80 : 20);
        if (subWaitError) {
            String saved = sp.getString("subPw", "");
            Button again = button("もう一度つなぐ", GREEN, Color.rgb(4, 33, 15));
            again.setOnClickListener(v -> { if (!saved.isEmpty()) subConnect(saved, true); else show("subpw"); });
            add(body, again, 24, dp(54));
            Button re = button("パスワードを入れ直す", PANEL, Color.WHITE);
            re.setOnClickListener(v -> { sp.edit().remove("subPw").apply(); show("subpw"); });
            add(body, re, 10, dp(54));
        }
        return pageView;
    }

    void subWait(String msg, boolean error) {
        subWaitMsg = msg;
        subWaitError = error;
        show("subwait");
    }

    void subConnect(String pw, boolean auto) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingSubPw = pw;
            pendingSubAuto = auto;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_SUBCAM);
            return;
        }
        subWait("メイン機を探しています…", false);
        Link.Sub.connect(this, pw, new Link.SubListener() {
            public void onStep(String text) {
                if ("ok".equals(text)) { subVideoMsg = "メイン機に映像を送っています"; updateSubLabel(); return; }
                if ("failed".equals(text)) { subVideoMsg = "映像の通り道を作れません。Wi-Fiかモバイル回線を変えてみてください"; updateSubLabel(); return; }
                if ("relay".equals(text)) { subVideoMsg = "メイン機に映像を送っています（中継）"; updateSubLabel(); return; }
                if ("subwait".equals(screen)) subWait(text, false);
            }
            public void onWho(String email, String name) {
                sp.edit().putString("subPw", pw).apply();
                // 同じパスワード・同じ相手なら確認をはぶく
                if (auto && email.equalsIgnoreCase(sp.getString("subEmail", ""))) { Link.Sub.accept(); return; }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("この人でいいですか？")
                        .setMessage((name == null || name.isEmpty() ? "" : name + "\n") + email)
                        .setCancelable(false)
                        .setPositiveButton("OK", (d, w) -> { sp.edit().putString("subEmail", email).apply(); Link.Sub.accept(); })
                        .setNegativeButton("やり直し", (d, w) -> { Link.Sub.decline(); sp.edit().remove("subPw").apply(); show("subpw"); })
                        .show();
            }
            public void onLocalTrack(org.webrtc.VideoTrack t, boolean front) {
                subTrack = t;
                subFront = front;
                if (subRenderer != null) { subRenderer.setMirror(front); }
            }
            public void onLinked() {
                subVideoMsg = "パーティーに参加しました。映像をつないでいます…";
                show("subview");
                toast("パーティーに参加しました");
            }
            public void onLive(boolean on) { if (powerSave != null) powerSave.setVisibility(on ? View.VISIBLE : View.GONE); subLive = on; }
            public void onEnd() {
                show("start");
                new AlertDialog.Builder(MainActivity.this).setMessage("メイン機がライブを終了したので、通信を切りました").setPositiveButton("OK", null).show();
            }
            public void onFail(String code) {
                String msg;
                if ("notfound".equals(code)) msg = "メイン機が見つかりません。\nメイン機でSyncCamを開き、同じパスワードで「完了」を押してから、もう一度ためしてください。";
                else if ("lost".equals(code)) msg = "通信が切れました。";
                else msg = "通信エラーが起きました。ネット接続を確認してください。";
                subWait(msg, true);
            }
        });
    }

    String subVideoMsg = "";
    TextView subLabel;

    void updateSubLabel() { if (subLabel != null) subLabel.setText(subVideoMsg); }

    org.webrtc.VideoTrack subTrack;
    boolean subFront = true, subLive = false;

    View subViewScreen() {
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.BLACK);
        subRenderer = new org.webrtc.SurfaceViewRenderer(this);
        try {
            subRenderer.init(Link.egl.getEglBaseContext(), null);
            subRenderer.setMirror(subFront);
            subRenderer.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            if (subTrack != null) subTrack.addSink(subRenderer);
        } catch (Exception ignored) { }
        f.addView(subRenderer, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        TextView label = text(subVideoMsg, 12, Color.WHITE);
        subLabel = label;
        label.setBackground(round(Color.argb(150, 0, 0, 0), 999));
        label.setPadding(dp(12), dp(5), dp(12), dp(5));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = dp(30);
        f.addView(label, lp);
        // サブ機は何も押せない
        View block = new View(this);
        block.setOnTouchListener((v, e) -> true);
        f.addView(block, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // 省エネ画面（メイン機がライブ中）
        TextView ps = text("SyncCam 通信中", 12, Color.rgb(70, 70, 70));
        ps.setGravity(Gravity.CENTER);
        ps.setBackgroundColor(Color.BLACK);
        ps.setVisibility(subLive ? View.VISIBLE : View.GONE);
        powerSave = ps;
        f.addView(ps, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        return f;
    }

    void releaseSubView() {
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try { if (subTrack != null && subRenderer != null) subTrack.removeSink(subRenderer); } catch (Exception ignored) { }
        try { if (subRenderer != null) subRenderer.release(); } catch (Exception ignored) { }
        subRenderer = null;
        subLabel = null;
        powerSave = null;
        subLive = false;
    }
}
