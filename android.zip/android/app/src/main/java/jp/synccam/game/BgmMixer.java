package jp.synccam.game;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import com.pedro.encoder.input.audio.CustomAudioEffect;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/**
 * 配信音源（BGM）：音楽ファイルを読みこんで、マイクの音に混ぜる。
 * スマホのスピーカーからは鳴らさないので、自分には聞こえず、配信を見ている人だけに聞こえる。
 * 最後まで行ったら最初からくり返す。
 */
public class BgmMixer extends CustomAudioEffect {

    static final int RATE = 44100;
    final File file;
    volatile float vol;
    volatile boolean running = false;

    // 2秒ぶんの音をためておく（左右交互）
    final short[] ring = new short[RATE * 2 * 2];
    int rd = 0, wr = 0, count = 0;
    final Object lock = new Object();
    Thread thread;

    BgmMixer(File file, float vol) {
        this.file = file;
        this.vol = vol;
    }

    void start() {
        running = true;
        thread = new Thread(this::decodeLoop, "bgm");
        thread.start();
    }

    void stop() {
        running = false;
        synchronized (lock) { lock.notifyAll(); }
    }

    /** マイクの音（16bit・ステレオ）にBGMを足す */
    @Override
    public byte[] process(byte[] pcm) {
        if (!running || pcm == null) return pcm;
        float v = vol;
        int n = pcm.length / 2;
        synchronized (lock) {
            for (int i = 0; i < n; i++) {
                int lo = pcm[2 * i] & 0xff, hi = pcm[2 * i + 1];
                int mic = (hi << 8) | lo;
                int bgm = 0;
                if (count > 0) {
                    bgm = ring[rd];
                    rd = (rd + 1) % ring.length;
                    count--;
                }
                int m = mic + Math.round(bgm * v);
                if (m > 32767) m = 32767;
                if (m < -32768) m = -32768;
                pcm[2 * i] = (byte) (m & 0xff);
                pcm[2 * i + 1] = (byte) ((m >> 8) & 0xff);
            }
            lock.notifyAll();
        }
        return pcm;
    }

    void push(short l, short r) throws InterruptedException {
        synchronized (lock) {
            while (running && count + 2 > ring.length) lock.wait(50);
            if (!running) return;
            ring[wr] = l;
            wr = (wr + 1) % ring.length;
            ring[wr] = r;
            wr = (wr + 1) % ring.length;
            count += 2;
        }
    }

    void decodeLoop() {
        int fails = 0;
        while (running && fails < 3) {
            MediaExtractor ex = new MediaExtractor();
            MediaCodec dec = null;
            boolean playedSomething = false;
            try {
                ex.setDataSource(file.getPath());
                int track = -1;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    String mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                    if (mime != null && mime.startsWith("audio/")) { track = i; break; }
                }
                if (track < 0) return;
                ex.selectTrack(track);
                MediaFormat fmt = ex.getTrackFormat(track);
                dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
                dec.configure(fmt, null, null, 0);
                dec.start();
                int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : RATE;
                int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
                double carry = 0;
                boolean inEnd = false;
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (running) {
                    if (!inEnd) {
                        int ii = dec.dequeueInputBuffer(10000);
                        if (ii >= 0) {
                            ByteBuffer ib = dec.getInputBuffer(ii);
                            int sz = ib == null ? -1 : ex.readSampleData(ib, 0);
                            if (sz < 0) {
                                dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inEnd = true;
                            } else {
                                dec.queueInputBuffer(ii, 0, sz, ex.getSampleTime(), 0);
                                ex.advance();
                            }
                        }
                    }
                    int oi = dec.dequeueOutputBuffer(info, 10000);
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat of = dec.getOutputFormat();
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    } else if (oi >= 0) {
                        ByteBuffer ob = dec.getOutputBuffer(oi);
                        if (ob != null && info.size > 0) {
                            ob.position(info.offset);
                            ob.limit(info.offset + info.size);
                            ShortBuffer sb = ob.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
                            short[] in = new short[sb.remaining()];
                            sb.get(in);
                            int frames = in.length / Math.max(1, ch);
                            double step = srcRate / (double) RATE;   // 44100に合わせる
                            double pos = carry;
                            while (pos < frames && running) {
                                int i = (int) pos;
                                short l = in[i * ch];
                                short r = ch > 1 ? in[i * ch + 1] : l;
                                push(l, r);
                                pos += step;
                            }
                            carry = pos - frames;
                            playedSomething = true;
                        }
                        dec.releaseOutputBuffer(oi, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;   // 最後まで来た → くり返す
                    }
                }
            } catch (Exception e) {
                fails++;
            } finally {
                try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) { }
                try { ex.release(); } catch (Exception ignored) { }
            }
            if (playedSomething) fails = 0;
            else fails++;
        }
    }
}
