package jp.synccam.game;

import android.opengl.Matrix;

import com.pedro.encoder.input.gl.render.filters.RotationFilterRender;

/**
 * ゲーム画面（配信のいちばん下の絵）を、真ん中を中心に大きく・小さくする。
 * 大きくすると角が切れて真ん中だけになり、小さくするとまわりが黒くなる。
 */
public class ZoomFilterRender extends RotationFilterRender {
    public void setZoom(float s) {
        Matrix.setIdentityM(MVPMatrix, 0);
        Matrix.scaleM(MVPMatrix, 0, s, s, 1f);
    }
}
