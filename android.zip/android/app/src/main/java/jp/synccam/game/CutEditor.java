package jp.synccam.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.OverScroller;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.ChannelMixingAudioProcessor;
import androidx.media3.common.audio.ChannelMixingMatrix;
import androidx.media3.common.audio.SonicAudioProcessor;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * CapCut風の動画編集：分割・削除（切り込み）、速度、音量、音源（BGM）。
 * 「エクスポート」で写真フォルダ（ムービー/SyncCam）に保存する。
 */
public class CutEditor {

    static final int REQ_MUSIC = 106;
    static final int BG = Color.rgb(20, 20, 20), BAR = Color.rgb(28, 28, 28), CYAN = Color.rgb(24, 214, 232),
            DIM = Color.rgb(160, 160, 160), TRACK = Color.rgb(40, 40, 40);

    final Activity a;
    final File src;
    final Handler h = new Handler(Looper.getMainLooper());
    final long dur;
    final View view;

    /** 1つの区切り（元の動画のどこからどこまで・速さ・音量） */
    static class Seg {
        long s, e;
        float speed = 1f, vol = 1f;
        Seg(long s, long e) { this.s = s; this.e = e; }
        Seg copy() { Seg g = new Seg(s, e); g.speed = speed; g.vol = vol; return g; }
    }

    List<Seg> segs = new ArrayList<>();
    final ArrayDeque<List<Seg>> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    int sel = -1;
    File music;
    String musicName;
    float musicVol = 0.8f;

    VideoView vv;
    MediaPlayer mp, bgm;
    boolean playing = false, released = false;
    int cur = 0;
    long ignoreUntil = 0;
    long outT = 0;
    TextView timeLabel, playBtn;
    Timeline tl;
    Bitmap[] thumbs;
    long thumbStep = 1000;
    Transformer transformer;

    CutEditor(Activity a, File src) {
        this.a = a;
        this.src = src;
        this.dur = Math.max(1000, Trimmer.durationMs(src.getPath()));
        segs.add(new Seg(0, dur));
        File m = new File(a.getFilesDir(), "editMusic");
        if (m.exists()) m.delete();
        view = build();
        loadThumbs();
        h.post(tick);
    }

    int dp(float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }

    void toast(String s) { Toast.makeText(a, s, Toast.LENGTH_SHORT).show(); }

    GradientDrawable round(int c, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    TextView text(String s, float sp, int c) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(c);
        return t;
    }

    /* ================= 画面 ================= */

    View build() {
        LinearLayout outer = new LinearLayout(a);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(BG);

        // 上：✕ と エクスポート
        FrameLayout top = new FrameLayout(a);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));
        TextView close = text("✕", 24, Color.WHITE);
        close.setPadding(dp(10), dp(4), dp(10), dp(4));
        close.setOnClickListener(v -> a.onBackPressed());
        top.addView(close, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        Button exp = new Button(a);
        exp.setText("エクスポート");
        exp.setAllCaps(false);
        exp.setTextColor(Color.rgb(0, 30, 35));
        exp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        exp.setTypeface(Typeface.DEFAULT_BOLD);
        exp.setBackground(round(CYAN, 12));
        exp.setStateListAnimator(null);
        exp.setPadding(dp(18), dp(6), dp(18), dp(6));
        exp.setOnClickListener(v -> exportVideo());
        top.addView(exp, new FrameLayout.LayoutParams(-2, dp(44), Gravity.END | Gravity.CENTER_VERTICAL));
        outer.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // プレビュー
        FrameLayout pv = new FrameLayout(a);
        pv.setBackgroundColor(Color.BLACK);
        vv = new VideoView(a);
        vv.setVideoPath(src.getPath());
        vv.setOnPreparedListener(p -> {
            mp = p;
            mp.setLooping(false);
            seekSrc(srcAt(outT));
        });
        vv.setOnCompletionListener(p -> { if (playing) nextSeg(); });
        pv.addView(vv, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        pv.setOnClickListener(v -> togglePlay());
        outer.addView(pv, new LinearLayout.LayoutParams(-1, 0, 1));

        // 時間・再生・元に戻す
        FrameLayout ctl = new FrameLayout(a);
        ctl.setBackgroundColor(BG);
        ctl.setPadding(dp(14), dp(4), dp(14), dp(4));
        timeLabel = text("00:00 / 00:00", 13, Color.WHITE);
        ctl.addView(timeLabel, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        playBtn = text("▶", 26, Color.WHITE);
        playBtn.setPadding(dp(16), 0, dp(16), 0);
        playBtn.setOnClickListener(v -> togglePlay());
        ctl.addView(playBtn, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        LinearLayout ur = new LinearLayout(a);
        TextView u = text("↶", 26, Color.WHITE), r = text("↷", 26, Color.WHITE);
        u.setPadding(dp(12), 0, dp(12), 0);
        r.setPadding(dp(12), 0, dp(4), 0);
        u.setOnClickListener(v -> doUndo());
        r.setOnClickListener(v -> doRedo());
        ur.addView(u);
        ur.addView(r);
        ctl.addView(ur, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL));
        outer.addView(ctl, new LinearLayout.LayoutParams(-1, dp(52)));

        // タイムライン
        tl = new Timeline(a);
        outer.addView(tl, new LinearLayout.LayoutParams(-1, dp(176)));

        // 下の道具
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(BAR);
        LinearLayout bar = new LinearLayout(a);
        bar.setPadding(dp(6), dp(8), dp(6), dp(10));
        bar.addView(tool("✂", "分割", v -> split()));
        bar.addView(tool("⏩", "速度", v -> speedSheet()));
        bar.addView(tool("🔊", "音量", v -> volumeSheet()));
        bar.addView(tool("♪", "音源", v -> musicSheet()));
        bar.addView(tool("🗑", "削除", v -> deleteSeg()));
        hs.addView(bar);
        outer.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        updateTime();
        return outer;
    }

    View tool(String icon, String label, View.OnClickListener l) {
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(4), dp(14), dp(4));
        TextView i = text(icon, 22, Color.WHITE);
        i.setGravity(Gravity.CENTER);
        TextView n = text(label, 12, Color.WHITE);
        n.setGravity(Gravity.CENTER);
        t.addView(i);
        t.addView(n);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(76), -2);
        t.setLayoutParams(p);
        return t;
    }

    /* ================= 時間の計算 ================= */

    static long outLen(Seg g) { return (long) ((g.e - g.s) / g.speed); }

    long total() {
        long t = 0;
        for (Seg g : segs) t += outLen(g);
        return Math.max(1, t);
    }

    long outStart(int i) {
        long t = 0;
        for (int k = 0; k < i; k++) t += outLen(segs.get(k));
        return t;
    }

    int segAt(long t) {
        long acc = 0;
        for (int i = 0; i < segs.size(); i++) {
            long l = outLen(segs.get(i));
            if (t < acc + l) return i;
            acc += l;
        }
        return segs.size() - 1;
    }

    long srcAt(long t) {
        int i = segAt(t);
        Seg g = segs.get(i);
        long s = g.s + (long) ((t - outStart(i)) * g.speed);
        return Math.max(g.s, Math.min(g.e - 1, s));
    }

    static String fmt(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    void updateTime() {
        if (timeLabel != null) timeLabel.setText(fmt(outT) + " / " + fmt(total()));
    }

    /* ================= 再生 ================= */

    void seekSrc(long s) {
        try {
            if (mp != null && Build.VERSION.SDK_INT >= 26) mp.seekTo(s, MediaPlayer.SEEK_CLOSEST);
            else vv.seekTo((int) s);
        } catch (Exception e) {
            try { vv.seekTo((int) s); } catch (Exception ignored) { }
        }
    }

    void applySeg(Seg g) {
        if (mp == null) return;
        try {
            if (playing) mp.setPlaybackParams(new PlaybackParams().setSpeed(g.speed));
        } catch (Exception ignored) { }
        try {
            float v = Math.min(1f, g.vol);
            mp.setVolume(v, v);
        } catch (Exception ignored) { }
    }

    void togglePlay() {
        if (playing) pause(); else play();
    }

    void play() {
        if (mp == null) return;
        if (outT >= total() - 50) outT = 0;
        cur = segAt(outT);
        playing = true;
        seekSrc(srcAt(outT));
        ignoreUntil = SystemClock.uptimeMillis() + 300;
        vv.start();
        applySeg(segs.get(cur));
        playBtn.setText("❚❚");
        if (bgm != null) {
            try {
                int md = Math.max(1, bgm.getDuration());
                bgm.seekTo((int) (outT % md));
                bgm.setVolume(musicVol, musicVol);
                bgm.start();
            } catch (Exception ignored) { }
        }
    }

    void pause() {
        playing = false;
        try { vv.pause(); } catch (Exception ignored) { }
        try { if (bgm != null && bgm.isPlaying()) bgm.pause(); } catch (Exception ignored) { }
        if (playBtn != null) playBtn.setText("▶");
    }

    void nextSeg() {
        cur++;
        if (cur >= segs.size()) {
            pause();
            outT = 0;
            cur = 0;
            seekSrc(srcAt(0));
            tl.invalidate();
            updateTime();
            return;
        }
        Seg n = segs.get(cur);
        outT = outStart(cur);
        seekSrc(n.s);
        ignoreUntil = SystemClock.uptimeMillis() + 300;
        if (!vv.isPlaying()) vv.start();
        applySeg(n);
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (released) return;
            if (playing && mp != null && cur < segs.size()) {
                long now = SystemClock.uptimeMillis();
                int pos = vv.getCurrentPosition();
                Seg g = segs.get(cur);
                if (now > ignoreUntil && pos >= g.e - 30) {
                    nextSeg();
                } else if (now > ignoreUntil) {
                    outT = outStart(cur) + (long) (Math.max(0, pos - g.s) / g.speed);
                    tl.invalidate();
                    updateTime();
                }
            }
            h.postDelayed(this, 30);
        }
    };

    /** タイムラインを指で動かしたとき */
    void scrubTo(long t) {
        if (playing) pause();
        outT = Math.max(0, Math.min(total(), t));
        cur = segAt(outT);
        seekSrc(srcAt(outT));
        updateTime();
    }

    /* ================= 編集 ================= */

    List<Seg> snap() {
        List<Seg> l = new ArrayList<>();
        for (Seg g : segs) l.add(g.copy());
        return l;
    }

    void push() {
        undo.push(snap());
        while (undo.size() > 50) undo.removeLast();
        redo.clear();
    }

    void doUndo() {
        if (undo.isEmpty()) { toast("これ以上戻せません"); return; }
        pause();
        redo.push(snap());
        segs = undo.pop();
        afterEdit();
    }

    void doRedo() {
        if (redo.isEmpty()) { toast("やり直せる操作がありません"); return; }
        pause();
        undo.push(snap());
        segs = redo.pop();
        afterEdit();
    }

    void afterEdit() {
        if (sel >= segs.size()) sel = -1;
        outT = Math.min(outT, total());
        cur = segAt(outT);
        seekSrc(srcAt(outT));
        tl.invalidate();
        updateTime();
    }

    /** 選んでいる区切り（なければ、再生位置の区切りを選ぶ） */
    int target() {
        if (sel < 0 || sel >= segs.size()) sel = segAt(outT);
        tl.invalidate();
        return sel;
    }

    void split() {
        pause();
        int i = segAt(outT);
        Seg g = segs.get(i);
        long at = srcAt(outT);
        if (at - g.s < 100 || g.e - at < 100) { toast("区切りの端なので分割できません。少しずらしてください"); return; }
        push();
        Seg b = g.copy();
        g.e = at;
        b.s = at;
        segs.add(i + 1, b);
        sel = i + 1;
        afterEdit();
        toast("分割しました");
    }

    void deleteSeg() {
        pause();
        int i = target();
        if (segs.size() <= 1) { toast("最後の1つは削除できません"); return; }
        push();
        segs.remove(i);
        sel = -1;
        outT = Math.min(outStart(Math.min(i, segs.size() - 1)), total());
        afterEdit();
        toast("削除しました");
    }

    LinearLayout sheetBox() {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), dp(4));
        return box;
    }

    void speedSheet() {
        pause();
        int i = target();
        Seg g = segs.get(i);
        float[] val = {g.speed};
        LinearLayout box = sheetBox();
        TextView lab = text("", 28, Color.WHITE);
        lab.setTypeface(Typeface.DEFAULT_BOLD);
        lab.setGravity(Gravity.CENTER);
        box.addView(lab);
        SeekBar sb = new SeekBar(a);
        sb.setMax(490);   // 0.1x 〜 5.0x
        Runnable show = () -> lab.setText(String.format(Locale.US, "%.1fx", val[0]));
        sb.setProgress(Math.round(val[0] * 100) - 10);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) { val[0] = Math.round((p + 10) / 10f) / 10f; show.run(); } }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(-1, dp(48)));
        LinearLayout presets = new LinearLayout(a);
        for (float f : new float[]{0.5f, 1f, 1.5f, 2f, 3f}) {
            TextView b = text((f == (int) f ? String.valueOf((int) f) : String.valueOf(f)) + "x", 15, Color.WHITE);
            b.setGravity(Gravity.CENTER);
            b.setBackground(round(TRACK, 10));
            b.setOnClickListener(v -> { val[0] = f; sb.setProgress(Math.round(f * 100) - 10); show.run(); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1);
            p.leftMargin = p.rightMargin = dp(3);
            presets.addView(b, p);
        }
        box.addView(presets);
        show.run();
        new AlertDialog.Builder(a).setTitle("速度（選んでいる区切り）").setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    push();
                    g.speed = Math.max(0.1f, Math.min(5f, val[0]));
                    afterEdit();
                })
                .setNegativeButton("キャンセル", null).show();
    }

    void volumeSheet() {
        pause();
        int i = target();
        Seg g = segs.get(i);
        int[] val = {Math.round(g.vol * 100)};
        LinearLayout box = sheetBox();
        TextView lab = text("", 28, Color.WHITE);
        lab.setTypeface(Typeface.DEFAULT_BOLD);
        lab.setGravity(Gravity.CENTER);
        box.addView(lab);
        SeekBar sb = new SeekBar(a);
        sb.setMax(200);
        sb.setProgress(val[0]);
        Runnable show = () -> lab.setText(val[0] == 0 ? "ミュート" : val[0] + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { val[0] = p; show.run(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(-1, dp(48)));
        box.addView(text("100%より大きくすると、保存した動画で大きくなります（プレビューは100%まで）", 11, DIM));
        show.run();
        new AlertDialog.Builder(a).setTitle("音量（選んでいる区切り）").setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    push();
                    g.vol = val[0] / 100f;
                    afterEdit();
                })
                .setNegativeButton("キャンセル", null).show();
    }

    /* ================= 音源（BGM） ================= */

    void musicSheet() {
        pause();
        if (music == null) { pickMusic(); return; }
        int[] val = {Math.round(musicVol * 100)};
        LinearLayout box = sheetBox();
        box.addView(text("♪ " + musicName, 15, Color.WHITE));
        TextView lab = text("", 22, Color.WHITE);
        lab.setGravity(Gravity.CENTER);
        box.addView(lab);
        SeekBar sb = new SeekBar(a);
        sb.setMax(200);
        sb.setProgress(val[0]);
        Runnable show = () -> lab.setText("音源の音量 " + val[0] + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { val[0] = p; show.run(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(-1, dp(48)));
        show.run();
        new AlertDialog.Builder(a).setTitle("音源").setView(box)
                .setPositiveButton("OK", (d, w) -> { musicVol = val[0] / 100f; tl.invalidate(); })
                .setNeutralButton("音源を外す", (d, w) -> removeMusic())
                .setNegativeButton("変更", (d, w) -> pickMusic())
                .show();
    }

    void pickMusic() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            a.startActivityForResult(Intent.createChooser(i, "音源を選ぶ（音楽、または動画の音）"), REQ_MUSIC);
        } catch (Exception e) {
            toast("ファイルを選べませんでした");
        }
    }

    void onMusicPicked(Uri u) {
        if (u == null) return;
        try {
            File f = new File(a.getFilesDir(), "editMusic");
            try (InputStream in = a.getContentResolver().openInputStream(u); OutputStream out = new java.io.FileOutputStream(f)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            String name = "音源";
            try (Cursor c = a.getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) name = c.getString(idx);
                }
            } catch (Exception ignored) { }
            releaseBgm();
            music = f;
            musicName = name;
            bgm = new MediaPlayer();
            bgm.setDataSource(f.getPath());
            bgm.setLooping(true);
            bgm.prepare();
            tl.invalidate();
            toast("音源を追加しました");
        } catch (Exception e) {
            music = null;
            releaseBgm();
            toast("この音源は使えませんでした");
        }
    }

    void removeMusic() {
        releaseBgm();
        if (music != null) music.delete();
        music = null;
        musicName = null;
        tl.invalidate();
    }

    void releaseBgm() {
        try { if (bgm != null) bgm.release(); } catch (Exception ignored) { }
        bgm = null;
    }

    /* ================= サムネイル ================= */

    void loadThumbs() {
        thumbStep = Math.max(1000, (dur / 150) / 1000 * 1000);
        int n = (int) (dur / thumbStep) + 1;
        thumbs = new Bitmap[n];
        int th = dp(64);
        new Thread(() -> {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(src.getPath());
                for (int i = 0; i < n && !released; i++) {
                    Bitmap b = r.getFrameAtTime(i * thumbStep * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (b == null) continue;
                    float k = th / (float) b.getHeight();
                    Bitmap s = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)), th, true);
                    if (s != b) b.recycle();
                    thumbs[i] = s;
                    if (i % 4 == 0) h.post(() -> { if (tl != null) tl.invalidate(); });
                }
            } catch (Exception ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
                h.post(() -> { if (tl != null) tl.invalidate(); });
            }
        }).start();
    }

    Bitmap thumbAt(long srcMs) {
        if (thumbs == null) return null;
        int i = (int) Math.round(srcMs / (double) thumbStep);
        for (int d = 0; d < 4; d++) {
            if (i - d >= 0 && i - d < thumbs.length && thumbs[i - d] != null) return thumbs[i - d];
            if (i + d >= 0 && i + d < thumbs.length && thumbs[i + d] != null) return thumbs[i + d];
        }
        return null;
    }

    /* ================= タイムライン（指で左右・2本指で拡大縮小） ================= */

    class Timeline extends View {
        float pps = dp(60);   // 1秒あたりの幅
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final OverScroller scroller;
        VelocityTracker vt;
        final ScaleGestureDetector zoom;
        float lastX, downX, downY;
        boolean moved = false, scaling = false;

        Timeline(Context c) {
            super(c);
            setBackgroundColor(BG);
            scroller = new OverScroller(c);
            zoom = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                public boolean onScaleBegin(ScaleGestureDetector d) { scaling = true; return true; }
                public boolean onScale(ScaleGestureDetector d) {
                    pps = Math.max(dp(1), Math.min(dp(300), pps * d.getScaleFactor()));
                    invalidate();
                    return true;
                }
            });
        }

        float trackTop() { return dp(30); }
        float trackH() { return dp(64); }
        float musicTop() { return dp(110); }
        float musicH() { return dp(40); }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), cx = W / 2f;
            float x0 = cx - outT / 1000f * pps;   // 動画の始まりのx

            // 目盛り
            p.setTextSize(dp(11));
            p.setColor(DIM);
            p.setTextAlign(Paint.Align.CENTER);
            float stepSec = 1;
            while (stepSec * pps < dp(70)) stepSec = stepSec < 5 ? 5 : stepSec * 2;
            long tot = total();
            for (float s = 0; s <= tot / 1000f + stepSec; s += stepSec) {
                float x = x0 + s * pps;
                if (x < -dp(40) || x > W + dp(40)) continue;
                c.drawText(fmt((long) (s * 1000)), x, dp(16), p);
                c.drawCircle(x + stepSec * pps / 2, dp(12), dp(1.5f), p);
            }

            // 動画の区切り
            float top = trackTop(), th = trackH();
            long acc = 0;
            for (int i = 0; i < segs.size(); i++) {
                Seg g = segs.get(i);
                long len = outLen(g);
                float l = x0 + acc / 1000f * pps, r = x0 + (acc + len) / 1000f * pps;
                acc += len;
                if (r < 0 || l > W) continue;
                c.save();
                RectF rr = new RectF(l + dp(1), top, r - dp(1), top + th);
                android.graphics.Path clip = new android.graphics.Path();
                clip.addRoundRect(rr, dp(6), dp(6), android.graphics.Path.Direction.CW);
                c.clipPath(clip);
                p.setColor(TRACK);
                c.drawRect(rr, p);
                // サムネイルを並べる
                float tw = th * 9f / 16f;
                Bitmap any = thumbAt(g.s);
                if (any != null) tw = th * any.getWidth() / (float) any.getHeight();
                for (float x = Math.max(l, l + (float) Math.floor((0 - l) / tw) * tw); x < Math.min(r, W); x += tw) {
                    long srcMs = g.s + (long) (((x - l) / pps) * 1000 * g.speed);
                    Bitmap b = thumbAt(srcMs);
                    if (b != null) c.drawBitmap(b, null, new RectF(x, top, x + tw, top + th), null);
                }
                c.restore();
                // 速度・音量の表示
                String info = "";
                if (Math.abs(g.speed - 1) > 0.01) info += String.format(Locale.US, "%.1fx ", g.speed);
                if (Math.abs(g.vol - 1) > 0.01) info += (g.vol == 0 ? "🔇" : Math.round(g.vol * 100) + "%");
                if (!info.isEmpty() && r - l > dp(40)) {
                    p.setTextAlign(Paint.Align.LEFT);
                    p.setTextSize(dp(11));
                    float w = p.measureText(info);
                    p.setColor(Color.argb(170, 0, 0, 0));
                    c.drawRoundRect(new RectF(l + dp(5), top + dp(4), l + dp(13) + w, top + dp(20)), dp(4), dp(4), p);
                    p.setColor(Color.WHITE);
                    c.drawText(info, l + dp(9), top + dp(16), p);
                }
                if (i == sel) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(3));
                    p.setColor(Color.WHITE);
                    c.drawRoundRect(new RectF(l + dp(2), top - dp(1), r - dp(2), top + th + dp(1)), dp(6), dp(6), p);
                    p.setStyle(Paint.Style.FILL);
                }
            }

            // 音源
            float mt = musicTop(), mh = musicH();
            float mr = x0 + tot / 1000f * pps;
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(dp(13));
            if (music != null) {
                p.setColor(Color.rgb(13, 110, 120));
                c.drawRoundRect(new RectF(x0, mt, mr, mt + mh), dp(6), dp(6), p);
                p.setColor(Color.WHITE);
                String s = "♪ " + musicName + "  " + Math.round(musicVol * 100) + "%";
                c.drawText(s, Math.max(x0, 0) + dp(10), mt + mh / 2 + dp(5), p);
            } else {
                p.setColor(TRACK);
                float w = Math.max(dp(150), Math.min(mr - x0, dp(220)));
                c.drawRoundRect(new RectF(x0, mt, x0 + w, mt + mh), dp(6), dp(6), p);
                p.setColor(DIM);
                c.drawText("＋ 音源を追加", x0 + dp(12), mt + mh / 2 + dp(5), p);
            }

            // 真ん中の再生位置の線
            p.setColor(Color.WHITE);
            c.drawRect(cx - dp(1), dp(24), cx + dp(1), getHeight() - dp(6), p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            zoom.onTouchEvent(e);
            if (vt == null) vt = VelocityTracker.obtain();
            vt.addMovement(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    scroller.forceFinished(true);
                    lastX = downX = e.getX();
                    downY = e.getY();
                    moved = false;
                    scaling = false;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (scaling || e.getPointerCount() > 1) { lastX = e.getX(); moved = true; return true; }
                    float dx = e.getX() - lastX;
                    lastX = e.getX();
                    if (Math.abs(e.getX() - downX) > dp(6)) moved = true;
                    if (moved) {
                        scrubTo(outT - (long) (dx / pps * 1000));
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved && !scaling) tap(e.getX(), e.getY());
                    else if (!scaling) {
                        vt.computeCurrentVelocity(1000);
                        float v = vt.getXVelocity();
                        if (Math.abs(v) > dp(300)) {
                            int start = (int) (outT / 1000f * pps);
                            scroller.fling(start, 0, (int) -v, 0, 0, (int) (total() / 1000f * pps), 0, 0);
                            postInvalidateOnAnimation();
                        }
                    }
                    vt.recycle();
                    vt = null;
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    if (vt != null) { vt.recycle(); vt = null; }
                    return true;
            }
            return true;
        }

        @Override
        public void computeScroll() {
            if (scroller.computeScrollOffset()) {
                scrubTo((long) (scroller.getCurrX() / pps * 1000));
                postInvalidateOnAnimation();
            }
        }

        void tap(float x, float y) {
            float cx = getWidth() / 2f;
            long t = outT + (long) ((x - cx) / pps * 1000);
            if (y >= musicTop() - dp(4)) {
                musicSheet();
                return;
            }
            if (y >= trackTop() && y <= trackTop() + trackH() && t >= 0 && t <= total()) {
                int i = segAt(t);
                sel = (sel == i) ? -1 : i;
            } else {
                sel = -1;
            }
            invalidate();
        }
    }

    /* ================= 書き出し → 写真フォルダへ ================= */

    static AudioProcessor volume(float v) {
        ChannelMixingAudioProcessor p = new ChannelMixingAudioProcessor();
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v));
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v));
        return p;
    }

    void exportVideo() {
        pause();
        if (Build.VERSION.SDK_INT < 29 && a.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 107);
            toast("保存の許可をしてから、もう一度エクスポートを押してください");
            return;
        }
        Composition comp;
        try {
            List<EditedMediaItem> items = new ArrayList<>();
            for (Seg g : segs) {
                MediaItem mi = new MediaItem.Builder().setUri(Uri.fromFile(src))
                        .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(g.s).setEndPositionMs(g.e).build())
                        .build();
                List<AudioProcessor> ap = new ArrayList<>();
                List<Effect> ve = new ArrayList<>();
                if (Math.abs(g.speed - 1) > 0.01) {
                    SonicAudioProcessor so = new SonicAudioProcessor();
                    so.setSpeed(g.speed);
                    ap.add(so);
                    ve.add(new SpeedChangeEffect(g.speed));
                }
                if (Math.abs(g.vol - 1) > 0.01) ap.add(volume(g.vol));
                items.add(new EditedMediaItem.Builder(mi).setEffects(new Effects(ap, ve)).build());
            }
            List<EditedMediaItemSequence> seqs = new ArrayList<>();
            seqs.add(new EditedMediaItemSequence(items));
            if (music != null) {
                List<AudioProcessor> ap = new ArrayList<>();
                if (Math.abs(musicVol - 1) > 0.01) ap.add(volume(musicVol));
                EditedMediaItem m = new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music)))
                        .setRemoveVideo(true)
                        .setEffects(new Effects(ap, new ArrayList<>()))
                        .build();
                seqs.add(new EditedMediaItemSequence(Collections.singletonList(m), true));
            }
            comp = new Composition.Builder(seqs).build();
        } catch (Exception e) {
            toast("書き出しの準備に失敗しました：" + e.getMessage());
            return;
        }

        File out = new File(a.getCacheDir(), "edit_out.mp4");
        if (out.exists()) out.delete();
        TextView msg = text("書き出し中… 0%", 16, Color.WHITE);
        msg.setPadding(dp(24), dp(20), dp(24), dp(10));
        AlertDialog dlg = new AlertDialog.Builder(a).setTitle("エクスポート").setView(msg).setCancelable(false)
                .setNegativeButton("キャンセル", (d, w) -> { try { if (transformer != null) transformer.cancel(); } catch (Exception ignored) { } transformer = null; })
                .show();
        transformer = new Transformer.Builder(a)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition c, ExportResult r) {
                        transformer = null;
                        try { dlg.dismiss(); } catch (Exception ignored) { }
                        try {
                            String where = saveToGallery(a, out);
                            out.delete();
                            new AlertDialog.Builder(a).setTitle("保存しました")
                                    .setMessage("写真フォルダ（" + where + "）に保存しました。")
                                    .setPositiveButton("OK", null).show();
                        } catch (Exception e) {
                            toast("写真フォルダに保存できませんでした：" + e.getMessage());
                        }
                    }

                    @Override
                    public void onError(Composition c, ExportResult r, ExportException e) {
                        transformer = null;
                        try { dlg.dismiss(); } catch (Exception ignored) { }
                        new AlertDialog.Builder(a).setTitle("書き出しに失敗しました")
                                .setMessage(String.valueOf(e.getMessage()))
                                .setPositiveButton("OK", null).show();
                    }
                })
                .build();
        try {
            transformer.start(comp, out.getPath());
        } catch (Exception e) {
            transformer = null;
            dlg.dismiss();
            toast("書き出しを始められませんでした：" + e.getMessage());
            return;
        }
        ProgressHolder ph = new ProgressHolder();
        h.post(new Runnable() {
            public void run() {
                Transformer t = transformer;
                if (t == null || released) return;
                try {
                    if (t.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) msg.setText("書き出し中… " + ph.progress + "%");
                } catch (Exception ignored) { }
                h.postDelayed(this, 300);
            }
        });
    }

    /** ムービー/SyncCam に保存して、どこに入ったかを返す */
    static String saveToGallery(Context c, File f) throws Exception {
        String name = "SyncCam_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new java.util.Date()) + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SyncCam");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri u = c.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("保存先を作れません");
            try (InputStream in = new FileInputStream(f); OutputStream out = c.getContentResolver().openOutputStream(u)) {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            c.getContentResolver().update(u, done, null, null);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "SyncCam");
            dir.mkdirs();
            File dst = new File(dir, name);
            try (InputStream in = new FileInputStream(f); OutputStream out = new java.io.FileOutputStream(dst)) {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            MediaScannerConnection.scanFile(c, new String[]{dst.getPath()}, new String[]{"video/mp4"}, null);
        }
        return "ムービー › SyncCam";
    }

    /* ================= 後片づけ ================= */

    boolean dirty() { return !undo.isEmpty() || music != null; }

    void release() {
        released = true;
        playing = false;
        h.removeCallbacksAndMessages(null);
        try { vv.stopPlayback(); } catch (Exception ignored) { }
        releaseBgm();
        try { if (transformer != null) transformer.cancel(); } catch (Exception ignored) { }
        transformer = null;
        if (thumbs != null) for (Bitmap b : thumbs) if (b != null) b.recycle();
        thumbs = null;
    }
}
