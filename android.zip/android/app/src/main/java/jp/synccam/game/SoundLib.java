package jp.synccam.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 「保存した音源」：一度選んだ音（音楽ファイル、または動画の音）をアプリの中に取っておく。
 * 動画を選んだときは、音だけを取り出して保存する。
 */
public class SoundLib {

    static class Item {
        final String id, name;
        Item(String id, String name) { this.id = id; this.name = name; }
    }

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("synccam", Context.MODE_PRIVATE); }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "sounds");
        d.mkdirs();
        return d;
    }

    static File file(Context c, String id) { return new File(dir(c), id); }

    static List<Item> list(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("soundLib", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String id = o.optString("id");
                if (file(c, id).exists()) out.add(new Item(id, o.optString("name", "音源")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    static void save(Context c, List<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) a.put(new JSONObject().put("id", it.id).put("name", it.name));
        } catch (Exception ignored) { }
        sp(c).edit().putString("soundLib", a.toString()).apply();
    }

    static void rename(Context c, String id, String name) {
        List<Item> l = list(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).id.equals(id)) l.set(i, new Item(id, name));
        save(c, l);
    }

    static void delete(Context c, String id) {
        List<Item> l = list(c);
        List<Item> keep = new ArrayList<>();
        for (Item it : l) if (!it.id.equals(id)) keep.add(it);
        file(c, id).delete();
        save(c, keep);
    }

    /** 選んだファイルを「保存した音源」に入れる（いちばん上に）。入れたものを返す */
    static Item importUri(Context c, Uri uri, String name) throws Exception {
        String id = "s" + System.currentTimeMillis();
        File tmp = new File(c.getCacheDir(), "import_" + id);
        try (InputStream in = c.getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(tmp)) {
            if (in == null) throw new Exception("ファイルを開けません");
            byte[] buf = new byte[65536];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                o.write(buf, 0, n);
                total += n;
                if (total > 300L * 1024 * 1024) throw new Exception("大きすぎます");
            }
        }
        File dst = file(c, id);
        boolean hasVideo = false, hasAudio = false;
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(tmp.getPath());
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (m == null) continue;
                if (m.startsWith("video/")) hasVideo = true;
                if (m.startsWith("audio/")) hasAudio = true;
            }
        } catch (Exception ignored) {
        } finally {
            ex.release();
        }
        if (hasVideo && !hasAudio) { tmp.delete(); throw new Exception("この動画には音が入っていません"); }
        // 動画なら音だけ取り出す（できなければ、そのまま保存しても音は使える）
        if (!(hasVideo && extractAudio(tmp, dst))) {
            if (!tmp.renameTo(dst)) copy(tmp, dst);
        }
        tmp.delete();
        String clean = name == null ? "音源" : name.replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        Item it = new Item(id, clean.isEmpty() ? "音源" : clean);
        List<Item> l = list(c);
        l.add(0, it);
        save(c, l);
        return it;
    }

    static void copy(File a, File b) throws Exception {
        try (InputStream in = new FileInputStream(a); OutputStream o = new FileOutputStream(b)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    /** 動画の音（AAC）だけを .m4a にして保存する */
    static boolean extractAudio(File src, File dst) {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mux = null;
        boolean ok = false;
        try {
            ex.setDataSource(src.getPath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/mp4a")) { track = i; fmt = f; break; }
            }
            if (track < 0) return false;
            ex.selectTrack(track);
            mux = new MediaMuxer(dst.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int out = mux.addTrack(fmt);
            mux.start();
            ByteBuffer buf = ByteBuffer.allocate(1 << 20);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                int sz = ex.readSampleData(buf, 0);
                if (sz < 0) break;
                info.offset = 0;
                info.size = sz;
                info.presentationTimeUs = ex.getSampleTime();
                info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                mux.writeSampleData(out, buf, info);
                ex.advance();
            }
            ok = true;
        } catch (Exception e) {
            ok = false;
        } finally {
            try { if (mux != null) { mux.stop(); mux.release(); } } catch (Exception e) { ok = false; }
            ex.release();
            if (!ok) dst.delete();
        }
        return ok;
    }
}
