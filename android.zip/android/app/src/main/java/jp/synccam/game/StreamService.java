package jp.synccam.game;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.widget.Toast;

import androidx.lifecycle.LifecycleService;

import com.pedro.common.ConnectChecker;
import com.pedro.library.rtmp.RtmpDisplay;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 配信の本体。ホーム画面に戻っても、ここで配信が続く */
public class StreamService extends LifecycleService implements ConnectChecker, Overlay.Listener {

    static volatile StreamService instance;
    static final String CH = "synccam_live";

    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newCachedThreadPool();   // 終了ボタンが待たされないよう、仕事ごとに別の道

    RtmpDisplay display;
    YouTube yt;
    Overlay overlay;
    Compositor comp;
    int streamW, streamH;
    boolean micOn = true, paused = false;
    String recPath;
    final java.util.ArrayDeque<String> chatLines = new java.util.ArrayDeque<>();
    String title, desc, cat, game, thumb, rtmpUrl, bid, sid, chatId, pageToken;
    volatile int state = 0;         // 0準備中 1待機中 2公開準備 3ライブ中 4終了処理
    volatile boolean ending = false;
    volatile boolean wantLive = false;      // 準備中に「はい」が押された
    volatile String busyStep = "公開を始めています…";

    static boolean running() { return instance != null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        if (intent == null || instance != null) return START_NOT_STICKY;
        instance = this;

        // Android 14 からは、画面の録画を始める前に「前面サービス」になっている必要がある
        createChannel();
        Notification n = notification("配信の準備中…");
        int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (mic && Build.VERSION.SDK_INT >= 30) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        String camMode = Parts.mode(this);
        boolean cam = !camMode.isEmpty() && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (cam && Build.VERSION.SDK_INT >= 30) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, type);
            else startForeground(1, n);
        } catch (Exception e) {
            fail("配信を始められませんでした：" + e.getMessage());
            return START_NOT_STICKY;
        }

        title = intent.getStringExtra("title");
        desc = intent.getStringExtra("desc");
        cat = intent.getStringExtra("cat");
        game = intent.getStringExtra("game");
        thumb = intent.getStringExtra("thumb");
        if (game != null && !game.isEmpty()) desc = (desc == null ? "" : desc) + "\n\nゲーム：" + game;
        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");

        String email = intent.getStringExtra("email");
        if (email == null || email.isEmpty()) { fail("配信するGoogleアカウントが選ばれていません"); return START_NOT_STICKY; }
        yt = new YouTube(this, email);
        String tok = intent.getStringExtra("token");
        if (tok != null && !tok.isEmpty()) yt.setToken(tok);
        overlay = new Overlay(this, this);
        overlay.iconFile = new java.io.File(getFilesDir(), Auth.avatarName(email));
        try { overlay.show(); } catch (Exception e) { fail("黒い丸を表示できません。「他のアプリの上に重ねて表示」を許可してください"); return START_NOT_STICKY; }

        // ショート＝縦（720×1280）、ロング＝横（1280×720）。
        // ライブラリの決まりで、大きさは横長で渡して、縦のときは90度を指定する
        boolean longLive = Parts.isLong(this);
        streamW = longLive ? 1280 : 720;
        streamH = longLive ? 720 : 1280;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        try {
            display = new RtmpDisplay(this, true, this);
            display.setIntentResult(code, data);
            boolean v = display.prepareVideo(1280, 720, 30, 3500 * 1024, longLive ? 0 : 90, dm.densityDpi);
            boolean a = mic && display.prepareAudio(128 * 1024, 44100, true, true, true);
            if (!v) { fail("この端末では画面の配信を準備できませんでした"); return START_NOT_STICKY; }
            if (!a) toast("マイクが使えないため、音声なしで配信します");
            if (a) startBgm();
        } catch (Exception e) {
            fail("画面の配信を準備できませんでした：" + e.getMessage());
            return START_NOT_STICKY;
        }

        io.execute(this::setupYouTube);
        return START_NOT_STICKY;
    }

    /* ================= YouTubeの準備 → 映像を送る（まだ非公開の待機中） ================= */

    void setupYouTube() {
        try {
            JSONObject st = yt.stream();
            sid = st.getString("id");
            JSONObject ing = st.getJSONObject("cdn").getJSONObject("ingestionInfo");
            rtmpUrl = ing.getString("ingestionAddress") + "/" + ing.getString("streamName");
            JSONObject b = yt.createBroadcast(title, desc);
            bid = b.getString("id");
            getSharedPreferences("synccam", MODE_PRIVATE).edit().putString("lastBid", bid).putString("lastEmail", yt.email).apply();
            chatId = b.getJSONObject("snippet").optString("liveChatId", null);
            yt.bind(bid, sid);
            try { yt.setCategory(bid, title, desc, cat); } catch (Exception ignored) { }
            if (thumb != null) {
                try { yt.setThumbnail(bid, thumbJpeg(thumb)); }
                catch (Exception e) { toast("サムネイルを設定できませんでした：" + e.getMessage()); }
            }
            main.post(() -> {
                if (ending) return;
                try {
                    display.startStream(rtmpUrl);
                    // 顔・動画・写真・字幕・URL・チャットは、配信の映像にだけ重ねる
                    main.postDelayed(() -> {
                        if (ending) return;
                        try { comp = new Compositor(this, this, display, streamW, streamH); comp.start(); }
                        catch (Exception e) { toast("カメラ・動画などを重ねられませんでした：" + e.getMessage()); }
                    }, 800);
                } catch (Exception e) {
                    fail("映像を送り始められませんでした：" + e.getMessage());
                }
            });
        } catch (Exception e) {
            fail("YouTubeの準備に失敗しました：" + e.getMessage());
        }
    }

    /* ================= 黒い丸の操作 ================= */

    @Override
    public void onConfirmedGoLive() {
        if (state == 0) {
            // まだYouTubeにつながっていない → つながったらすぐ公開する
            wantLive = true;
            overlay.setState(Overlay.STARTING);
            busyStep = "YouTubeにつないでいます…";
            toast("つながったら、すぐ公開します");
            return;
        }
        if (state != 1) return;
        state = 2;
        wantLive = false;
        overlay.setState(Overlay.STARTING);
        busyStep = "公開を始めています…";
        toast("公開を始めています…");
        updateNotification("公開を始めています…");
        io.execute(() -> {
            try {
                // YouTubeに映像が届くのを待つ
                busyStep = "YouTubeに映像を届けています…";
                long t0 = System.currentTimeMillis();
                while (!"active".equals(yt.streamStatus(sid))) {
                    if (ending) return;
                    if (System.currentTimeMillis() - t0 > 60000) throw new Exception("YouTubeに映像が届いていません。ネット接続を確認してください");
                    Thread.sleep(2000);
                }
                // 待機中からそのまま公開（テスト段階をはさまない）
                busyStep = "公開に切り替えています…";
                String life = yt.lifeCycle(bid);
                if (!"live".equals(life) && !"liveStarting".equals(life)) {
                    Exception last = null;
                    for (int i = 0; i < 5 && !ending; i++) {
                        try { yt.transition(bid, "live"); last = null; break; }
                        catch (Exception e) { last = e; Thread.sleep(3000); }
                    }
                    if (last != null) throw last;
                }
                waitFor("live", 60000);
                if (ending) return;
                state = 3;
                main.post(() -> {
                    startRecording();
                    Link.Main.sendLive(true);
                    overlay.setState(Overlay.LIVE);
                    toast("YouTubeでライブが始まりました（公開）");
                    updateNotification("● YouTubeでライブ中");
                });
                io.execute(this::pollAlerts);
                startTts();
                pollChat();
            } catch (Exception e) {
                if (ending) return;
                state = 1;
                main.post(() -> {
                    overlay.setState(Overlay.WAITING);
                    toast("公開できませんでした：" + e.getMessage() + "\nもう一度黒い丸を押してください");
                    updateNotification("待機中（まだ公開されていません）");
                });
            }
        });
    }

    void waitFor(String want, long timeout) throws Exception {
        long t0 = System.currentTimeMillis();
        while (true) {
            String s = yt.lifeCycle(bid);
            if (ending || want.equals(s) || ("testing".equals(want) && "live".equals(s))) return;
            if (System.currentTimeMillis() - t0 > timeout) throw new Exception("YouTubeの切り替えが終わりません（" + s + "）");
            Thread.sleep(2500);
        }
    }

    volatile boolean firstChat = true;

    /* ================= コメントの読み上げ ================= */

    android.speech.tts.TextToSpeech tts;
    volatile boolean ttsReady = false;
    String lastSpeaker = "";
    long lastSpeakAt = 0;
    int ttsSeq = 0;

    void startTts() {
        if (!getSharedPreferences("synccam", MODE_PRIVATE).getBoolean("ttsOn", false)) return;
        main.post(() -> {
            try {
                tts = new android.speech.tts.TextToSpeech(getApplicationContext(), status -> {
                    if (status != android.speech.tts.TextToSpeech.SUCCESS) { toast("読み上げを使えませんでした"); return; }
                    tts.setLanguage(java.util.Locale.JAPANESE);
                    tts.setSpeechRate(1.1f);
                    tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                        public void onStart(String id) { }
                        public void onError(String id) { }
                        public void onDone(String id) {
                            java.io.File f = new java.io.File(getCacheDir(), id + ".wav");
                            if (!f.exists()) return;
                            // 配信の音にまぜる（見ている人に聞こえる）
                            if (bgm != null) bgm.addClip(f, 1.0f, 30000, true);
                            // イヤホンをつけているときだけ、自分にも聞こえる（スピーカーだとマイクに入って二重になるため）
                            if (headphones()) {
                                main.post(() -> {
                                    try {
                                        android.media.MediaPlayer mp = new android.media.MediaPlayer();
                                        mp.setDataSource(f.getPath());
                                        mp.setOnCompletionListener(m -> { m.release(); f.delete(); });
                                        mp.prepare();
                                        mp.start();
                                    } catch (Exception e) { f.delete(); }
                                });
                            } else {
                                main.postDelayed(f::delete, 60000);
                            }
                        }
                    });
                    ttsReady = true;
                });
            } catch (Exception ignored) { }
        });
    }

    void stopTts() {
        ttsReady = false;
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        tts = null;
    }

    boolean headphones() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
            for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET
                        || t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
                        || t == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    /** コメントを読みやすい形にする */
    static String readable(String text) {
        String t = text;
        t = t.replaceAll("https?://\\S+", "");                                  // URLは読まない
        t = t.replaceAll("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]", "");   // 絵文字は読まない
        t = t.replaceAll(":[a-zA-Z0-9_-]+:", "");                                // YouTubeのスタンプ
        t = t.replaceAll("(?<![A-Za-zＡ-Ｚａ-ｚ])[wWｗＷ]+(?![A-Za-zＡ-Ｚａ-ｚ])", "わら");   // w・ｗｗｗ → わら
        t = t.replaceAll("\\s+", " ").trim();
        if (t.codePointCount(0, t.length()) > 50) t = t.substring(0, t.offsetByCodePoints(0, 50));   // 50文字まで
        return t;
    }

    /** 1つのコメントを読み上げる */
    void speak(String channelId, String name, String text) {
        if (!ttsReady || tts == null || bgm == null) return;
        String body = readable(text);
        if (body.isEmpty()) return;
        String nm = name.startsWith("@") ? name.substring(1) : name;
        long now = System.currentTimeMillis();
        boolean same = channelId.equals(lastSpeaker) && now - lastSpeakAt < 60000;
        lastSpeaker = channelId;
        lastSpeakAt = now;
        boolean question = text.trim().endsWith("?") || text.trim().endsWith("？");
        String say;
        if (same) say = body;                                   // 同じ人が続けたら、名前は省く
        else if (question) say = nm + "さんから質問。" + body;
        else say = nm + "さん、ありがとう。" + body;
        String id = "tts" + (ttsSeq++);
        java.io.File f = new java.io.File(getCacheDir(), id + ".wav");
        try { tts.synthesizeToFile(say, null, f, id); } catch (Exception ignored) { }
    }

    void pollChat() {
        new Thread(() -> {
            while (state == 3 && !ending && chatId != null && !chatId.isEmpty()) {
                long wait = 8000;
                try {
                    JSONObject j = yt.chat(chatId, pageToken);
                    pageToken = j.optString("nextPageToken", null);
                    JSONArray items = j.optJSONArray("items");
                    if (items != null) {
                        for (int i = 0; i < items.length(); i++) {
                            JSONObject it = items.getJSONObject(i);
                            String text = it.getJSONObject("snippet").optString("displayMessage", "");
                            String name = it.has("authorDetails") ? it.getJSONObject("authorDetails").optString("displayName", "") : "";
                            if (text.isEmpty()) continue;
                            JSONObject ad = it.optJSONObject("authorDetails");
                            boolean owner = ad != null && ad.optBoolean("isChatOwner", false);
                            String cid = ad == null ? "" : ad.optString("channelId", "");
                            if (!firstChat && !owner) speak(cid, name, text);   // 配信前からのコメントと自分のコメントは読まない
                            final String line = name.isEmpty() ? text : name + "：" + text;
                            main.post(() -> {
                                overlay.addChat(line);
                                chatLines.addFirst(line);
                                while (chatLines.size() > 3) chatLines.removeLast();
                                if (comp != null) comp.setChat(new java.util.ArrayList<>(chatLines));
                            });
                        }
                    }
                    firstChat = false;
                    wait = Math.max(5000, j.optLong("pollingIntervalMillis", 5000));
                } catch (Exception e) {
                    wait = 10000;
                }
                try { Thread.sleep(wait); } catch (InterruptedException ie) { return; }
            }
        }).start();
    }

    /* ================= チャンネル登録・グッドのお知らせ（写真＋効果音） ================= */

    /**
     * チャンネル登録とグッドを見張る。
     * 登録は「登録者の数が増えた」ことでも気づけるようにする
     * （登録を非公開にしている人は、名前のリストに出てこないため）。
     */
    void pollAlerts() {
        new Thread(() -> {
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            boolean first = true;
            long lastLikes = -1, lastSubs = -1;
            while (state == 3 && !ending) {
                int named = 0;
                try {
                    JSONArray subs = yt.recentSubscribers();
                    for (int i = subs.length() - 1; i >= 0; i--) {
                        JSONObject it = subs.getJSONObject(i);
                        String id = it.optString("id");
                        if (seen.add(id) && !first) {
                            JSONObject sn = it.optJSONObject("subscriberSnippet");
                            String name = sn == null ? "" : sn.optString("title", "");
                            alert(true, name.isEmpty() ? "" : name + " さん");
                            named++;
                        }
                    }
                } catch (Exception ignored) { }
                try {
                    long n = yt.subscriberCount();
                    if (n >= 0) {
                        // 名前でまだ知らせていない分だけ知らせる
                        if (lastSubs >= 0 && n > lastSubs) {
                            long more = Math.min(5, (n - lastSubs) - named);
                            for (long k = 0; k < more; k++) alert(true, "");
                        }
                        lastSubs = n;
                    }
                } catch (Exception ignored) { }
                first = false;
                try {
                    long[] st = yt.liveStats(bid);
                    long n = st[1];
                    main.post(() -> { if (overlay != null) overlay.setStats(st[0], st[1]); });
                    if (n >= 0) {
                        if (lastLikes >= 0 && n > lastLikes) alert(false, "");
                        lastLikes = n;
                    }
                } catch (Exception ignored) { }
                try { Thread.sleep(15000); } catch (InterruptedException ie) { return; }
            }
        }).start();
    }

    void alert(boolean subscribe, String sub) {
        main.post(() -> {
            if (ending || overlay == null) return;
            java.io.File img = new java.io.File(getFilesDir(), subscribe ? "subImg" : "likeImg");
            java.io.File snd = new java.io.File(getFilesDir(), subscribe ? "subSnd" : "likeSnd");
            android.content.SharedPreferences p = getSharedPreferences("synccam", MODE_PRIVATE);
            String kind = subscribe ? "sub" : "like";
            int sec = MainActivity.alertSec(p, kind);
            android.graphics.Bitmap bm = img.exists() ? MainActivity.decodeSampled(img, 500) : null;
            try {
                if (comp != null) comp.showAlert(bm, subscribe ? "チャンネル登録ありがとう！" : "グッドありがとう！", sub, sec * 1000);
            } catch (Exception ignored) { }
            // 効果音は配信の音に直接まぜる（スマホのマイクに頼らないので、確実に配信に乗る）
            if (snd.exists() && bgm != null) {
                bgm.addClip(snd, MainActivity.alertVol(p, kind) / 100f, sec * 1000L);
            } else if (snd.exists()) {
                try {
                    android.media.MediaPlayer mp = new android.media.MediaPlayer();
                    mp.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).build());
                    mp.setDataSource(snd.getPath());
                    float v = MainActivity.alertVol(p, kind) / 100f;
                    mp.setVolume(v, v);
                    boolean[] done = {false};
                    mp.setOnCompletionListener(m -> { if (!done[0]) { done[0] = true; m.release(); } });
                    mp.prepare();
                    mp.start();
                    // 写真を出す時間が終わったら、音も止める
                    main.postDelayed(() -> {
                        if (done[0]) return;
                        done[0] = true;
                        try { mp.stop(); } catch (Exception ignored) { }
                        try { mp.release(); } catch (Exception ignored) { }
                    }, sec * 1000L);
                } catch (Exception ignored) { }
            }
        });
    }

    /** サムネイルをYouTube用（1280×720・2MB以下のJPEG）にする */
    static byte[] thumbJpeg(String path) throws Exception {
        android.graphics.Bitmap src = MainActivity.decodeSampled(new java.io.File(path), 1280);
        if (src == null) throw new Exception("画像を読めません");
        android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(1280, 720, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(out);
        c.drawColor(android.graphics.Color.BLACK);
        float sc = Math.max(1280f / src.getWidth(), 720f / src.getHeight());
        float w = src.getWidth() * sc, h = src.getHeight() * sc;
        c.drawBitmap(src, null, new android.graphics.RectF((1280 - w) / 2, (720 - h) / 2, (1280 + w) / 2, (720 + h) / 2), new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG));
        for (int q : new int[]{90, 80, 65, 50}) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            out.compress(android.graphics.Bitmap.CompressFormat.JPEG, q, bo);
            if (bo.size() < 1900 * 1024) return bo.toByteArray();
        }
        throw new Exception("画像が大きすぎます");
    }

    @Override
    public void onPauseToggle(boolean p) {
        paused = p;
        if (comp != null) comp.setPaused(p);
        applyAudio();
        toast(p ? "画面を止めました（視聴者には「一時停止中」が映ります）" : "画面を再開しました");
    }

    @Override
    public void onMicToggle(boolean on) {
        micOn = on;
        applyAudio();
        toast(on ? "マイクをONにしました" : "マイクをミュートしました");
    }

    void applyAudio() {
        try {
            if (micOn && !paused) display.enableAudio(); else display.disableAudio();
        } catch (Exception ignored) { }
    }

    /* ================= 録画（履歴に残す） ================= */

    static java.io.File recDir(android.content.Context c) {
        java.io.File d = c.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES);
        if (d == null) d = new java.io.File(c.getFilesDir(), "movies");
        d.mkdirs();
        return d;
    }

    void startRecording() {
        try {
            String name = "live_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date()) + ".mp4";
            recPath = new java.io.File(recDir(this), name).getPath();
            display.startRecord(recPath);
        } catch (Exception e) {
            recPath = null;
            toast("録画を始められませんでした（配信は続きます）");
        }
    }

    void stopRecording() {
        try { if (recPath != null) display.stopRecord(); } catch (Exception ignored) { }
    }

    @Override
    public void onChatToggle(boolean on) { }

    @Override
    public String busyText() {
        if (state == 0) return "YouTubeにつないでいます…";
        return busyStep;
    }

    @Override
    public void onEnd() { endStream(null); }

    /* ================= 配信を終える ================= */

    void endStream(String errorMessage) {
        if (ending) return;
        ending = true;
        state = 4;
        toast(errorMessage != null ? errorMessage : "配信を終了しています…");
        io.execute(() -> {
            if (bid != null) {
                // 3回までやり直す（トークン切れ・通信エラーでも終わらせる）
                for (int t = 0; t < 3; t++) {
                    try {
                        String life = yt.lifeCycle(bid);
                        if ("live".equals(life) || "liveStarting".equals(life)) yt.transition(bid, "complete");
                        else if (!"complete".equals(life) && !"revoked".equals(life)) yt.deleteBroadcast(bid);   // 公開しなかった配信枠は片づける
                        getSharedPreferences("synccam", MODE_PRIVATE).edit().remove("lastBid").apply();
                        break;
                    } catch (Exception e) {
                        try { Thread.sleep(1500); } catch (InterruptedException ignored) { }
                    }
                }
            }
            main.post(() -> {
                stopRecording();
                stopTts();
                stopBgm();
                if (comp != null) comp.stop();
                Link.Main.sendLive(false);
                Link.Main.endSub();   // 配信終了でサブ機との通信も切る
                try { if (display != null && display.isStreaming()) display.stopStream(); } catch (Exception ignored) { }
                if (overlay != null) overlay.hide();
                getSharedPreferences("synccam", MODE_PRIVATE).edit()
                        .putString("lastMessage", errorMessage != null ? errorMessage : "配信を終了しました").apply();
                Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception ignored) { }
                stopForeground(true);
                stopSelf();
            });
        });
    }

    BgmMixer bgm;

    /** 配信音源：配信を見ている人だけに聞こえる音楽（くり返し） */
    void startBgm() {
        android.content.SharedPreferences p = getSharedPreferences("synccam", MODE_PRIVATE);
        java.io.File f = new java.io.File(getFilesDir(), "bgm");
        // 配信音源がOFFでも、効果音を配信にまぜるために用意しておく
        boolean useBgm = p.getBoolean("bgmOn", false) && f.exists();
        try {
            bgm = new BgmMixer(useBgm ? f : null, p.getInt("bgmVol", 50) / 100f);
            boolean set = false;
            // マイクの音に混ぜる仕組みに、BGMをつなぐ
            try {
                display.getClass().getMethod("setCustomAudioEffect", com.pedro.encoder.input.audio.CustomAudioEffect.class).invoke(display, bgm);
                set = true;
            } catch (Exception e) {
                try {
                    Class<?> c = display.getClass();
                    java.lang.reflect.Field fm = null;
                    while (c != null && fm == null) {
                        try { fm = c.getDeclaredField("microphoneManager"); } catch (NoSuchFieldException ne) { c = c.getSuperclass(); }
                    }
                    if (fm != null) {
                        fm.setAccessible(true);
                        Object mm = fm.get(display);
                        mm.getClass().getMethod("setCustomAudioEffect", com.pedro.encoder.input.audio.CustomAudioEffect.class).invoke(mm, bgm);
                        set = true;
                    }
                } catch (Exception ignored) { }
            }
            if (set) bgm.start();
            else { bgm = null; if (useBgm) toast("配信音源を使えませんでした"); }
        } catch (Exception e) {
            bgm = null;
        }
    }

    void stopBgm() {
        if (bgm != null) bgm.stop();
        bgm = null;
    }

    void fail(String message) {
        main.post(() -> {
            if (ending) return;
            toast(message);
            endStream(message);
        });
    }

    @Override
    public void onDestroy() {
        instance = null;
        stopRecording();
        stopBgm();
        if (comp != null) comp.stop();
        try { if (display != null && display.isStreaming()) display.stopStream(); } catch (Exception ignored) { }
        if (overlay != null) overlay.hide();
        io.shutdownNow();
        super.onDestroy();
    }

    /* ================= 映像の送信状態（ライブラリから呼ばれる） ================= */

    @Override
    public void onConnectionStarted(String url) { }

    @Override
    public void onConnectionSuccess() {
        main.post(() -> {
            if (state == 0) {
                state = 1;
                if (wantLive) { onConfirmedGoLive(); return; }
                toast("待機中です。黒い丸を押すと公開を始められます");
                updateNotification("待機中（まだ公開されていません）");
            }
        });
    }

    @Override
    public void onConnectionFailed(String reason) {
        fail("YouTubeへの接続が切れました：" + reason);
    }

    @Override
    public void onNewBitrate(long bitrate) { }

    @Override
    public void onDisconnect() { }

    @Override
    public void onAuthError() { fail("YouTubeへの接続が拒否されました"); }

    @Override
    public void onAuthSuccess() { }

    /* ================= 通知・トースト ================= */

    void createChannel() {
        NotificationChannel c = new NotificationChannel(CH, "配信", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
    }

    Notification notification(String text) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH)
                .setContentTitle("SyncCam Game")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    void updateNotification(String text) {
        try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(1, notification(text)); } catch (Exception ignored) { }
    }

    void toast(String s) {
        main.post(() -> Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show());
    }
}
