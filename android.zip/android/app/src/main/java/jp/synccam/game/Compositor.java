package jp.synccam.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;

import com.google.android.gms.tasks.Tasks;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.pedro.encoder.input.gl.render.filters.object.BaseObjectFilterRender;
import com.pedro.encoder.input.gl.render.filters.object.ImageObjectFilterRender;
import com.pedro.encoder.input.gl.render.filters.object.SurfaceFilterRender;
import com.pedro.library.rtmp.RtmpDisplay;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 配信の映像にだけ重ねるもの（自分の画面には出さない）。
 * 下から順に：動画 → 写真 → カメラ（雪・犬） → URL → 字幕 → チャット → お礼 → 一時停止
 */
public class Compositor {

    final Context ctx;
    final LifecycleOwner owner;
    final RtmpDisplay display;
    final int W, H;   // 配信の映像の大きさ
    final Handler main = new Handler(Looper.getMainLooper());

    ImageObjectFilterRender camF, photoF, urlF, capF, chatF, alertF, pauseF;
    SurfaceFilterRender videoF;
    MediaPlayer video;
    ProcessCameraProvider camProvider;
    ExecutorService camExec;
    FaceDetector detector;
    WebView web;
    View webWin;
    boolean snow, dog, stopped = false;
    long lastFrame = 0;
    final ArrayDeque<Runnable> alerts = new ArrayDeque<>();
    boolean alertShowing = false;

    Compositor(Context c, LifecycleOwner owner, RtmpDisplay d, int w, int h) {
        ctx = c;
        this.owner = owner;
        display = d;
        W = w;
        H = h;
    }

    static Bitmap clear() {
        Bitmap b = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.TRANSPARENT);
        return b;
    }

    static void place(BaseObjectFilterRender f, double x, double y, double w, double h) {
        f.setScale((float) (w * 100), (float) (h * 100));
        f.setPosition((float) (x * 100), (float) (y * 100));
    }

    static void place(BaseObjectFilterRender f, JSONObject p) {
        place(f, p.optDouble("x"), p.optDouble("y"), p.optDouble("w"), p.optDouble("h"));
    }

    ImageObjectFilterRender imageFilter(Bitmap b) {
        ImageObjectFilterRender f = new ImageObjectFilterRender();
        f.setImage(b);
        display.getGlInterface().addFilter(f);
        return f;
    }

    void start() {
        JSONObject layout = Parts.load(ctx);
        String mode = Parts.mode(ctx);
        snow = Parts.snow(ctx);
        dog = Parts.dog(ctx);
        File dir = ctx.getFilesDir();

        // 動画（くり返し再生）
        JSONObject v = layout.optJSONObject("video");
        File vf = new File(dir, "partVideo");
        if (v != null && v.optBoolean("on") && vf.exists()) {
            boolean sound = v.optBoolean("sound");
            videoF = new SurfaceFilterRender(st -> main.post(() -> startVideo(st, vf, sound)));
            display.getGlInterface().addFilter(videoF);
            place(videoF, v);
        }
        // 写真
        JSONObject p = layout.optJSONObject("photo");
        File pf = new File(dir, "partPhoto");
        if (p != null && p.optBoolean("on") && pf.exists()) {
            Bitmap b = MainActivity.decodeSampled(pf, 900);
            if (b != null) { photoF = imageFilter(rounded(b, 24)); place(photoF, p); }
        }
        // カメラ（顔出し＝前カメラ、手元＝後ろカメラ）
        if ("face".equals(mode) || "hand".equals(mode)) {
            JSONObject c = layout.optJSONObject(mode);
            camF = imageFilter(clear());
            place(camF, c);
            camFront = "face".equals(mode);
            camAspect = (float) (c.optDouble("w") * W) / (float) Math.max(1, c.optDouble("h") * H);
            camExec = Executors.newSingleThreadExecutor();
            if (camFront && (snow || dog)) {
                detector = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build());
            }
            // サブ機がつながっていればサブ機のカメラ、なければこの端末のカメラ
            Link.Main.frames = this::onSubFrame;
            Link.Main.onLinkChange = () -> main.post(this::relink);
            if (!Link.Main.linked()) startCamera();
        }
        // URL
        JSONObject u = layout.optJSONObject("url");
        if (u != null && u.optBoolean("on") && !u.optString("src").isEmpty()) {
            urlF = imageFilter(clear());
            place(urlF, u);
            startWeb(u);
        }
        // 字幕
        JSONObject cap = layout.optJSONObject("caption");
        if (cap != null && cap.optBoolean("on") && !cap.optString("text").isEmpty()) {
            capF = imageFilter(caption(cap.optString("text"), (int) (W * cap.optDouble("w")), (int) (H * cap.optDouble("h"))));
            place(capF, cap);
        }
        // チャット（右上3行）
        chatF = imageFilter(clear());
        if (W > H) place(chatF, 0.68, 0.03, 0.3, 0.18);   // ロング（横）
        else place(chatF, 0.52, 0.03, 0.46, 0.1);
        // お礼・一時停止
        alertF = imageFilter(clear());
        pauseF = imageFilter(clear());
        place(pauseF, 0, 0, 1, 1);
    }

    /* ---------- 動画 ---------- */

    void startVideo(SurfaceTexture st, File f, boolean sound) {
        if (stopped) return;
        try {
            video = new MediaPlayer();
            video.setSurface(new Surface(st));
            video.setDataSource(f.getPath());
            video.setLooping(true);
            video.setVolume(sound ? 1f : 0f, sound ? 1f : 0f);
            video.setOnPreparedListener(mp -> {
                try { st.setDefaultBufferSize(Math.max(2, mp.getVideoWidth()), Math.max(2, mp.getVideoHeight())); } catch (Exception ignored) { }
                mp.start();
            });
            video.prepareAsync();
        } catch (Exception ignored) { }
    }

    /* ---------- カメラ＋雪・犬エフェクト ---------- */

    boolean camFront = true;
    float camAspect = 1;
    volatile boolean subBusy = false;

    void relink() {
        if (stopped || camF == null) return;
        if (Link.Main.linked()) {
            try { if (camProvider != null) camProvider.unbindAll(); } catch (Exception ignored) { }
        } else {
            startCamera();
        }
    }

    /** サブ機から届いた映像（上向き）。前カメラなら鏡のように左右反転 */
    void onSubFrame(Bitmap b) {
        if (stopped || camExec == null || subBusy) return;
        subBusy = true;
        camExec.execute(() -> {
            try {
                Bitmap up = b;
                if (camFront) {
                    Matrix m = new Matrix();
                    m.postScale(-1, 1);
                    up = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                }
                processUpright(up, SystemClock.uptimeMillis());
            } catch (Exception ignored) {
            } finally {
                subBusy = false;
            }
        });
    }

    void startCamera() {
        boolean front = camFront;
        float aspect = camAspect;
        ListenableFuture<ProcessCameraProvider> fut = ProcessCameraProvider.getInstance(ctx);
        fut.addListener(() -> {
            if (stopped) return;
            try {
                camProvider = fut.get();
                ImageAnalysis ia = new ImageAnalysis.Builder()
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .setTargetResolution(new android.util.Size(480, 640))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                ia.setAnalyzer(camExec, img -> onFrame(img, aspect, front));
                camProvider.unbindAll();
                camProvider.bindToLifecycle(owner, front ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA, ia);
            } catch (Exception ignored) { }
        }, ContextCompat.getMainExecutor(ctx));
    }

    final Paint smooth = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

    void onFrame(ImageProxy img, float aspect, boolean front) {
        try {
            long now = SystemClock.uptimeMillis();
            if (stopped || now - lastFrame < 55 || Link.Main.linked()) return;   // 1秒に約18回
            lastFrame = now;
            Bitmap src = img.toBitmap();
            Matrix m = new Matrix();
            m.postRotate(img.getImageInfo().getRotationDegrees());
            if (front) m.postScale(-1, 1);   // 前カメラは鏡のように（自撮りと同じ向き）
            Bitmap up = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
            processUpright(up, now);
        } catch (Exception ignored) {
        } finally {
            img.close();
        }
    }

    /** 上向きの映像を枠の形に切り取り、雪・犬を描いて配信に重ねる */
    void processUpright(Bitmap up, long now) throws Exception {
        float aspect = camAspect;
        {
            int bw = up.getWidth(), bh = up.getHeight();
            int cw = bw, ch = Math.round(bw / aspect);
            if (ch > bh) { ch = bh; cw = Math.round(bh * aspect); }
            int cx = (bw - cw) / 2, cy = (bh - ch) / 2;
            int outW = Math.min(cw, 480);
            float s = outW / (float) cw;
            int outH = Math.max(2, Math.round(ch * s));
            Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            Path clip = new Path();
            clip.addRoundRect(new RectF(0, 0, outW, outH), outW * 0.06f, outW * 0.06f, Path.Direction.CW);
            c.clipPath(clip);
            c.drawBitmap(up, new Rect(cx, cy, cx + cw, cy + ch), new Rect(0, 0, outW, outH), smooth);
            if (detector != null) {
                List<Face> faces = Tasks.await(detector.process(InputImage.fromBitmap(up, 0)), 2, TimeUnit.SECONDS);
                float t = now / 1000f;
                for (Face f : faces) {
                    RectF r = new RectF(f.getBoundingBox());
                    r.offset(-cx, -cy);
                    r = new RectF(r.left * s, r.top * s, r.right * s, r.bottom * s);
                    if (snow) Effects.snow(c, r, t);
                    if (dog) Effects.dog(c, r);
                }
            }
            if (camF != null && !stopped) camF.setImage(out);
        }
    }

    /* ---------- URL（見えない場所でページを開いて、配信にだけ映す） ---------- */

    void startWeb(JSONObject u) {
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            int w = Math.max(200, (int) (ctx.getResources().getDisplayMetrics().widthPixels * u.optDouble("w")));
            int h = Math.max(120, (int) (ctx.getResources().getDisplayMetrics().heightPixels * u.optDouble("h")));
            web = new WebView(ctx);
            web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.setBackgroundColor(Color.WHITE);
            web.setWebViewClient(new WebViewClient());
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_SECURE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.alpha = 0f;   // 自分の画面には見せない
            wm.addView(web, lp);
            webWin = web;
            web.loadUrl(u.optString("src"));
            main.postDelayed(this::snapWeb, 2500);
        } catch (Exception ignored) { }
    }

    void snapWeb() {
        if (stopped || web == null || urlF == null) return;
        try {
            if (web.getWidth() > 0 && web.getHeight() > 0) {
                Bitmap b = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
                web.draw(new Canvas(b));
                urlF.setImage(rounded(b, 18));
            }
        } catch (Exception ignored) { }
        main.postDelayed(this::snapWeb, 2000);
    }

    /* ---------- 字幕・チャット・お礼・一時停止の絵 ---------- */

    static Bitmap rounded(Bitmap src, float r) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Path p = new Path();
        p.addRoundRect(new RectF(0, 0, src.getWidth(), src.getHeight()), r, r, Path.Direction.CW);
        c.clipPath(p);
        c.drawBitmap(src, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    static Bitmap caption(String text, int w, int h) {
        w = Math.max(40, w);
        h = Math.max(20, h);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(140, 0, 0, 0));
        c.drawRoundRect(new RectF(0, 0, w, h), h * 0.2f, h * 0.2f, bg);
        String[] lines = text.split("\n");
        int n = Math.min(lines.length, 4);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setFakeBoldText(true);
        tp.setTextAlign(Paint.Align.CENTER);
        float fs = Math.min(h * 0.75f / n, 80);
        tp.setTextSize(fs);
        float widest;
        do {
            widest = 0;
            for (int i = 0; i < n; i++) widest = Math.max(widest, tp.measureText(lines[i]));
            if (widest > w * 0.92f) { fs -= 2; tp.setTextSize(fs); }
        } while (widest > w * 0.92f && fs > 10);
        float lh = fs * 1.15f, y0 = h / 2f - lh * (n - 1) / 2f - (tp.ascent() + tp.descent()) / 2f;
        for (int i = 0; i < n; i++) {
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(Math.max(2, fs / 9));
            tp.setColor(Color.argb(220, 0, 0, 0));
            c.drawText(lines[i], w / 2f, y0 + i * lh, tp);
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(Color.WHITE);
            c.drawText(lines[i], w / 2f, y0 + i * lh, tp);
        }
        return b;
    }

    void setChat(List<String> lines) {
        if (chatF == null || stopped) return;
        if (lines.isEmpty()) { chatF.setImage(clear()); return; }
        int w = (int) (W * (W > H ? 0.3 : 0.46)), h = (int) (H * (W > H ? 0.18 : 0.1));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(110, 0, 0, 0));
        c.drawRoundRect(new RectF(0, 0, w, h), 18, 18, bg);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setFakeBoldText(true);
        tp.setTextSize(h / 4.6f);
        tp.setColor(Color.WHITE);
        tp.setShadowLayer(4, 0, 1, Color.BLACK);
        float y = h * 0.1f - tp.ascent();
        for (String s : lines) {
            String t = s;
            while (t.length() > 1 && tp.measureText(t) > w - 24) t = t.substring(0, t.length() - 1);
            if (!t.equals(s)) t = t.substring(0, Math.max(0, t.length() - 1)) + "…";
            c.drawText(t, 12, y, tp);
            y += h * 0.3f;
        }
        chatF.setImage(b);
    }

    void showAlert(Bitmap img, String title, String sub, int ms) {
        alerts.add(() -> {
            int w = 520;
            int imgH = img != null ? 300 : 0;
            int h = 40 + imgH + (img != null ? 20 : 0) + 70 + (sub == null || sub.isEmpty() ? 0 : 50) + 30;
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(Color.argb(210, 0, 0, 0));
            c.drawRoundRect(new RectF(4, 4, w - 4, h - 4), 44, 44, bg);
            Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeWidth(6);
            st.setColor(Color.WHITE);
            c.drawRoundRect(new RectF(4, 4, w - 4, h - 4), 44, 44, st);
            float y = 40;
            if (img != null) {
                Bitmap r = rounded(Bitmap.createScaledBitmap(centerSquare(img), 300, 300, true), 32);
                c.drawBitmap(r, (w - 300) / 2f, y, null);
                y += 320;
            }
            TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            tp.setColor(Color.WHITE);
            tp.setFakeBoldText(true);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTextSize(40);
            while (tp.measureText(title) > w - 40 && tp.getTextSize() > 20) tp.setTextSize(tp.getTextSize() - 2);
            c.drawText(title, w / 2f, y + 50, tp);
            if (sub != null && !sub.isEmpty()) {
                tp.setFakeBoldText(false);
                tp.setTextSize(28);
                c.drawText(sub, w / 2f, y + 100, tp);
            }
            double fw = 0.68, fh = fw * W * h / w / H;
            place(alertF, (1 - fw) / 2, 0.3, fw, fh);
            alertF.setImage(b);
            alertShowing = true;
            main.postDelayed(() -> { if (alertF != null && !stopped) alertF.setImage(clear()); nextAlert(); }, Math.max(1500, ms));
        });
        if (!alertShowing) nextAlert();
    }

    void nextAlert() {
        alertShowing = false;
        Runnable r = alerts.poll();
        if (r != null && !stopped && alertF != null) r.run();
    }

    static Bitmap centerSquare(Bitmap b) {
        int s = Math.min(b.getWidth(), b.getHeight());
        return Bitmap.createBitmap(b, (b.getWidth() - s) / 2, (b.getHeight() - s) / 2, s, s);
    }

    void setPaused(boolean p) {
        if (pauseF == null) return;
        if (!p) { pauseF.setImage(clear()); return; }
        int w = 360, h = Math.max(2, Math.round(360f * H / W));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.BLACK);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.WHITE);
        tp.setFakeBoldText(true);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(34);
        c.drawText("一時停止中", w / 2f, h / 2f, tp);
        tp.setFakeBoldText(false);
        tp.setTextSize(18);
        tp.setColor(Color.argb(180, 255, 255, 255));
        c.drawText("しばらくお待ちください", w / 2f, h / 2f + 40, tp);
        pauseF.setImage(b);
    }

    /* ---------- 片づけ ---------- */

    void stop() {
        stopped = true;
        Link.Main.frames = null;
        Link.Main.onLinkChange = null;
        try { if (camProvider != null) camProvider.unbindAll(); } catch (Exception ignored) { }
        try { if (camExec != null) camExec.shutdown(); } catch (Exception ignored) { }
        try { if (detector != null) detector.close(); } catch (Exception ignored) { }
        try { if (video != null) video.release(); } catch (Exception ignored) { }
        try {
            if (webWin != null) ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).removeView(webWin);
            if (web != null) web.destroy();
        } catch (Exception ignored) { }
        try { display.getGlInterface().clearFilters(); } catch (Exception ignored) { }
    }

    static List<String> list(ArrayDeque<String> q) { return new ArrayList<>(q); }
}
