package jp.synccam.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * YouTubeのサムネイルのように、写真を指で動かして（1本指）、大きさを変えて（2本指）、
 * 枠の中に入れる場所を決める。結果は元の写真の中の割合 (左,上,右,下) で返す。
 */
public class CropView extends View {
    final Bitmap bmp;
    final float aspect;   // 枠の 横÷縦
    float scale, tx, ty;  // 写真の表示倍率と位置
    RectF frame = new RectF();
    final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    final ScaleGestureDetector pinch;
    float lastX, lastY;
    boolean ready = false;
    float[] initial;   // 前に決めた場所（あれば）

    CropView(Context c, Bitmap bmp, float aspect, float[] initial) {
        super(c);
        this.bmp = bmp;
        this.aspect = aspect;
        this.initial = initial;
        setBackgroundColor(Color.BLACK);
        pinch = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            public boolean onScale(ScaleGestureDetector d) {
                float ns = Math.max(minScale(), Math.min(minScale() * 8, scale * d.getScaleFactor()));
                float f = ns / scale;
                tx = d.getFocusX() - (d.getFocusX() - tx) * f;
                ty = d.getFocusY() - (d.getFocusY() - ty) * f;
                scale = ns;
                clamp();
                invalidate();
                return true;
            }
        });
    }

    float minScale() { return Math.max(frame.width() / bmp.getWidth(), frame.height() / bmp.getHeight()); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float pad = w * 0.06f;
        float fw = w - pad * 2, fh = fw / aspect;
        if (fh > h - pad * 2) { fh = h - pad * 2; fw = fh * aspect; }
        frame.set((w - fw) / 2, (h - fh) / 2, (w + fw) / 2, (h + fh) / 2);
        if (initial != null && initial[2] > initial[0] && initial[3] > initial[1]) {
            float cw = (initial[2] - initial[0]) * bmp.getWidth();
            scale = frame.width() / cw;
            tx = frame.left - initial[0] * bmp.getWidth() * scale;
            ty = frame.top - initial[1] * bmp.getHeight() * scale;
        } else {
            scale = minScale();
            tx = frame.centerX() - bmp.getWidth() * scale / 2;
            ty = frame.centerY() - bmp.getHeight() * scale / 2;
        }
        clamp();
        ready = true;
    }

    /** 枠の中にすき間ができないようにする */
    void clamp() {
        if (scale < minScale()) scale = minScale();
        float bw = bmp.getWidth() * scale, bh = bmp.getHeight() * scale;
        tx = Math.min(frame.left, Math.max(frame.right - bw, tx));
        ty = Math.min(frame.top, Math.max(frame.bottom - bh, ty));
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!ready) return;
        c.drawBitmap(bmp, null, new RectF(tx, ty, tx + bmp.getWidth() * scale, ty + bmp.getHeight() * scale), paint);
        // 枠の外を暗くする
        Path p = new Path();
        p.addRect(0, 0, getWidth(), getHeight(), Path.Direction.CW);
        p.addRect(frame, Path.Direction.CCW);
        paint.setColor(Color.argb(170, 0, 0, 0));
        c.drawPath(p, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4);
        paint.setColor(Color.WHITE);
        c.drawRect(frame, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        pinch.onTouchEvent(e);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX(); lastY = e.getY();
                break;
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_POINTER_DOWN:
                lastX = e.getX(0); lastY = e.getY(0);
                break;
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() == 1 && !pinch.isInProgress()) {
                    tx += e.getX() - lastX;
                    ty += e.getY() - lastY;
                    clamp();
                    invalidate();
                }
                lastX = e.getX(0); lastY = e.getY(0);
                break;
        }
        return true;
    }

    /** 枠に入っている部分（元の写真の中の割合） */
    float[] result() {
        float l = (frame.left - tx) / scale / bmp.getWidth();
        float t = (frame.top - ty) / scale / bmp.getHeight();
        float r = (frame.right - tx) / scale / bmp.getWidth();
        float b = (frame.bottom - ty) / scale / bmp.getHeight();
        return new float[]{clamp01(l), clamp01(t), clamp01(r), clamp01(b)};
    }

    static float clamp01(float v) { return Math.max(0, Math.min(1, v)); }

    /* ---------- 保存と読み出し ---------- */

    static void save(SharedPreferences sp, String key, float[] r) {
        sp.edit().putString("crop_" + key, r[0] + "," + r[1] + "," + r[2] + "," + r[3]).apply();
    }

    static float[] load(SharedPreferences sp, String key) {
        String s = sp.getString("crop_" + key, null);
        if (s == null) return null;
        try {
            String[] a = s.split(",");
            return new float[]{Float.parseFloat(a[0]), Float.parseFloat(a[1]), Float.parseFloat(a[2]), Float.parseFloat(a[3])};
        } catch (Exception e) { return null; }
    }

    /** 決めた場所で写真を切り取る（決めていなければそのまま） */
    static Bitmap apply(Bitmap src, float[] r) {
        if (src == null || r == null || r[2] <= r[0] || r[3] <= r[1]) return src;
        int x = Math.round(r[0] * src.getWidth()), y = Math.round(r[1] * src.getHeight());
        int w = Math.max(1, Math.min(src.getWidth() - x, Math.round((r[2] - r[0]) * src.getWidth())));
        int h = Math.max(1, Math.min(src.getHeight() - y, Math.round((r[3] - r[1]) * src.getHeight())));
        try { return Bitmap.createBitmap(src, x, y, w, h); } catch (Exception e) { return src; }
    }
}
