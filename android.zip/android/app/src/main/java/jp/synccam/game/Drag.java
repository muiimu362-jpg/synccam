package jp.synccam.game;

import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

/** 1秒（動画・写真は3秒）長押ししたら動かせる。短くタップなら onTap。自分の指で押したときだけ反応する */
public class Drag {

    interface Listener {
        void onStart();
        void onMove(float dx, float dy);
        void onEnd();
    }

    static void attach(View v, Runnable onTap, Listener l) { attach(v, onTap, l, 1000); }

    static void attach(View v, Runnable onTap, Listener l, long holdMs) {
        Handler h = new Handler(Looper.getMainLooper());
        v.setOnTouchListener(new View.OnTouchListener() {
            float x0, y0;
            boolean dragging, cancelled;
            long t0;
            android.widget.TextView count;
            // 長押しのあいだ「あと○秒」を真ん中に出す（指が少し震えても止まらない）
            final Runnable tick = new Runnable() {
                public void run() {
                    if (dragging || cancelled) return;
                    long left = holdMs - (android.os.SystemClock.uptimeMillis() - t0);
                    if (left <= 0) return;
                    showCount(String.valueOf((left + 999) / 1000));
                    h.postDelayed(this, 100);
                }
            };

            void showCount(String s) {
                if (holdMs < 2000 || !(v instanceof android.widget.FrameLayout)) return;
                if (count == null) {
                    count = new android.widget.TextView(v.getContext());
                    count.setTextColor(android.graphics.Color.WHITE);
                    count.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 26);
                    count.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                    count.setGravity(android.view.Gravity.CENTER);
                    count.setBackgroundColor(android.graphics.Color.argb(120, 0, 0, 0));
                    ((android.widget.FrameLayout) v).addView(count, new android.widget.FrameLayout.LayoutParams(-1, -1));
                }
                count.setText(s);
            }

            void hideCount() {
                if (count != null) { try { ((android.widget.FrameLayout) v).removeView(count); } catch (Exception ignored) { } count = null; }
            }
            final Runnable arm = () -> {
                dragging = true;
                hideCount();
                try {
                    Vibrator vb = (Vibrator) v.getContext().getSystemService(android.content.Context.VIBRATOR_SERVICE);
                    if (vb != null) vb.vibrate(30);
                } catch (Exception ignored) { }
                v.setAlpha(0.7f);
                if (l != null) l.onStart();
            };

            @Override
            public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x0 = e.getRawX(); y0 = e.getRawY();
                        dragging = false; cancelled = false;
                        t0 = android.os.SystemClock.uptimeMillis();
                        view.getParent().requestDisallowInterceptTouchEvent(true);
                        h.postDelayed(arm, holdMs);
                        if (holdMs >= 2000) h.postDelayed(tick, 250);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (dragging) {
                            if (l != null) l.onMove(e.getRawX() - x0, e.getRawY() - y0);
                        } else if (!cancelled && Math.hypot(e.getRawX() - x0, e.getRawY() - y0) > slop(view)) {
                            cancelled = true;
                            h.removeCallbacks(arm);
                            h.removeCallbacks(tick);
                            hideCount();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        h.removeCallbacks(arm);
                        h.removeCallbacks(tick);
                        hideCount();
                        v.setAlpha(1f);
                        if (dragging) { if (l != null) l.onEnd(); }
                        else if (!cancelled && onTap != null) onTap.run();
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        h.removeCallbacks(arm);
                        h.removeCallbacks(tick);
                        hideCount();
                        v.setAlpha(1f);
                        if (dragging && l != null) l.onEnd();
                        dragging = false;
                        return true;
                }
                return false;
            }
        });
    }

    /** 長押し中に許す指のブレ（長い長押しほど大きめ） */
    static float slop(View v) {
        return 28 * v.getResources().getDisplayMetrics().density;
    }
}
