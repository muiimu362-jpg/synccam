package jp.synccam.game;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** YouTube Data API */
public class YouTube {

    static final String API = "https://www.googleapis.com/youtube/v3/";

    /** APIのエラー */
    public static class ApiException extends Exception {
        final int code;
        final String error;
        ApiException(int code, String error, String message) {
            super(message);
            this.code = code;
            this.error = error;
        }
    }

    final android.content.Context ctx;
    final String email;
    String cached = null;
    long cachedAt = 0;

    public YouTube(android.content.Context c, String email) {
        ctx = c.getApplicationContext();
        this.email = email;
    }

    /** Googleのトークン（50分ごとに取り直す） */
    synchronized String token() throws Exception {
        if (cached != null && System.currentTimeMillis() - cachedAt < 50 * 60 * 1000L) return cached;
        cached = Auth.tokenBlocking(ctx, email);
        cachedAt = System.currentTimeMillis();
        return cached;
    }

    void setToken(String t) { cached = t; cachedAt = System.currentTimeMillis(); }

    /* ---------------- 通信 ---------------- */

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    static JSONObject http(String method, String url, String token, String contentType, byte[] body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", contentType);
            try (OutputStream o = c.getOutputStream()) { o.write(body); }
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String s = in == null ? "" : readAll(in);
        c.disconnect();
        JSONObject j;
        try { j = s.trim().isEmpty() ? new JSONObject() : new JSONObject(s); }
        catch (Exception e) { j = new JSONObject(); }
        if (code >= 400) {
            Object err = j.opt("error");
            String errCode = "";
            String msg = "通信エラー（" + code + "）";
            if (err instanceof String) {
                errCode = (String) err;
                msg = j.optString("error_description", errCode);
            } else if (err instanceof JSONObject) {
                JSONObject eo = (JSONObject) err;
                msg = eo.optString("message", msg);
                JSONArray arr = eo.optJSONArray("errors");
                if (arr != null && arr.length() > 0) errCode = arr.getJSONObject(0).optString("reason", "");
                if ("liveStreamingNotEnabled".equals(errCode)) msg = "このアカウントはYouTubeのライブ配信が有効になっていません";
            }
            throw new ApiException(code, errCode, msg);
        }
        return j;
    }

    /** 名前・メール・写真・チャンネル名を取ってくる */
    JSONObject loadProfile() throws Exception {
        JSONObject u = http("GET", "https://www.googleapis.com/oauth2/v3/userinfo", token(), null, null);
        String ch = "", chIcon = "";
        try {
            JSONArray items = get("channels?part=snippet&mine=true").optJSONArray("items");
            if (items != null && items.length() > 0) {
                JSONObject sn = items.getJSONObject(0).getJSONObject("snippet");
                ch = sn.optString("title", "");
                JSONObject th = sn.optJSONObject("thumbnails");
                if (th != null) {
                    JSONObject t = th.optJSONObject("medium");
                    if (t == null) t = th.optJSONObject("default");
                    if (t != null) chIcon = t.optString("url", "");
                }
            }
        } catch (Exception ignored) { }
        // 白い丸に出すアイコン：YouTubeチャンネルのアイコン。なければGoogleの写真
        String pic = chIcon.isEmpty() ? u.optString("picture", "") : chIcon;
        if (!pic.isEmpty()) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(pic).openConnection();
                c.setConnectTimeout(10000); c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream();
                     java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(ctx.getFilesDir(), Auth.avatarName(email)))) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                }
            } catch (Exception ignored) { }
        }
        return new JSONObject().put("email", email).put("name", u.optString("name", "")).put("channel", ch);
    }

    /* ---------------- YouTube Live ---------------- */

    JSONObject get(String path) throws Exception { return http("GET", API + path, token(), null, null); }

    JSONObject send(String method, String path, JSONObject body) throws Exception {
        return http(method, API + path, token(), "application/json; charset=UTF-8",
                body == null ? new byte[0] : body.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** 配信用のストリーム（ストリームキー）。SyncCam用を1つ作って使い回す */
    JSONObject stream() throws Exception {
        JSONObject j = get("liveStreams?part=id,snippet,cdn,status&mine=true&maxResults=50");
        JSONArray items = j.optJSONArray("items");
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject s = items.getJSONObject(i);
                if (s.getJSONObject("snippet").optString("title").contains("SyncCam")) return s;
            }
        }
        JSONObject body = new JSONObject()
                .put("snippet", new JSONObject().put("title", "SyncCam Game"))
                .put("cdn", new JSONObject().put("frameRate", "variable").put("ingestionType", "rtmp").put("resolution", "variable"))
                .put("contentDetails", new JSONObject().put("isReusable", true));
        return send("POST", "liveStreams?part=id,snippet,cdn,contentDetails,status", body);
    }

    static String nowIso() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    /** 配信枠を作る。まだ視聴者には見えない（テスト中→あとで公開） */
    JSONObject createBroadcast(String title, String desc) throws Exception {
        if (title == null || title.trim().isEmpty()) title = "ゲーム配信";
        if (title.length() > 100) title = title.substring(0, 100);
        JSONObject body = new JSONObject()
                .put("snippet", new JSONObject().put("title", title).put("description", desc == null ? "" : desc).put("scheduledStartTime", nowIso()))
                .put("status", new JSONObject().put("privacyStatus", "public").put("selfDeclaredMadeForKids", false))
                .put("contentDetails", new JSONObject()
                        .put("enableAutoStart", false)
                        .put("enableAutoStop", false)
                        .put("enableDvr", true)
                        .put("latencyPreference", "low")
                        .put("monitorStream", new JSONObject().put("enableMonitorStream", false)));
        return send("POST", "liveBroadcasts?part=id,snippet,status,contentDetails", body);
    }

    void bind(String bid, String sid) throws Exception {
        send("POST", "liveBroadcasts/bind?part=id,contentDetails&id=" + bid + "&streamId=" + sid, null);
    }

    void setCategory(String bid, String title, String desc, String categoryId) throws Exception {
        JSONObject body = new JSONObject().put("id", bid).put("snippet",
                new JSONObject().put("title", title == null || title.trim().isEmpty() ? "ゲーム配信" : title)
                        .put("description", desc == null ? "" : desc).put("categoryId", categoryId == null ? "20" : categoryId));
        send("PUT", "videos?part=snippet", body);
    }

    /** サムネイル（JPEG）を設定 */
    void setThumbnail(String bid, byte[] jpeg) throws Exception {
        http("POST", "https://www.googleapis.com/upload/youtube/v3/thumbnails/set?uploadType=media&videoId=" + bid, token(), "image/jpeg", jpeg);
    }

    /** 最近チャンネル登録してくれた人（登録を公開している人だけ） */
    JSONArray recentSubscribers() throws Exception {
        JSONArray a = get("subscriptions?part=subscriberSnippet&myRecentSubscribers=true&maxResults=20").optJSONArray("items");
        return a == null ? new JSONArray() : a;
    }

    /** 自分のチャンネルの登録者数（非公開なら -1） */
    long subscriberCount() throws Exception {
        JSONArray items = get("channels?part=statistics&mine=true").optJSONArray("items");
        if (items == null || items.length() == 0) return -1;
        JSONObject st = items.getJSONObject(0).optJSONObject("statistics");
        if (st == null || st.optBoolean("hiddenSubscriberCount", false)) return -1;
        return Long.parseLong(st.optString("subscriberCount", "-1"));
    }

    /** 配信のグッドの数 */
    long likeCount(String bid) throws Exception {
        JSONArray items = get("videos?part=statistics&id=" + bid).optJSONArray("items");
        if (items == null || items.length() == 0) return -1;
        JSONObject st = items.getJSONObject(0).optJSONObject("statistics");
        return st == null ? -1 : Long.parseLong(st.optString("likeCount", "-1"));
    }

    String streamStatus(String sid) throws Exception {
        JSONArray items = get("liveStreams?part=status&id=" + sid).optJSONArray("items");
        if (items == null || items.length() == 0) return "";
        return items.getJSONObject(0).getJSONObject("status").optString("streamStatus");
    }

    String lifeCycle(String bid) throws Exception {
        JSONArray items = get("liveBroadcasts?part=status&id=" + bid).optJSONArray("items");
        if (items == null || items.length() == 0) return "";
        return items.getJSONObject(0).getJSONObject("status").optString("lifeCycleStatus");
    }

    void transition(String bid, String to) throws Exception {
        send("POST", "liveBroadcasts/transition?part=status&broadcastStatus=" + to + "&id=" + bid, null);
    }

    void deleteBroadcast(String bid) throws Exception {
        http("DELETE", API + "liveBroadcasts?id=" + bid, token(), null, null);
    }

    JSONObject chat(String chatId, String pageToken) throws Exception {
        String q = "liveChat/messages?part=snippet,authorDetails&maxResults=200&liveChatId=" + URLEncoder.encode(chatId, "UTF-8");
        if (pageToken != null && !pageToken.isEmpty()) q += "&pageToken=" + URLEncoder.encode(pageToken, "UTF-8");
        return get(q);
    }
}
