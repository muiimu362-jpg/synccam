package jp.synccam.game;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.File;
import java.io.RandomAccessFile;

/**
 * 「流れている音を録る」：スマホで流れている音（ほかのアプリの音）を、マイクを使わずに直接録る。
 * 画面の端に「● 0:12 ■」を出して、■で止める。録った音は WAV で保存して、アプリに戻る。
 */
public class CaptureService extends Service {

    static final String CH = "capture";
    static final int RATE = 44100;
    static final long MAX_MS = 10 * 60 * 1000L;   // 最長10分
    static volatile CaptureService instance;

    final Handler main = new Handler(Looper.getMainLooper());
    MediaProjection projection;
    AudioRecord rec;
    volatile boolean running = false;
    File out;
    long startAt;
    long bytes = 0;
    int peak = 0;
    TextView bubble;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "stop".equals(intent.getAction())) { stopIfRunning(); return START_NOT_STICKY; }
        if (intent == null || instance != null || Build.VERSION.SDK_INT < 29) { if (instance == null) stopSelf(); return START_NOT_STICKY; }
        instance = this;
        NotificationChannel c = new NotificationChannel(CH, "音の録音", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        PendingIntent pi = PendingIntent.getService(this, 0, new Intent(this, CaptureService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH)
                .setContentTitle("SyncCam：流れている音を録っています")
                .setContentText("画面の「▶ スタート」で録りはじめ、「■ 終了」で止める（ここをタップでやめる）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
        try {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (Exception e) {
            try { startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); } catch (Exception e2) { finish(false, "録音を始められませんでした"); return START_NOT_STICKY; }
        }
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), intent.getParcelableExtra("data"));
            if (Build.VERSION.SDK_INT >= 34) {
                projection.registerCallback(new MediaProjection.Callback() {
                    @Override
                    public void onStop() { if (running) stopRecording(); }
                }, main);
            }
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)   // 音楽・動画の音だけ（ゲーム・通知・着信は録らない）。マイクは使わない
                    .build();
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min * 2, 8192))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
        } catch (SecurityException e) {
            finish(false, "マイク（録音）の許可が必要です");
            return START_NOT_STICKY;
        } catch (Exception e) {
            finish(false, "録音を始められませんでした：" + e.getMessage());
            return START_NOT_STICKY;
        }
        out = new File(getCacheDir(), "capture.wav");
        showBubble();   // まだ録らない。「▶ スタート」を押したら録りはじめる
        return START_NOT_STICKY;
    }

    volatile boolean started = false;

    /** 「▶ スタート」を押した瞬間から録る */
    void beginCapture() {
        if (started) return;
        started = true;
        startAt = System.currentTimeMillis();
        running = true;
        new Thread(this::loop, "capture").start();
        paintBubble();
        main.post(new Runnable() {
            public void run() {
                if (!running || bubble == null) return;
                paintBubble();
                main.postDelayed(this, 500);
            }
        });
    }

    void paintBubble() {
        if (bubble == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(100);
        if (!started) {
            bg.setColor(Color.argb(235, 22, 163, 74));
            bubble.setText("▶ スタート");
        } else {
            bg.setColor(Color.argb(235, 220, 38, 38));
            long s = (System.currentTimeMillis() - startAt) / 1000;
            bubble.setText(String.format(java.util.Locale.US, "● %d:%02d   ■ 終了", s / 60, s % 60));
        }
        bubble.setBackground(bg);
    }

    void loop() {
        try (RandomAccessFile f = new RandomAccessFile(out, "rw")) {
            f.setLength(0);
            f.write(new byte[44]);   // あとでWAVの見出しを書く
            byte[] buf = new byte[8192];
            rec.startRecording();
            while (running) {
                int n = rec.read(buf, 0, buf.length);
                if (n <= 0) continue;
                f.write(buf, 0, n);
                bytes += n;
                for (int i = 0; i + 1 < n; i += 64) {
                    int s = Math.abs((short) ((buf[i] & 0xff) | (buf[i + 1] << 8)));
                    if (s > peak) peak = s;
                }
                if (System.currentTimeMillis() - startAt > MAX_MS) main.post(this::stopRecording);
            }
            try { rec.stop(); } catch (Exception ignored) { }
            writeWavHeader(f, bytes);
        } catch (Exception e) {
            bytes = 0;
        }
        main.post(() -> finish(bytes > RATE * 4L / 2, null));
    }

    static void writeWavHeader(RandomAccessFile f, long data) throws Exception {
        int ch = 2, bits = 16;
        long byteRate = (long) RATE * ch * bits / 8;
        f.seek(0);
        f.writeBytes("RIFF");
        f.write(le32(36 + data));
        f.writeBytes("WAVE");
        f.writeBytes("fmt ");
        f.write(le32(16));
        f.write(le16(1));
        f.write(le16(ch));
        f.write(le32(RATE));
        f.write(le32(byteRate));
        f.write(le16(ch * bits / 8));
        f.write(le16(bits));
        f.writeBytes("data");
        f.write(le32(data));
    }

    static byte[] le32(long v) { return new byte[]{(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24)}; }
    static byte[] le16(int v) { return new byte[]{(byte) v, (byte) (v >> 8)}; }

    void showBubble() {
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            bubble = new TextView(this);
            bubble.setTextColor(Color.WHITE);
            bubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            bubble.setTypeface(Typeface.DEFAULT_BOLD);
            int p = (int) (12 * getResources().getDisplayMetrics().density);
            bubble.setPadding(p + p / 2, p, p + p / 2, p);
            bubble.setOnClickListener(v -> { if (!started) beginCapture(); else stopRecording(); });
            paintBubble();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = p;
            lp.y = p * 8;
            wm.addView(bubble, lp);
        } catch (Exception ignored) { }
    }

    void hideBubble() {
        try { if (bubble != null) ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(bubble); } catch (Exception ignored) { }
        bubble = null;
    }

    void stopRecording() {
        if (!started) { finish(false, "録音をやめました"); return; }
        running = false;
        hideBubble();
    }

    /** 終わったら、アプリを開いて「切る・写真・名前」の画面へ */
    void finish(boolean ok, String error) {
        running = false;
        hideBubble();
        try { if (rec != null) rec.release(); } catch (Exception ignored) { }
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (ok) {
            i.putExtra("captured", out.getPath());
            i.putExtra("capturedSilent", peak < 200);
        } else {
            i.putExtra("captureError", error != null ? error : "音が短すぎて保存できませんでした");
        }
        try { startActivity(i); } catch (Exception ignored) { }
        instance = null;
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        hideBubble();
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) { }

    static void stopIfRunning() {
        CaptureService s = instance;
        if (s != null) s.main.post(s::stopRecording);
    }
}
