package jp.synccam.game;

import java.io.DataInputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * しゃべくらから「みんなの声＋自分の声」を直接もらう係。
 * スマホの中だけ（127.0.0.1:19132）でつながる。スピーカーの音を拾い直さないので反響しない。
 * しゃべくら側：通話画面の「📺 配信アプリに声を送る」をオン。
 *
 * 届く音：16kHz・ステレオ・16bit → 配信の 44.1kHz・ステレオに変えて、ためておく。
 */
public class ShabekuraVoice {

    static final int PORT = 19132;
    static final int IN_RATE = 16000;
    static final String PACKAGE = "com.muiimu.shabekura";

    final int outRate;
    volatile boolean running = false;
    volatile boolean connected = false;
    volatile Socket socket;
    Runnable onConnect, onDisconnect;

    // 44.1kHzステレオを2秒ぶん
    final short[] ring;
    long wpos = 0, rpos = 0;
    boolean primed = false;
    final Object lock = new Object();

    ShabekuraVoice(int outRate) {
        this.outRate = outRate;
        ring = new short[outRate * 2 * 2];
    }

    void start() {
        if (running) return;
        running = true;
        new Thread(this::loop, "shabekura-voice").start();
    }

    void stop() {
        running = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
    }

    void loop() {
        while (running) {
            try (Socket s = new Socket()) {
                socket = s;
                s.connect(new InetSocketAddress("127.0.0.1", PORT), 1000);
                s.setTcpNoDelay(true);
                DataInputStream in = new DataInputStream(s.getInputStream());
                String header = readLine(in);
                if (!header.startsWith("SHABEKURA PCM 16000 2 s16le")) throw new Exception("not shabekura");
                connected = true;
                synchronized (lock) { rpos = wpos; }   // つながったら今から
                Runnable r = onConnect; if (r != null) r.run();
                byte[] frame = new byte[2560];         // 40ms・16kHz・ステレオ
                double step = (double) IN_RATE / outRate, t = 0;
                int prevL = 0, prevR = 0;
                while (running) {
                    in.readFully(frame);
                    int n = frame.length / 4;
                    synchronized (lock) {
                        for (int i = 0; i < n; i++) {
                            int l = (short) ((frame[4 * i] & 0xff) | (frame[4 * i + 1] << 8));
                            int rr = (short) ((frame[4 * i + 2] & 0xff) | (frame[4 * i + 3] << 8));
                            // 16kHz → 44.1kHz（あいだをなめらかにつなぐ）
                            while (t < 1.0) {
                                put((int) (prevL + (l - prevL) * t), (int) (prevR + (rr - prevR) * t));
                                t += step;
                            }
                            t -= 1.0;
                            prevL = l;
                            prevR = rr;
                        }
                        long max = ring.length / 2;
                        if (wpos - rpos > max) rpos = wpos - max / 2;   // ためすぎたら古いのを捨てる
                    }
                }
            } catch (Exception ignored) {
            }
            if (connected) { connected = false; Runnable r = onDisconnect; if (r != null && running) r.run(); }
            if (running) try { Thread.sleep(1000); } catch (InterruptedException e) { break; }   // しゃべくらを待つ
        }
    }

    void put(int l, int r) {
        int i = (int) ((wpos % (ring.length / 2)) * 2);
        ring[i] = (short) l;
        ring[i + 1] = (short) r;
        wpos++;
    }

    /** 1フレーム（左右）ぶんの声を取り出す。足りなければ false */
    boolean next(int[] lr) {
        synchronized (lock) {
            long avail = wpos - rpos;
            if (!primed && avail < outRate * 60L / 1000) return false;   // 少したまってから流す（とぎれにくく）
            if (avail <= 0) { primed = false; return false; }
            primed = true;
            int i = (int) ((rpos % (ring.length / 2)) * 2);
            lr[0] = ring[i];
            lr[1] = ring[i + 1];
            rpos++;
            return true;
        }
    }

    static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        while (sb.length() < 200) {
            int c = in.read();
            if (c < 0 || c == '\n') break;
            sb.append((char) c);
        }
        return sb.toString().trim();
    }
}
